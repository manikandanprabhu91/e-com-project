package com.qvc.cti.socket.protocol.converter.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.qvc.cti.socket.protocol.converter.logger.SocketLogger;

/**
 * @author c003987
 *
 */
@Configuration
@EnableAspectJAutoProxy
@ComponentScan(basePackages = {"com.qvc.cti.socket.protocol.converter.logger"})
public class AspectConfig {
	
	 @Autowired
	 private SocketLogger socketLogger;
    
    @PostConstruct
    public void initialize() {
    	socketLogger.setAspectConfig(this);
    }
}