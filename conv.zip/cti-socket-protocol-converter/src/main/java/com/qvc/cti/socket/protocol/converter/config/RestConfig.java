package com.qvc.cti.socket.protocol.converter.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.client.RestTemplate;

@Configuration
@PropertySource("classpath:application.yml")
public class RestConfig {

  private static final String CLASS_NAME = "RestConfig";
  private final Log log = LogFactory.getLog(getClass());

  @Value("${service.url}")
  private String url;

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  @Bean
  public RestTemplate createTemplate() {
    return new RestTemplate();
  }
}