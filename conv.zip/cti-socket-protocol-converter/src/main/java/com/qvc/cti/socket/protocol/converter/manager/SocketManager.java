package com.qvc.cti.socket.protocol.converter.manager;

import java.io.IOException;
import java.net.UnknownHostException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.qvc.order.model.cti.CallInfo;

import lombok.extern.slf4j.Slf4j;

/**
 * @author c003987
 *
 */
@Slf4j
@Service
public class SocketManager {

  private final Log log = LogFactory.getLog(getClass());
  private static final String SYMBOL = "!";
  private static final String PATTEREN = "0001";
  private static final String CONSTANTS = "S";
  private static final char CONSTANT_CALL_ABANDONED = 'A';
  private static final char CONSTANT_CALL_INCOMING = 'I';
  private static final char CONSTANT_CALL_TRANSFER_REQ = 'T';
  private static final char CONSTANT_CALL_TRANSFER = 'X';
  private static final char CONSTANT_CALL_CONFIRMATION = 'C';

  @Autowired
  private RestManager restManager;

  @Bean
  public CallInfo getCtiCallInfo() {
    return new CallInfo();
  }

  CallInfo ctiCallInfo = getCtiCallInfo();

  public void convert(String message) throws UnknownHostException, IOException {

    if (StringUtils.startsWith(message, SYMBOL)) {
      log.info("FEED DATA : "+message);
      if (StringUtils.indexOf(message, CONSTANTS) != -1
          && StringUtils.indexOf(message, CONSTANTS) == 43) {
        if (StringUtils.substring(message, 44, 48).equals(PATTEREN)) {
          log.info("ASAI Line down");
        } else {
          log.info("Received Heart Beat Message !");
        }
      } else {
        callRestApiBasedOnCallIndicator(message);
      }
    } else {
      log.info("Out of Sequence");
      log.info("FEED DATA : "+message);
    }

  }

  private CallInfo splitMessage(String message) {
    ctiCallInfo.setDnis(StringUtils.substring(message, 6, 16));
    ctiCallInfo.setAni(StringUtils.substring(message, 16, 26));
    ctiCallInfo.setSiteId(StringUtils.substring(message, 26, 27));
    ctiCallInfo.setCallId(StringUtils.substring(message, 27, 31));
    ctiCallInfo.setCallDay(StringUtils.substring(message, 31, 33));
    ctiCallInfo.setCallTime(StringUtils.substring(message, 33, 37));
    ctiCallInfo.setReservedATT(StringUtils.substring(message, 37, 40));
    ctiCallInfo.setReservedQVC(StringUtils.substring(message, 40, 43));
    ctiCallInfo.setCallType(StringUtils.substring(message, 43, 44));
    ctiCallInfo.setExtension(StringUtils.substring(message, 49, 59));
    ctiCallInfo.setVdnTo(StringUtils.substring(message, 64, 74));
    ctiCallInfo.setQvcCallType(StringUtils.substring(message, 74, 75));
    ctiCallInfo.setDestinationCode(StringUtils.substring(message, 75, 76));
    return ctiCallInfo;
  }

  private void callRestApiBasedOnCallIndicator(String message) {
    char callIndicator = message.charAt(43);
    if (callIndicator == CONSTANT_CALL_ABANDONED) {
      ctiCallInfo = splitMessage(message);
      log.info("Calling Call Abandoned Service..");
      restManager.callAbandoned(ctiCallInfo);
    }
    if (callIndicator == CONSTANT_CALL_INCOMING) {
      ctiCallInfo = splitMessage(message);
      log.info("Calling Incoming service..");
      restManager.callIncoming(ctiCallInfo);
    }
    if (callIndicator == CONSTANT_CALL_TRANSFER_REQ) {
      ctiCallInfo = splitMessage(message);
      log.info("Calling Transfer Req service..");
      restManager.callTransferReq(ctiCallInfo);
    }
    if (callIndicator == CONSTANT_CALL_TRANSFER) {
      ctiCallInfo = splitMessage(message);
      log.info("Calling Transfer service..");
      restManager.callTransfer(ctiCallInfo);
    }
    if (callIndicator == CONSTANT_CALL_CONFIRMATION) {
      ctiCallInfo = splitMessage(message);
      log.info("Calling Confirmation service..");
      restManager.callConfirmation(ctiCallInfo);
    }
  }

  public RestManager getRestManager() {
    return restManager;
  }

  public void setRestManager(RestManager restManager) {
    this.restManager = restManager;
  }
}
