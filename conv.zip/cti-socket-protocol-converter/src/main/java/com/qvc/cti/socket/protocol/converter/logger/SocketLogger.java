package com.qvc.cti.socket.protocol.converter.logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import com.qvc.cti.socket.protocol.converter.config.AspectConfig;

/**
 * @author c003987
 *
 */
@Aspect
@Component
public class SocketLogger {

  private final Log log = LogFactory.getLog(getClass());

  private AspectConfig aspectConfig;

  public void setAspectConfig(AspectConfig aspectConfig) {
    this.aspectConfig = aspectConfig;
  }

  @AfterReturning("execution(* com.qvc.cti.socket.protocol..*.*(..)) && !@annotation(com.qvc.cti.socket.protocol.converter.util.NoLogging)")
  public void logMethodAccessAfterReturning(JoinPoint joinPoint) {
    log.info("Completed Method: " + joinPoint.getTarget().getClass().getName() + "."
        + joinPoint.getSignature().getName() + "()");
  }

  @Before("execution(* com.qvc.cti.socket.protocol..*.*(..)) && !@annotation(com.qvc.cti.socket.protocol.converter.util.NoLogging)")
  public void logMethodAccessBefore(JoinPoint joinPoint) {
    log.info("Starting Executing : " + joinPoint.getTarget().getClass().getName() + "."
        + joinPoint.getSignature().getName() + "()");
  }

  @AfterThrowing("execution(* com.qvc.cti.socket.protocol.converter.manager.SocketManager.*(..))")
  public void logAfterThrowingAllMethods() throws Throwable {
    log.info("****** logAfterThrowingAllMethods() ****");
  }
}