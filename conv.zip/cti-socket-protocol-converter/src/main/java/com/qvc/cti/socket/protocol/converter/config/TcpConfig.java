package com.qvc.cti.socket.protocol.converter.config;

import java.io.IOException;
import java.net.UnknownHostException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.serializer.Deserializer;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.ip.tcp.TcpReceivingChannelAdapter;
import org.springframework.integration.ip.tcp.connection.AbstractServerConnectionFactory;
import org.springframework.integration.ip.tcp.connection.TcpNetServerConnectionFactory;
import org.springframework.integration.ip.tcp.serializer.ByteArrayCrLfSerializer;
import org.springframework.integration.ip.tcp.serializer.ByteArraySingleTerminatorSerializer;
import org.springframework.messaging.MessageChannel;

import com.qvc.cti.socket.protocol.converter.manager.SocketManager;
import com.qvc.cti.socket.protocol.converter.util.CustomDeserializer;


/**
 * @author c003987
 *
 */
@Configuration
@PropertySource("classpath:application.yml")
public class TcpConfig {

  @Value("${server.port1}")
  private int port1;

  @Value("${server.port2}")
  private int port2;

  @Bean
  public SocketManager getInstance() {
    return new SocketManager();
  }
  
  @SuppressWarnings("rawtypes")
  @Bean
  public Deserializer getCustomDeserializer() {
    return new CustomDeserializer();
  }

  @Bean
  public ByteArrayCrLfSerializer getByteArrayCrLfSerializer() {
	  ByteArrayCrLfSerializer serilizer = new ByteArrayCrLfSerializer();
	  serilizer.setMaxMessageSize(100);
	  return serilizer;
  }

  @Bean
  public ByteArraySingleTerminatorSerializer getByteArraySingleTerminatorSerializer() {
    return new ByteArraySingleTerminatorSerializer((byte) 0);
  }

  @Bean
  @Primary
  public TcpNetServerConnectionFactory connectionFactory() {
    TcpNetServerConnectionFactory tcp = new TcpNetServerConnectionFactory(port1);
    tcp.setSerializer(getByteArrayCrLfSerializer());
    tcp.setDeserializer(getCustomDeserializer());
    tcp.setSingleUse(false);
    tcp.setSoKeepAlive(true);
    return tcp;
  }

  @Bean
  @Qualifier
  public TcpNetServerConnectionFactory connectionFactory2() {
    TcpNetServerConnectionFactory tcp = new TcpNetServerConnectionFactory(port2);
    tcp.setSerializer(getByteArrayCrLfSerializer());
    tcp.setDeserializer(getCustomDeserializer());
    tcp.setSingleUse(false);
    tcp.setSoKeepAlive(true);
    return tcp;
  }

  @Bean
  public TcpReceivingChannelAdapter inbound1(AbstractServerConnectionFactory cf) {
    TcpReceivingChannelAdapter adapter = new TcpReceivingChannelAdapter();
    adapter.setConnectionFactory(connectionFactory());
    adapter.setOutputChannel(toSA());
    return adapter;
  }

  @Bean
  public TcpReceivingChannelAdapter inbound2(AbstractServerConnectionFactory cf) {
    TcpReceivingChannelAdapter adapter = new TcpReceivingChannelAdapter();
    adapter.setConnectionFactory(connectionFactory2());
    adapter.setOutputChannel(toSA());
    return adapter;
  }

  @Bean
  public MessageChannel toSA() {
    return new DirectChannel();
  }

  @Bean
  public MessageChannel toSA2() {
    return new DirectChannel();
  }

/*  @ServiceActivator(inputChannel = "toSA")
  public void service(byte[] in) throws UnknownHostException, IOException {
    System.out.println(in);
    // byte[] b = in.getBytes(StandardCharsets.UTF_8);
    getInstance().convert(new String(in));
  }*/

  @ServiceActivator(inputChannel = "toSA")
  public void service(String in) throws UnknownHostException, IOException {
    getInstance().convert(in);
  }
}