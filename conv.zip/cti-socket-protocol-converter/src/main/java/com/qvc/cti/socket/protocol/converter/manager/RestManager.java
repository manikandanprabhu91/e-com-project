package com.qvc.cti.socket.protocol.converter.manager;

import java.net.URI;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriTemplate;

import com.qvc.cti.socket.protocol.converter.config.RestConfig;
import com.qvc.order.model.cti.CallInfo;

@Service
public class RestManager {

  private static final String CLASS_NAME = "RestManager";
  private final Log log = LogFactory.getLog(getClass());
  @Autowired
  private RestConfig restConfig;

  public String callAbandoned(CallInfo cTICallInfo) {
    String methodName = " ::callAbandoned";
    URI expandedURI = new UriTemplate(restConfig.getUrl()).expand("US");
    log.debug(CLASS_NAME + methodName);
    /*
     * TODO restConfig.createTemplate().exchange(expandedURI, HttpMethod.POST,
     * createRequestEntity(cTICallInfo), CTICallInfo.class);
     */
    return "callAbandoned";
  }

  public String callIncoming(CallInfo cTICallInfo) {
    String methodName = " ::callIncoming";
    URI expandedURI = new UriTemplate(restConfig.getUrl()).expand("US");
    log.debug(CLASS_NAME + methodName);
    /*
     * TODO restConfig.createTemplate().exchange(expandedURI, HttpMethod.POST,
     * createRequestEntity(cTICallInfo), CTICallInfo.class);
     */
    return "callIncoming";
  }

  public String callTransferReq(CallInfo cTICallInfo) {
    String methodName = " ::callTransferReq";
    URI expandedURI = new UriTemplate(restConfig.getUrl()).expand("US");
    log.debug(CLASS_NAME + methodName);
    /*
     * TODO restConfig.createTemplate().exchange(expandedURI, HttpMethod.POST,
     * createRequestEntity(cTICallInfo), CTICallInfo.class);
     */
    return "callTransferReq";
  }

  public String callTransfer(CallInfo cTICallInfo) {
    String methodName = " ::callTransfer";
    URI expandedURI = new UriTemplate(restConfig.getUrl()).expand("US");
    log.debug(CLASS_NAME + methodName);
    /*
     * TODO restConfig.createTemplate().exchange(expandedURI, HttpMethod.POST,
     * createRequestEntity(cTICallInfo), CTICallInfo.class);
     */
    return "callTransfer";
  }

  public String callConfirmation(CallInfo cTICallInfo) {
    String methodName = " ::callConfirmation";
    URI expandedURI = new UriTemplate(restConfig.getUrl()).expand("US");
    log.debug(CLASS_NAME + methodName);
    /*
     * TODO restConfig.createTemplate().exchange(expandedURI, HttpMethod.POST,
     * createRequestEntity(cTICallInfo), CTICallInfo.class);
     */
    return "callConfirmation";
  }

  private HttpEntity<CallInfo> createRequestEntity(CallInfo o) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return new HttpEntity<CallInfo>(o, headers);
  }

  public RestConfig getRestConfig() {
    return restConfig;
  }

  public void setRestConfig(RestConfig restConfig) {
    this.restConfig = restConfig;
  }
}