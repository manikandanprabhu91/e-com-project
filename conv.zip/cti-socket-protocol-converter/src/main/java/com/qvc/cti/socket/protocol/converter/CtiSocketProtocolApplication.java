package com.qvc.cti.socket.protocol.converter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * @author c003987
 *
 */
@Configuration
@ComponentScan(basePackages = {"com.qvc.cti.socket.protocol.converter.*"})
@EnableAutoConfiguration
@EnableAspectJAutoProxy
@SpringBootApplication
public class CtiSocketProtocolApplication {
  public static void main(String[] args) {
    SpringApplication.run(CtiSocketProtocolApplication.class, args);
  }
}
