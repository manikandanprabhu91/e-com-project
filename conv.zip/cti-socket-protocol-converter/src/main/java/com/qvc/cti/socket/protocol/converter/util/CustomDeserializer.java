package com.qvc.cti.socket.protocol.converter.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.springframework.core.serializer.Deserializer;
import org.springframework.core.serializer.Serializer;
import org.springframework.integration.ip.tcp.serializer.SoftEndOfStreamException;

public class CustomDeserializer implements Deserializer, Serializer {

  private static final String SHORT_CLASS_NAME = "CustomDeserializer";
  private static final byte[] CRLF = "\r\n".getBytes();

  @Override
  @NoLogging
  public String deserialize(InputStream inputStream) throws IOException {
	  
		int n = 0;
		int maxMessageSize = 96;
		byte[] buffer = new byte[96];
		int bite;
		try {
			while (true) {
				bite = inputStream.read();
				if (bite < 0 && n == 0) {
					throw new SoftEndOfStreamException("Stream closed between payloads");
				}
				checkClosure(bite);
				if (n > 0 && bite == '\n' && buffer[n - 1] == '\r') {
					break;
				}
				buffer[n++] = (byte) bite;
				if (n >= maxMessageSize) {
					break;
				}
			}
			byte[] assembledData = new byte[n];
			System.arraycopy(buffer, 0, assembledData, 0, n);
			return new String(assembledData);
		} catch (SoftEndOfStreamException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		}

	}

	public void checkClosure(int bite) throws IOException {
		if (bite < 0) {
			throw new IOException("Socket closed during message assembly");
		}
	}

	@Override
	public void serialize(Object object, OutputStream outputStream) throws IOException {
		// TODO Auto-generated method stub
		outputStream.write(CRLF);

	}
}

