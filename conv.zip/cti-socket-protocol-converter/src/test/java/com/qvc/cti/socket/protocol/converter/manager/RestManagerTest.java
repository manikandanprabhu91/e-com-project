package com.qvc.cti.socket.protocol.converter.manager;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.qvc.cti.socket.protocol.converter.config.RestConfig;
import com.qvc.order.model.cti.CallInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration
public class RestManagerTest {

  RestConfig restConfig = null;
  RestManager restManager;

  @Before

  public void setUp() throws Exception {

    restManager = new RestManager();
    restConfig = new RestConfig();
    restConfig.setUrl("http://localhost:9080/{US}");
    restManager.setRestConfig(restConfig);
  }

  @Test
  public void testConvertIncomingCall() throws IOException {

    assertEquals("callIncoming", restManager.callIncoming(new CallInfo()));
  }

  @Test
  public void testConvertCallAbandoned() throws IOException {

    assertEquals("callAbandoned", restManager.callAbandoned(new CallInfo()));
  }

  @Test
  public void testConvertCallTransferReq() throws IOException {

    assertEquals("callTransferReq", restManager.callTransferReq(new CallInfo()));
  }

  @Test
  public void testConvertCallTransfer() throws IOException {
    assertEquals("callTransfer", restManager.callTransfer(new CallInfo()));
  }

  @Test
  public void testConvertCallConfirmation() throws IOException {

    assertEquals("callConfirmation", restManager.callConfirmation(new CallInfo()));
  }

}
