package com.qvc.cti.socket.protocol.converter.manager;

import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.qvc.cti.socket.protocol.converter.config.RestConfig;
import com.qvc.order.model.cti.CallInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration
public class SocketManagerTest {

  private SocketManager manager;
  RestManager restManager = Mockito.mock(RestManager.class);
  RestConfig restConfig = Mockito.mock(RestConfig.class);

  @Before

  public void setUp() throws Exception {

    MockitoAnnotations.initMocks(this);
    manager = new SocketManager();
    manager.setRestManager(restManager);
  }

  @Test
  public void testConvertIncomingCall() throws IOException {


    String s =
        "!4292 4292      610701690511605140834X  qvcI4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
    doCallRealMethod().when(restManager).callIncoming(Mockito.any(CallInfo.class));
    verify(restManager, times(1)).callIncoming(Mockito.any(CallInfo.class));
  }

  @Test
  public void testConvertCallAbandoned() throws IOException {

    String s =
        "!4292 4292      610701690511605140834X  qvcA4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
    restManager.setRestConfig(restConfig);
    doCallRealMethod().when(restManager).callAbandoned(Mockito.any(CallInfo.class));
    verify(restManager, times(1)).callAbandoned(Mockito.any(CallInfo.class));
  }

  @Test
  public void testConvertCallTransferReq() throws IOException {

    String s =
        "!4292 4292      610701690511605140834X  qvcT4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
    doCallRealMethod().when(restManager).callTransferReq(Mockito.any(CallInfo.class));
    verify(restManager, times(1)).callTransferReq(Mockito.any(CallInfo.class));
  }

  @Test
  public void testConvertCallTransfer() throws IOException {
    String s =
        "!4292 4292      610701690511605140834X  qvcX4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
    doCallRealMethod().when(restManager).callTransfer(Mockito.any(CallInfo.class));
    verify(restManager, times(1)).callTransfer(Mockito.any(CallInfo.class));
  }

  @Test
  public void testConvertCallConfirmation() throws IOException {
    String s =
        "!4292 4292      610701690511605140834X  qvcC4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
    doCallRealMethod().when(restManager).callConfirmation(Mockito.any(CallInfo.class));
    verify(restManager, times(1)).callConfirmation(Mockito.any(CallInfo.class));
  }

  @Test()
  public void testLineDown() throws IOException {
    String s =
        "!4292 4292      610701690511605140834X  qvcS0001 61088350314321 1013104321                   G1`05";
    manager.convert(s);
  }

  @Test()
  public void testConvertOutOFSequence() throws IOException {
    String s =
        "4292 4292      610701690511605140834X  qvcI4532 61088350314321 1013104321                   G1`05";
    manager.convert(s);
  }

}
