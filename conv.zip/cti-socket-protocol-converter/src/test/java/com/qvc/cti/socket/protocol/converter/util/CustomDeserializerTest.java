package com.qvc.cti.socket.protocol.converter.util;

import static org.junit.Assert.assertEquals;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.ip.tcp.serializer.SoftEndOfStreamException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration
public class CustomDeserializerTest {

  CustomDeserializer customDeserializer;
  InputStream inputStream;
  String input;

  @Before

  public void setUp() throws Exception {

    customDeserializer = new CustomDeserializer();
    input =
        "!4292 4292      610701690511605140834X  qvcX5031 61088350314321 1013104321                   G1`";
    inputStream = new ByteArrayInputStream(input.getBytes());
  }

  @Test
  public void testDeserialize() throws IOException {
    assertEquals(input, customDeserializer.deserialize(inputStream));
  }

  @Test(expected = Exception.class)
  public void testSocketEndOfStreamEx() throws IOException {
    //inputStream = new ByteArrayInputStream(null);
    customDeserializer.deserialize(null);
  }

  @Test(expected = IOException.class)
  public void testControlCharacter() throws IOException {
    byte[] array = {13};
    inputStream = new ByteArrayInputStream(array);
    assertEquals(96, customDeserializer.deserialize(inputStream).length());
  }
}
