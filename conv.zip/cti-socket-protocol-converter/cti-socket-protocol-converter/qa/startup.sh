#!/bin/sh

### Enter application name and port within the quotes below ###
APP_NAME="cti-socket-protocol-converter"
APP_PORT="12046"
KEYSTORE_PASSWORD=$(cat /applications/common/security/tomcat/keys/keystore_pass)
ENV="qa"

### Uncomment below if using Dynatrace. Enter agent name and Dynatrace server as supplied by ESM team. ###
# AGENT_NAME=""
# DYNATRACE_SERVER=""
# DT_JAVAOPTIONS="-agentpath:/opt/dynatrace/dynatrace-7.0.0/agent/lib64/libdtagent.so=name=${AGENT_NAME},server=${DYNATRACE_SERVER}"

JAVA_OPTS="$JAVA_OPTS\
 -Xms512m\
 -Xmx512m\
 -XX:MaxNewSize=128m\
 -XX:NewSize=128m\
 -XX:+UseConcMarkSweepGC\
 -XX:+UseParNewGC\
 -XX:CMSInitiatingOccupancyFraction=65\
 -XX:+UseCMSInitiatingOccupancyOnly\
 -XX:CMSWaitDuration=300000\
 -XX:+CMSScavengeBeforeRemark\
 -XX:+UnlockCommercialFeatures\
 -XX:+FlightRecorder\
 -Djava.awt.headless=true\
 -Djava.rmi.server.hostname=$HOSTNAME\
 -Denv.dir=/applications\
 -Dlog.dir=/logs\
 -Dserver.tomcat.accesslog.enabled=true\
 -Dserver.tomcat.accesslog.rename-on-rotate=true\
 -Dserver.tomcat.accesslog.request-attributes-enabled=false\
 -Dserver.tomcat.accesslog.directory=/logs/$APP_NAME/\
 -Dserver.ssl.key-store=/applications/common/security/tomcat/keys/$ENV-$APP_NAME.qvcdev.qvc.net.p12\
 -Dserver.ssl.key-store-password=$KEYSTORE_PASSWORD\
 -Dserver.ssl.keyStoreType=PKCS12\
 -Djavax.net.ssl.trustStore=/applications/common/security/tomcat/keys/qvcmsca_trust\
 -Dserver.ssl.enabled=true\
 -Dserver.ssl.enabled-protocols=TLSv1.2\
 -Dserver.ssl.ciphers=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_DHE_RSA_WITH_AES_256_CBC_SHA256,TLS_DHE_RSA_WITH_AES_128_CBC_SHA256,TLS_DHE_RSA_WITH_AES_256_CBC_SHA,TLS_DHE_RSA_WITH_AES_128_CBC_SHA,TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA,TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA,TLS_RSA_WITH_AES_256_GCM_SHA384,TLS_RSA_WITH_AES_128_GCM_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_3DES_EDE_CBC_SHA\
 -Dserver.port=$APP_PORT"

 # Custom JAVA_OPTS

### Enter additional Java options below. Leave a space between options. Can add as many as needed, ###
### Example: JAVA_OPTS="-Dspring.profiles.active=qa -Dspring... $JAVA_OPTS"
JAVA_OPTS=" $JAVA_OPTS"

JAR_FILE=$(ls /applications/common/bin/$APP_NAME/*.jar)

exec /usr/java/latest/bin/java $JAVA_OPTS -jar $JAR_FILE >> /logs/$APP_NAME/startup.out 2>&1 &