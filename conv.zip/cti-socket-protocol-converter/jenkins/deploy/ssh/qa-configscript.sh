#!/bin/bash

APP_NAME="cti-socket-protocol-converter"
DIR_NAME="cti-socket-protocol-converter"
ENV="qa"

mkdir -p /applications/common/bin/${APP_NAME}/config/
rm -rf /applications/common/bin/${APP_NAME}/config/*
unzip -jn /tmp/${APP_NAME}/config.zip 'config/application*.yml' -d /applications/common/bin/${APP_NAME}/config/

mkdir -p /applications/common/scripts/${DIR_NAME}/
rm -rf /applications/common/scripts/${DIR_NAME}/*
unzip -j /tmp/${APP_NAME}/config.zip ${DIR_NAME}/${ENV}/\* -d /applications/common/scripts/${DIR_NAME}/
chmod 755 /applications/common/scripts/${DIR_NAME}/*