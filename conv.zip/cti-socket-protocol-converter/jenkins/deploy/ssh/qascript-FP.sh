#!/bin/bash
APP_NAME="cti-socket-protocol-converter"
DIR_NAME="cti-socket-protocol-converter"
#AGENT_GROUP="ORDER_FP_ADMIN"
#DYNATRACE_SERVER="U01VDAAWAPP0098.qvcdev.qvc.net:9998"
HEALTH_PATH=/health
US_PORT=12046
SLEEP_DURATION=5
# Remove if your app doesn't use Couchbase
#DC_CODE="FP"

sudo -u tomcat mkdir -p /logs/${DIR_NAME}/

echo "Shutting down US Service"
cd /applications/common/bin/${APP_NAME}
sudo -u tomcat /applications/common/scripts/${DIR_NAME}/shutdown.sh

echo "Post shutdown script.....Sleeping for ${SLEEP_DURATION} seconds"
sleep ${SLEEP_DURATION}

echo "Moving jar to bin, cleaning up, and changing location"
rm -rf /applications/common/bin/${APP_NAME}/${APP_NAME}.jar
cp /tmp/${APP_NAME}/${APP_NAME}*.jar /applications/common/bin/${APP_NAME}/${APP_NAME}.jar
rm -rf /tmp/${APP_NAME}

echo "Starting US Service"
# Remove "${DC_CODE}" if your app doesn't use Couchbase
sudo -u tomcat /applications/common/scripts/${DIR_NAME}/startup.sh

echo "Run health check against https://localhost:${US_PORT}${HEALTH_PATH}"
MAX_ATTEMPTS=12
for i in $(seq 1 $MAX_ATTEMPTS); do
    echo "waiting ${SLEEP_DURATION} seconds to allow for completion of startup of tomcat"
    sleep ${SLEEP_DURATION}
    echo "Calling health endpoint"
    US_RESPONSE_CODE=$(curl --silent -o /dev/null --insecure --max-time 10 --write-out %{http_code} -X GET https://localhost:${US_PORT}${HEALTH_PATH})
    echo "Got HTTP status response: [${US_RESPONSE_CODE}]"
    if [ "${US_RESPONSE_CODE}" == "200" ]; then
        echo "Service instance is up!"
        exit 0
    fi
done
echo "Health check still failing after ${MAX_ATTEMPTS} attempts, exiting deploy with unsuccessful status code"
exit 1