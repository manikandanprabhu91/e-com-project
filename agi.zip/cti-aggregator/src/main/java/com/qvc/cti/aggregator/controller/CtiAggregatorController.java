package com.qvc.cti.aggregator.controller;

import java.text.MessageFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.qvc.cti.aggregator.service.CtiAggregatorService;
import com.qvc.order.model.cti.CTISession;

/**
 * @author c004529
 *
 */
@RestController
@RequestMapping(value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/aggregator")
public class CtiAggregatorController {

  @Autowired
  private CtiAggregatorService ctiAggregatorService;

  private static final Logger logger =
      LoggerFactory.getLogger(CtiAggregatorController.class.getName());

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return boolean
   */
  @PostMapping(value = "/initiateTransfer", produces = "application/json",
      consumes = "application/json")
  public Boolean initiateTransfer(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob", required = false) String lob,
      @RequestBody final CTISession ctiSession) {
    final String methodName = "initiateTransfer";
    logger.info(MessageFormat.format(
        "{0}|In Initiate Transfer with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    return ctiAggregatorService.initiateTransfer(headers, version, countryCode, standardizeLob(lob),
        ctiSession);
  }


  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return void
   */
  @PostMapping(value = "/transferCall", produces = "application/json",
      consumes = "application/json")
  public ResponseEntity<Void> transferCall(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob", required = false) String lob,
      @RequestBody final CTISession ctiSession) {
    final String methodName = "transferCall";
    logger.info(MessageFormat.format(
        "{0}|In Transfer Call with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    ctiAggregatorService.transferCall(headers, version, countryCode, standardizeLob(lob),
        ctiSession);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param sessionId
   * @param ctiSession
   * @return CTISession
   */
  @PutMapping(value = "/session", produces = "application/json", consumes = "application/json")
  public ResponseEntity<CTISession> updateCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob", required = false) String lob,
      @RequestBody final CTISession ctiSession) {
    final String methodName = "updateCTISession";
    logger.info(MessageFormat.format(
        "{0}|In Update CTI Session with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    return new ResponseEntity<>(ctiAggregatorService.updateCTISession(headers, version, countryCode,
        standardizeLob(lob), ctiSession), HttpStatus.OK);
  }


  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param sessionId
   * @param ctiSession
   * @return CTISession
   */
  @DeleteMapping(value = "/session", produces = "application/json", consumes = "application/json")
  public ResponseEntity<CTISession> deleteCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob", required = false) String lob,
      @RequestBody final CTISession ctiSession) {
    final String methodName = "deleteCTISession";
    logger.info(MessageFormat.format(
        "{0}|In Delete CTI Session with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    return new ResponseEntity<>(ctiAggregatorService.deleteCTISession(headers, version, countryCode,
        standardizeLob(lob), ctiSession), HttpStatus.OK);
  }

  /**
   * Return first character of the lob value.
   *
   * @param lob the lob
   * @return the string
   */
  public String standardizeLob(String lob) {
    return Character.toString(lob.charAt(0)).toLowerCase();
  }

}
