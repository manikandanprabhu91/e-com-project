package com.qvc.cti.aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author c004529
 *
 */
@SpringBootApplication
@EnableFeignClients
public class CtiAggregatorApplication {
  public static void main(String[] args) {
    SpringApplication.run(CtiAggregatorApplication.class, args);
  }
}
