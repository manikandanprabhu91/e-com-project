package com.qvc.cti.aggregator.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import com.qvc.order.model.cti.CTISession;

/**
 * @author c004529
 *
 */
@FeignClient(name = "${spring.application.name}",
    url = "${aggregator.webservice.ctiAggregatorService.ctiAggregatorServiceHost}")
public interface CtiSessionProxy {

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return CTI Session object
   */
  @PostMapping(value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/session")
  CTISession createCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @RequestBody CTISession ctiSession);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param sessionId
   * @return CTI Session object
   */
  @GetMapping(
      value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/session/session-id/{sessionId}")
  CTISession findSessionBySessionId(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @PathVariable(name = "sessionId") String sessionId);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return CTI Session object
   */
  @PutMapping(value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/session")
  CTISession updateCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @RequestBody CTISession ctiSession);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return CTI Session object
   */
  @DeleteMapping(value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/session")
  CTISession deleteCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @RequestBody CTISession ctiSession);

}
