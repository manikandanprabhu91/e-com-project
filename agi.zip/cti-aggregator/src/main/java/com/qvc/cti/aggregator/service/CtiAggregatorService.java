package com.qvc.cti.aggregator.service;

import org.springframework.http.HttpHeaders;
import com.qvc.order.model.cti.CTISession;

/**
 * @author c004529
 *
 */
public interface CtiAggregatorService {

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   * @return boolean
   */
  Boolean initiateTransfer(HttpHeaders headers, String version, String countryCode,
      String standardizeLob, CTISession ctiSession);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   */
  void transferCall(HttpHeaders headers, String version, String countryCode, String standardizeLob,
      CTISession ctiSession);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   * @return CTI Session object
   */
  CTISession updateCTISession(HttpHeaders headers, String version, String countryCode,
      String standardizeLob, CTISession ctiSession);

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   * @return CTI Session object
   */
  CTISession deleteCTISession(HttpHeaders headers, String version, String countryCode,
      String standardizeLob, CTISession ctiSession);
}
