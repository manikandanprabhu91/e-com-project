package com.qvc.cti.aggregator.util;

public class UtilMethods {
  private UtilMethods() {

  }

  public static String generateShortErrorMessage(Throwable b) {
    return b.getClass().getName() + (b.getMessage() != null ? ": " + b.getMessage().trim() : "");
  }
}
