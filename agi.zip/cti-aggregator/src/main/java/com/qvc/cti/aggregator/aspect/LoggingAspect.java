package com.qvc.cti.aggregator.aspect;

import java.text.MessageFormat;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import com.qvc.cti.aggregator.util.UtilMethods;

/**
 * @author c004529
 *
 */

@Configuration
@Aspect
public class LoggingAspect {

  /** Logger */
  Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

  @Around(" execution(* com.qvc.cti.aggregator.controller.CtiAggregatorController.*(..)) || execution(* com.qvc.cti.aggregator.service.CtiAggregatorServiceImpl.*(..))")
  public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
    long methodStartTime = System.currentTimeMillis();
    String methodName = null;
    String simpleClassName = null;
    try {
      methodName = joinPoint.getSignature().getName();
      simpleClassName = joinPoint.getTarget().getClass().getSimpleName();
      return joinPoint.proceed();
    } catch (Throwable b) {
      logger.error(MessageFormat.format("Error while executing method: {0}, {1}",
          simpleClassName + "." + methodName, UtilMethods.generateShortErrorMessage(b)));
      throw b;
    } finally {
      logger.info("{}.{} | {} | Method completed ", simpleClassName, methodName,
          (System.currentTimeMillis() - methodStartTime) + "ms");
    }
  }
}
