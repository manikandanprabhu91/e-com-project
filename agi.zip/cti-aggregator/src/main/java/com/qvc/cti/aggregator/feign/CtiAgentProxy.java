package com.qvc.cti.aggregator.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import com.qvc.order.model.cti.Agent;

/**
 * @author c004529
 *
 */
@FeignClient(name = "cti-agent", url = "${cti.agent.hostUrl}")
public interface CtiAgentProxy {

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param exension
   * @return Agent object
   */
  @GetMapping(
      value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/agent/{exension}/extension")
  Agent getAgentByExtension(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @PathVariable(name = "exension") String exension);

}
