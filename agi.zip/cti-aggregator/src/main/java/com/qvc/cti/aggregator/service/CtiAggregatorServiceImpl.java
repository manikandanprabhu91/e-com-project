package com.qvc.cti.aggregator.service;

import java.text.MessageFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import com.qvc.cti.aggregator.feign.CtiAgentProxy;
import com.qvc.cti.aggregator.feign.CtiSessionProxy;
import com.qvc.order.model.cti.Agent;
import com.qvc.order.model.cti.CTISession;

@Service
public class CtiAggregatorServiceImpl implements CtiAggregatorService {

  @Autowired
  private CtiSessionProxy ctiSessionProxy;

  @Autowired
  private CtiAgentProxy ctiAgentProxy;

  private static final Logger logger =
      LoggerFactory.getLogger(CtiAggregatorServiceImpl.class.getName());

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   * @return boolean
   */
  @Override
  public Boolean initiateTransfer(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    final String methodName = "initiateTransfer";
    logger.info(MessageFormat.format(
        "{0}|In Initiate Transfer with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    CTISession initiateTransfer =
        ctiSessionProxy.createCTISession(headers, version, countryCode, lob, ctiSession);
    return initiateTransfer != null;
  }

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   */
  @Override
  public void transferCall(HttpHeaders headers, String version, String countryCode, String lob,
      CTISession ctiSession) {
    final String methodName = "transferCall";
    logger.info(MessageFormat.format(
        "{0}|In Transfer Call with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    CTISession ctiSessionResponse = ctiSessionProxy.findSessionBySessionId(headers, version,
        countryCode, lob, ctiSession.getSessionId());
    if (ctiSessionResponse != null) {
      Agent agent = ctiAgentProxy.getAgentByExtension(headers, version, countryCode, lob,
          ctiSession.getCallInfo().getExtension());
      if (agent != null) {
        ctiSessionResponse.setAgentId(agent.getAgentId());
        updateCTISession(headers, version, countryCode, lob, ctiSessionResponse);
      }
    }
  }

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param standardizeLob
   * @param ctiSession
   * @return CTI Session object
   */
  @Override
  public CTISession updateCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    final String methodName = "updateCTISession";
    logger.info(MessageFormat.format(
        "{0}|In Update CTI Session with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    return ctiSessionProxy.updateCTISession(headers, version, countryCode, lob, ctiSession);
  }

  /**
   * @param headers
   * @param version
   * @param countryCode
   * @param lob
   * @param ctiSession
   * @return CTI Session object
   */
  @Override
  public CTISession deleteCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    final String methodName = "deleteCTISession";
    logger.info(MessageFormat.format(
        "{0}|In Delete CTI Session with version [{1}], countryCode [{2}], lob [{3}]", methodName,
        version, countryCode, lob));
    return ctiSessionProxy.deleteCTISession(headers, version, countryCode, lob, ctiSession);
  }

}
