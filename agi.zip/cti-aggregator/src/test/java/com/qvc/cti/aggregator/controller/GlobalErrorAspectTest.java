package com.qvc.cti.aggregator.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.qvc.cti.aggregator.aspect.ApiError;
import com.qvc.cti.aggregator.aspect.GlobalErrorAspect;
import com.qvc.cti.aggregator.aspect.NoConnectionToServiceException;
import com.qvc.cti.aggregator.service.CtiAggregatorService;
import feign.FeignException;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
public class GlobalErrorAspectTest {

  private MockMvc mvc;

  @InjectMocks
  private CtiAggregatorController ctiAggregatorController;

  @MockBean
  private CtiAggregatorService ctiAggregatorService;

  public static final String INITIATE_TRANSFER =
      "/order-flow/order-capture/v1/US/q/cti/aggregator/initiateTransfer";

  private NoConnectionToServiceException noConnectionToServiceException;

  public static final String MESSAGE = "$.message";

  public static final String STATUS = "$.status";

  private ApiError apiError;

  private ApiError apiErrorContructorParams;

  String input = null;

  HttpHeaders headers;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    headers = new HttpHeaders();
    headers.add("Content-Type", "application/json; charset=utf-8");
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("User-Agent", "postman");
    String errors[] = {"404", "500", "410"};
    apiError = new ApiError();
    apiError.setStatus(HttpStatus.ACCEPTED);
    apiError.setMessage(MESSAGE);
    apiError.setErrors(errors);
    mvc = MockMvcBuilders.standaloneSetup(ctiAggregatorController)
        .setControllerAdvice(new GlobalErrorAspect()).build();
    apiErrorContructorParams = new ApiError(HttpStatus.ACCEPTED, MESSAGE, errors);
    this.noConnectionToServiceException = new NoConnectionToServiceException(
        new Exception("No Connection to Cti Aggregator application"));
    input =
        "{  \"sessionId\": \"0001\", \"callInfo\": {\"extension\": \"415212\"},\"agentId\": \"c007152\"  }";
  }

  /**
   * Test http client error exception.
   * 
   * @throws Exception
   */
  @Test
  public void testHttpClientErrorException() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
    MockHttpServletResponse response =
        mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
  }

  /**
   * Test http media type not acceptable exception.
   * 
   * @throws Exception
   */
  @Test
  public void testHttpMediaTypeNotAcceptableException() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_OCTET_STREAM).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_ACCEPTABLE.value());
  }

  /**
   * Test http media type not supported exception.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHttpMediaTypeNotSupportedException() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_OCTET_STREAM)
            .accept(MediaType.APPLICATION_OCTET_STREAM).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value());
  }

  /**
   * Test handle http request method not supported.
   * 
   * @throws Exception
   */
  @Test
  public void testHttpRequestMethodNotSupported() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(get(INITIATE_TRANSFER).accept(MediaType.APPLICATION_JSON)).andReturn()
            .getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED.value());
  }

  /**
   * Test hystrix runtime exception.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testHystrixRuntimeException() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(HystrixRuntimeException.class);
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(MESSAGE, is("Error occurred")))
        .andExpect(jsonPath(STATUS, is(HttpStatus.BAD_REQUEST.name())));
  }

  /**
   * Test no connection to service exception.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testNoConnectionToServiceException() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(noConnectionToServiceException);
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(STATUS, is(HttpStatus.SERVICE_UNAVAILABLE.name())));
  }

  /**
   * Test cti aggregator service unavailable.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testCtiAggregatorServiceUnavailable() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(noConnectionToServiceException);
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input)).andExpect(status().is5xxServerError());
  }

  /**
   * Test http status code exception.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testHttpStatusCodeException() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(new HttpStatusCodeException(HttpStatus.CONFLICT) {
          private static final long serialVersionUID = -7352111074196509737L;
        });
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(MESSAGE, is("Error occurred")))
        .andExpect(jsonPath(STATUS, is(HttpStatus.CONFLICT.name())));
  }

  /**
   * Test http status code exception.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testHttpStatusCodeExceptionWhenHttpHeaderNotNull() throws Exception {
    Mockito
        .when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any()))
        .thenThrow(new HttpStatusCodeException(HttpStatus.CONFLICT, null, headers, null, null) {
          private static final long serialVersionUID = -7352111074196509737L;
        });
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(MESSAGE, is("Error occurred")))
        .andExpect(jsonPath(STATUS, is(HttpStatus.CONFLICT.name())));
  }

  /**
   * Test http status code lessthan 400 exception.
   * 
   * @throws Exception the exception
   */
  @Test
  public void testHttpStatusCodeExceptionStatusCodeLessthan400() throws Exception {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenThrow(new HttpStatusCodeException(HttpStatus.MOVED_PERMANENTLY) {
          private static final long serialVersionUID = -7352111074196509737L;
        });
    mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(MESSAGE, is("Error occurred")))
        .andExpect(jsonPath(STATUS, is(HttpStatus.BAD_REQUEST.name())));
  }

  /**
   * Test feign exception for Get Agent By Extension
   *
   * @throws Exception the exception
   */
  @Test
  public void testFeignExceptionForGetAgentByExtension() throws Exception {

    byte[] content = "error".getBytes();
    Mockito
        .when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any()))
        .thenThrow(new FeignException(404,
            "Received no agent in response from cti-session application", content) {
          private static final long serialVersionUID = 1L;
        });
    MockHttpServletResponse response =
        mvc.perform(post(INITIATE_TRANSFER).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(404);
  }

}
