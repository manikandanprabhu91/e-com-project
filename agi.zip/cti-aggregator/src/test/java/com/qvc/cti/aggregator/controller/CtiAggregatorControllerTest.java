package com.qvc.cti.aggregator.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.qvc.cti.aggregator.aspect.LoggingAspect;
import com.qvc.cti.aggregator.cofig.ServletContainerCustomizer;
import com.qvc.cti.aggregator.service.CtiAggregatorService;
import com.qvc.cti.aggregator.util.UtilMethods;
import com.qvc.order.model.cti.CTISession;
import com.qvc.order.model.cti.CallInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@WebMvcTest(value = CtiAggregatorController.class, secure = false)
@ActiveProfiles("test")
public class CtiAggregatorControllerTest {
  @Autowired
  private CtiAggregatorController ctiAggregatorController;

  @MockBean
  private CtiAggregatorService ctiAggregatorService;

  private ServletContainerCustomizer customizer;

  HttpHeaders headers;

  private LoggingAspect loggingAspect;

  @Rule
  public MockitoRule mockitoRule = MockitoJUnit.rule();

  @Mock
  private ProceedingJoinPoint proceedingJoinPoint;

  private CTISession ctiSession;

  private CallInfo callInfo;

  public static final String VERSON = "v1";
  public static final String COUNTRY_CODE = "us";
  public static final String LINE_OF_BUSSINESS = "qvc";

  @Before
  public void setUp() {
    headers = new HttpHeaders();
    headers.add("Content-Type", "application/json; charset=utf-8");
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("User-Agent", "postman");
    customizer = new ServletContainerCustomizer();
    customizer.customize(new TomcatServletWebServerFactory());
    loggingAspect = new LoggingAspect();
    ctiSession = new CTISession();
    callInfo = new CallInfo();
    ctiSession.setAgentId("c004529");
    ctiSession.setSessionId("1234");
    ctiSession.setCartGuid("001");
    callInfo.setCallDay("Friday");
    callInfo.setExtension("4529");
    ctiSession.setCallInfo(callInfo);
  }

  @Test(expected = NullPointerException.class)
  public void testLoggingAspect() throws Throwable {
    Mockito.when(proceedingJoinPoint.getSignature()).thenReturn(null);
    loggingAspect.logAround(proceedingJoinPoint);
  }

  @Test
  public void testLogginAspectProceed() throws Throwable {
    MethodSignature signature = mock(MethodSignature.class);
    Mockito.when(proceedingJoinPoint.getTarget()).thenReturn(ctiAggregatorController);
    Mockito.when(proceedingJoinPoint.getSignature()).thenReturn(signature);
    Mockito.when(signature.getName()).thenReturn("Sample");
    loggingAspect.logAround(proceedingJoinPoint);
  }

  @Test
  public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException,
      InvocationTargetException, InstantiationException {
    Constructor<UtilMethods> constructor = UtilMethods.class.getDeclaredConstructor();
    Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
    constructor.setAccessible(true);
    constructor.newInstance();
  }

  @Test
  public void testUtilMethodGenerateShortErrorMessage() {
    assertEquals(new Throwable() + "", UtilMethods.generateShortErrorMessage(new Throwable()));
    assertEquals(new Throwable("message") + "",
        UtilMethods.generateShortErrorMessage(new Throwable("message")));
  }

  @Test
  public void initiateTransferReturnValueTrueTest() {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(true);
    Assert.assertEquals(true, ctiAggregatorController.initiateTransfer(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void initiateTransferReturnValueFalseTest() {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(false);
    Assert.assertEquals(false, ctiAggregatorController.initiateTransfer(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void initiateTransferReturnValueMismatchTest() {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(true);
    Assert.assertNotEquals(false, ctiAggregatorController.initiateTransfer(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void initiateTransferReturnValueNullTest() {
    Mockito.when(ctiAggregatorService.initiateTransfer(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(null);
    Assert.assertEquals(null, ctiAggregatorController.initiateTransfer(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void transferCallTest() {
    doNothing().when(ctiAggregatorService).transferCall(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any());
    Assert.assertEquals(new ResponseEntity<>(HttpStatus.OK), ctiAggregatorController
        .transferCall(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void updateCTISessionTest() {
    Mockito.when(ctiAggregatorService.updateCTISession(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(ctiSession);
    Assert.assertEquals(new ResponseEntity<>(ctiSession, HttpStatus.OK), ctiAggregatorController
        .updateCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void deleteCTISessionTest() {
    Mockito.when(ctiAggregatorService.deleteCTISession(Mockito.any(HttpHeaders.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class),
        Mockito.any())).thenReturn(ctiSession);
    Assert.assertEquals(new ResponseEntity<>(ctiSession, HttpStatus.OK), ctiAggregatorController
        .deleteCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }
}
