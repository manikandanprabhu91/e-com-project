package com.qvc.cti.aggregator.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.qvc.cti.aggregator.feign.CtiAgentProxy;
import com.qvc.cti.aggregator.feign.CtiSessionProxy;
import com.qvc.order.model.cti.Agent;
import com.qvc.order.model.cti.CTISession;
import com.qvc.order.model.cti.CallInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@ActiveProfiles("test")
public class CtiAggregatorServiceTest {

  @Autowired
  private CtiAggregatorService ctiAggregatorService;

  @MockBean
  private CtiSessionProxy ctiSessionProxy;

  @MockBean
  private CtiAgentProxy ctiAgentProxy;

  HttpHeaders headers;

  private CTISession ctiSession;

  private CallInfo callInfo;

  private Agent agent;

  public static final String VERSON = "v1";
  public static final String COUNTRY_CODE = "us";
  public static final String LINE_OF_BUSSINESS = "qvc";

  @Before
  public void setUp() {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-type", "application/json");
    ctiSession = new CTISession();
    agent = new Agent();
    callInfo = new CallInfo();
    ctiSession.setAgentId("c004529");
    ctiSession.setSessionId("1234");
    ctiSession.setCartGuid("001");
    callInfo.setCallDay("Friday");
    callInfo.setExtension("4529");
    ctiSession.setCallInfo(callInfo);
    agent.setAgentId("123456");
  }

  @Test
  public void initiateTransferReturnTrueTest() {
    Mockito.when(ctiSessionProxy.createCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession)).thenReturn(ctiSession);
    Assert.assertEquals(true, ctiAggregatorService.initiateTransfer(headers, VERSON, COUNTRY_CODE,
        LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void initiateTransferReturnFalseTest() {
    Mockito.when(ctiSessionProxy.createCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession)).thenReturn(null);
    Assert.assertEquals(false, ctiAggregatorService.initiateTransfer(headers, VERSON, COUNTRY_CODE,
        LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void transferCallTest() {
    Mockito.when(ctiSessionProxy.findSessionBySessionId(headers, VERSON, COUNTRY_CODE,
        LINE_OF_BUSSINESS, ctiSession.getSessionId())).thenReturn(ctiSession);
    Mockito.when(ctiAgentProxy.getAgentByExtension(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession.getCallInfo().getExtension())).thenReturn(agent);
    ctiAggregatorService.transferCall(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession);
  }

  @Test
  public void transferCallReturnsNullAgentObjectTest() {
    Mockito.when(ctiSessionProxy.findSessionBySessionId(headers, VERSON, COUNTRY_CODE,
        LINE_OF_BUSSINESS, ctiSession.getSessionId())).thenReturn(ctiSession);
    Mockito.when(ctiAgentProxy.getAgentByExtension(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession.getCallInfo().getExtension())).thenReturn(null);
    ctiAggregatorService.transferCall(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession);
  }

  @Test
  public void transferCallReturnsNullCtiSessionObjectTest() {
    Mockito.when(ctiSessionProxy.findSessionBySessionId(headers, VERSON, COUNTRY_CODE,
        LINE_OF_BUSSINESS, ctiSession.getSessionId())).thenReturn(null);
    Mockito.when(ctiAgentProxy.getAgentByExtension(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession.getCallInfo().getExtension())).thenReturn(agent);
    ctiAggregatorService.transferCall(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession);
  }

  @Test
  public void updateCTISessionTest() {
    Mockito.when(ctiSessionProxy.updateCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession)).thenReturn(ctiSession);
    Assert.assertEquals(ctiSession, ctiAggregatorService.updateCTISession(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }

  @Test
  public void deleteCTISessionTest() {
    Mockito.when(ctiSessionProxy.deleteCTISession(headers, VERSON, COUNTRY_CODE, LINE_OF_BUSSINESS,
        ctiSession)).thenReturn(ctiSession);
    Assert.assertEquals(ctiSession, ctiAggregatorService.deleteCTISession(headers, VERSON,
        COUNTRY_CODE, LINE_OF_BUSSINESS, ctiSession));
  }
}
