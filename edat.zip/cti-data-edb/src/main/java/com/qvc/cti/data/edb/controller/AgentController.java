package com.qvc.cti.data.edb.controller;

import java.security.Principal;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

import javax.validation.Valid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.coast.web.client.error.ApiException.ErrorCode;
import com.qvc.coast.web.client.error.BadRequestException;
import com.qvc.cti.data.edb.service.AgentService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping(value = "/order/management/v1/{countryCode}/{lob}/cti/agent", produces = MediaType.APPLICATION_JSON_VALUE)
public class AgentController {

	AgentService agentService;
	
	private static final String NOT_AUTHENTICATED = " User Not Authenticated";

	@PostMapping(value = "/cms", 
			produces = { "application/json", "application/xml" }, 
			consumes = { "application/json", "application/xml" })
	public ResponseEntity<List<EAgent>> createAgents(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@RequestBody final @Valid List<EAgent> agents,
			Principal principal) {
		final String classMethodName = "AgentController.createAgents";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		log.info("{}|Creating EAgents.Requested user is: {}", classMethodName, principal.getName());
		Assert.notNull(agents, "The Agent request payload cannot be null");
		return new ResponseEntity<>(agentService.createAgents(agents, countryCode, lob), HttpStatus.CREATED);
	}
	
	@PostMapping(value = "/login-id", 
			produces = { "application/json", "application/xml" }, 
			consumes = { "application/json", "application/xml" })
	public ResponseEntity<List<EAgentLdap>> createAgentLdaps(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@RequestBody final @Valid List<EAgentLdap> agentLdaps,
			Principal principal) {
		
		final String classMethodName = "AgentController.createAgentLdaps";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		log.info("{}|Creating EAgentLdaps.Requested user is: {}", classMethodName, principal.getName());
		Assert.notNull(agentLdaps, "The AgentLdap request payload cannot be null");
		agentLdaps.stream().filter(agentLdap -> {
			boolean isLdapIdEmpty= StringUtils.isNotBlank(agentLdap.getLdapId());
			if(!isLdapIdEmpty){
				throw new BadRequestException(ErrorCode.PARAMETER_INVALID, "Payload missing mandatory ldapId field");
			}
			return isLdapIdEmpty;
		   }).forEach(agent -> {agent.setOperationalCountryCode(countryCode);agent.setLineOfBusiness(lob);});
		return new ResponseEntity<>(agentService.createAgentLdaps(agentLdaps), HttpStatus.CREATED);
	}
	
	@GetMapping(value = "/agent-id/{agentId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<EAgent> findAgentByAgentId(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@PathVariable String agentId,
			Principal principal) {
		
		final String classMethodName = "AgentController.findAgentByAgentId";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		log.info("{}|Finding EAgent by agentId: {}.Requested user is: {}", classMethodName, agentId, principal.getName());
		return new ResponseEntity<>(agentService.findByAgentId(countryCode, lob, agentId), HttpStatus.OK);
	}	
	
	@GetMapping(value = "/login-id/{windowId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<EAgent> findAgentByLdapId(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@PathVariable String windowId,
			Principal principal) {
		
		final String classMethodName = "AgentController.findAgentByLdapId";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		log.info("{}|Finding EAgent by ldapid: {} .Requested user is: {}", classMethodName, windowId, principal.getName());
		return new ResponseEntity<>(agentService.findAgentByLdapId(countryCode, lob, windowId), HttpStatus.OK);
	}	
	
	@GetMapping(value = "/extension/{extensionId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<EAgent> findAgentByExtension(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@PathVariable String extensionId,
			Principal principal) {
		
		final String classMethodName = "AgentController.findAgentByExtension";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		log.info("{}|Finding EAgent by extension: {} .Requested user is: {}", classMethodName, extensionId, principal.getName());
		return new ResponseEntity<>(agentService.findAgentByExtension(countryCode, lob, extensionId), HttpStatus.OK);
	}	
	
	@PutMapping(value="/login-id/{windowId}", 
			produces = { "application/json", "application/xml" }, 
			consumes = { "application/json", "application/xml" })
	public ResponseEntity<EAgent> updateAgent(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@PathVariable String windowId, 
			@RequestBody final EAgent agent,
			Principal principal) {
		
		final String classMethodName="AgentController.updateAgent";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		Assert.notNull(agent, "The agent request payload cannot be null");
		agent.setOperationalCountryCode(countryCode);
		agent.setLineOfBusiness(lob);
		if(StringUtils.isNotBlank(agent.getLdapId()) && !agent.getLdapId().equalsIgnoreCase(windowId)) {
			throw new BadRequestException(ErrorCode.PARAMETER_INVALID, "Payload ldapId is "+agent.getLdapId()+" and URL has "+windowId);
		}
		log.info("{}|Updating EAgent by using ldapId {} .Requested user is: {}",classMethodName, windowId,principal.getName());
		return new ResponseEntity<>(agentService.updateAgent(agent,windowId), HttpStatus.OK);
	}
	
	@DeleteMapping(value="/cms", 
			produces = { "application/json", "application/xml" },
			consumes = { "application/json", "application/xml" })
	public ResponseEntity<EAgent> deleteAgent(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@RequestBody final EAgent agent,
			Principal principal) {
		
		final String classMethodName="AgentController.deleteAgent";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		Assert.notNull(agent, "The agent request payload cannot be null");
		Assert.notNull(agent.getAgentId(), "Payload missing mandatory agentId field");
		agent.setOperationalCountryCode(countryCode);
		agent.setLineOfBusiness(lob);
		log.info("{}|Deleting Agent using agentId: {}.Requested user is: {}",classMethodName,agent.getLdapId(), principal.getName());
		return new ResponseEntity<>(agentService.deleteAgent(agent),HttpStatus.OK);
	}

	@DeleteMapping(value="/login-id", 
			produces = { "application/json", "application/xml" },
			consumes = { "application/json", "application/xml" })
	public ResponseEntity<List<EAgentLdap>> deleteAgentLdaps(@RequestHeader HttpHeaders headers, 
			@PathVariable String countryCode,
			@PathVariable String lob, 
			@RequestBody final List<EAgentLdap> agentLdaps,
			Principal principal) {
		
		final String classMethodName="AgentController.deleteAgentLdaps";
		Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
		Assert.notNull(agentLdaps, "The agentLdap request payload cannot be null");
		agentLdaps.stream().filter(agentLdap -> {
			boolean isLdapIdEmpty= StringUtils.isNotBlank(agentLdap.getLdapId());
			if(!isLdapIdEmpty){
				throw new BadRequestException(ErrorCode.PARAMETER_INVALID, "Payload missing mandatory ldapId field");
			}
			return isLdapIdEmpty;
		   }).forEach(agent -> {agent.setOperationalCountryCode(countryCode);agent.setLineOfBusiness(lob);});
		return new ResponseEntity<>(agentService.deleteAgentLdaps(agentLdaps), HttpStatus.OK);
	}
	
    @GetMapping(value="/ldap-agent/{agentId}",produces = {"application/json","application/xml"})
    public ResponseEntity<ELdapAgent> findLdapAgentByAgentId(@RequestHeader HttpHeaders headers,
            @PathVariable String countryCode,
            @PathVariable String lob,
            @PathVariable String agentId,
            Principal principal){
      final String classMethodName = "AgentController.findLdapAgentByAgentId";
      Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
      log.info("{}|Finding ELdapAgent by agentId: {}.Requested user is: {}", classMethodName, agentId, principal.getName());
      return new ResponseEntity<>(agentService.findLdapAgentByAgentId(countryCode, lob, agentId),HttpStatus.OK);
      
    }
    
    @GetMapping(value="/agent-ldap/{ldapId}",produces = {"application/json","application/xml"})
    public ResponseEntity<EAgentLdap> findAgentLdapByLdapId(@RequestHeader HttpHeaders headers,
            @PathVariable String countryCode,
            @PathVariable String lob,
            @PathVariable String ldapId,
            Principal principal){
      final String classMethodName = "AgentController.findAgentLdapByLdapId";
      Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
      log.info("{}|Finding EAgentLdap by ldapId: {}.Requested user is: {}", classMethodName, ldapId, principal.getName());
      return new ResponseEntity<>(agentService.findAgentLdapByLdapId(countryCode, lob, ldapId),HttpStatus.OK);
      
    }   
}
	