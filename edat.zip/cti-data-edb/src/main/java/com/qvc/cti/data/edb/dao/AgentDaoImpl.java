package com.qvc.cti.data.edb.dao;

import java.util.Date;
import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;

import com.qvc.coast.edb.data.transformer.cti.CTIBase;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.cti.data.edb.config.EdbCouchbaseRepository;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;

@Slf4j
@Service
@AllArgsConstructor
public class AgentDaoImpl implements AgentDao {
	
	PropertiesConfig config;
	EdbCouchbaseRepository edbCouchbaseRepository;
	DozerBeanMapper dozerBeanMapper;
	private CouchbaseUtils couchbaseUtils;
	
	@Override
	public EAgent createOrUpdateAgent(final EAgent agent, String userName) {
		final String classMethodName="AgentDaoImpl.createOrUpdateAgent";	
		String id = couchbaseUtils.getId(new EAgent(config.getAgentType(),agent.getOperationalCountryCode(), agent.getLineOfBusiness(), agent.getAgentId()), EAgent.class);
		EAgent agentDoc =  this.findById(id,EAgent.class).orElseGet(EAgent::new);
		//If the agent doc was found and the extension differs from the doc passed in, then update couch
		if (StringUtils.isBlank(agentDoc.getExtension()) || 
		    (StringUtils.isNotBlank(agentDoc.getExtension()) && !agentDoc.getExtension().equals(agent.getExtension()))) {
		  mergeAgentDocs(agent, agentDoc);
  		setCommonAgentAttributes(agent, new Date(), userName);
  		agent.setType(config.getAgentType());
  		log.info("{}|Creating/Updating EAgent using agentId: {} with expiry:{}", classMethodName,agent.getAgentId(), config.getExpiry());
  		EAgent responseAgent = edbCouchbaseRepository.upsert(agent, EAgent.class, config.getExpiry());
  		log.info("{}|Created/Updated EAgent using agentId:{} and expiry:{}", classMethodName, responseAgent.getAgentId(),config.getExpiry());	
  		if(StringUtils.isNotBlank(agent.getExtension())){
  			EAgentExtension agentExtension=toAgentExtension(agent);
  			agentExtension.setType(config.getAgentExtensionType());
  			log.info("{}|Creating/Updating EAgentExtension using extension:{} with expiry time: {}", classMethodName,
  					agentExtension.getExtension(), config.getExpiry());
  			Optional.ofNullable(edbCouchbaseRepository.upsert(agentExtension, EAgentExtension.class, config.getExpiry()))
  			.ifPresent(eAgentExtension -> log.info("{}|Created/Updated EAgentExtension using extension:{}",
  					classMethodName, eAgentExtension.getExtension()));
  		}else{
  			log.warn("{}|Agent {} is not associated with extension {} ",classMethodName,agent.getAgentId());
  		}
  		return responseAgent;
		} else {
		  return agentDoc;
		}
	}

	@Override
	public EAgentLdap createOrUpdateAgentLdap(EAgentLdap agentLdap, String userName) {
		final String classMethodName = "AgentDaoImpl.createOrUpdateAgentLdap";
		setCommonAgentAttributes(agentLdap, new Date(), userName);
		agentLdap.setType(config.getAgentLdapType());
		log.info("{}|Creating/Updating EAgentLdap using ldapId:{}", classMethodName,agentLdap.getLdapId());
		Optional.ofNullable(edbCouchbaseRepository.upsert(agentLdap, EAgentLdap.class))
				.ifPresent(eEAgentLdap -> log.info("{}|Created/Updated EAgentLdap using ldapId:{}",
						classMethodName, eEAgentLdap.getLdapId()));
		ELdapAgent ldapAgent=toLdapAgent(agentLdap);
		ldapAgent.setType(config.getLdapAgentType());
		log.info("{}|Creating/Updating ELdapAgent using AgentId:{}", classMethodName, agentLdap.getAgentId());
		Optional.ofNullable(edbCouchbaseRepository.upsert(ldapAgent, ELdapAgent.class))
    .ifPresent(eLdapEAgent -> log.info("{}|Created/Updated ELdapAgent using AgentId:{}",
        classMethodName, eLdapEAgent.getAgentId()));
		return agentLdap;
    }
	
	@Override
	public EAgentExtension createAgentExtension(EAgentExtension agentExtension, String userName) {
		final String classMethodName = "AgentDaoImpl.createAgentExtension";
		setCommonAgentAttributes(agentExtension, new Date(), userName);
		agentExtension.setType(config.getAgentExtensionType());
		log.info("{}|Creating/Updating EAgentExtension using extension:{}", classMethodName,agentExtension.getExtension());
		Optional.ofNullable(edbCouchbaseRepository.create(agentExtension, EAgentExtension.class))
				.ifPresent(eAgentExtension -> log.info("{}|Created/Updated EAgentExtension using extension:{}",
						classMethodName, eAgentExtension.getExtension()));
		return agentExtension;
	}

	@Override
	public EAgent updateAgent(EAgent agent, String userName) {
		final String classMethodName = "AgentDaoImpl.updateAgent";
		setCommonAgentAttributes(agent, new Date(), userName);	
		agent.setType(config.getAgentType());
		log.info("{}| Updating EAgent using agentId:{}", classMethodName,agent.getAgentId());
		Optional.ofNullable(edbCouchbaseRepository.update(agent, EAgent.class))
				.ifPresent(eEAgent -> log.info("{}| Updated EAgent using agentId:{}",
						classMethodName, eEAgent.getAgentId()));
		return agent;
    }
	
	@Override
	public <T> Optional<T> findById(String id, Class<T> type){
		return edbCouchbaseRepository.findById(id, type);
	}
	@Override
	public <T> T  delete(T entity, Class<T> type){
		edbCouchbaseRepository.delete(entity, type);
		return entity;
	}

	private  EAgentExtension toAgentExtension(EAgent agent){
		EAgentExtension eAgentExtension = dozerBeanMapper.map(agent, EAgentExtension.class);
		eAgentExtension.setId(null);
		return eAgentExtension;	
	}
	
	private  ELdapAgent toLdapAgent(EAgentLdap agentLdap){
    ELdapAgent eLdapAgent = dozerBeanMapper.map(agentLdap, ELdapAgent.class);
    eLdapAgent.setId(null);
    return eLdapAgent; 
	}
	
	private EAgent mergeAgentDocs(EAgent newAgent, EAgent existingAgent) {
	  newAgent.setLdapId(existingAgent.getLdapId());
	  newAgent.setIpAddress(existingAgent.getIpAddress());
	  newAgent.setWebSocketId(existingAgent.getWebSocketId());
	  
	  return newAgent;
	}
	
	private void setCommonAgentAttributes(final CTIBase agent, Date date, String principalName) {
		if (StringUtils.isEmpty(config.getDocumentVersion())) {
			agent.setDocumentVersion(config.getDocumentVersion());
		}
		agent.setLastUpdateProgramName(config.getAppName());
		agent.setLastUpdateDBUserId(config.getClusterUsername());
		agent.setLastUpdateApplicationUserId(config.getBucketName());
		agent.setLastUpdatePrincipalName(principalName);
		agent.setLastUpdateTimeStamp(date);		
	}
}
