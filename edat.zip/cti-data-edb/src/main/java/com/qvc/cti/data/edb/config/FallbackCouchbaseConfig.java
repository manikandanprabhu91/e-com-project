package com.qvc.cti.data.edb.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "fallbackcouchbase")
@Getter
@Setter
public class FallbackCouchbaseConfig extends CouchbaseProperties {
	
	@Value("#{'${fallbackcouchbase.bootstrap-hosts}'.split(',')}")
	private List<String> fallbackBootstrapHosts;
	
	@Value("${fallbackcouchbase.cluster.username}")
	private String fallbackClusterUsername;

	@Value("${fallbackcouchbase.cluster.password}")
	private String fallbackClusterPassword;
	
	@Value("${fallbackcouchbase.bucket.name}")
	private String fallbackBucketName;

}
