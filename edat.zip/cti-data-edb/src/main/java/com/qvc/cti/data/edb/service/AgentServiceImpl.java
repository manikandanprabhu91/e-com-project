package com.qvc.cti.data.edb.service;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.commons.lang.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.coast.web.client.error.ApiException.ErrorCode;
import com.qvc.coast.web.client.error.BadRequestException;
import com.qvc.coast.web.client.error.DataNotFoundException;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.cti.data.edb.dao.AgentDao;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class AgentServiceImpl implements AgentService {

	private AgentDao agentDao;
	private CouchbaseUtils couchbaseUtils;
	private PropertiesConfig config;
	
	@Autowired
	private	DozerBeanMapper dozerBeanMapper;
	
	@Override
	public List<EAgent> createAgents(final List<EAgent> agents, String countryCode, String lob) {
		final String classMethodName="AgentServiceImpl.createAgents";
		log.info("{}|Creating agents in edb", classMethodName);
		final String userName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

		List<EAgent> eAgents =
				agents
					.stream()
					.unordered()
					.map(eAgent -> {
						if(org.apache.commons.lang3.StringUtils.isBlank(eAgent.getAgentId())) {
							throw new BadRequestException(ErrorCode.PARAMETER_INVALID, "Payload missing mandatory agentId field");
						}
						eAgent.setOperationalCountryCode(countryCode);
						eAgent.setLineOfBusiness(lob);
						return agentDao.createOrUpdateAgent(eAgent, userName);
					}).filter(eAgent -> eAgent!=null)
					.collect(Collectors.toList());
		if(eAgents.isEmpty()) {
          throw new BadRequestException(ErrorCode.PARAMETER_INVALID,"Could not create Agent document because AgentLdap relation was not found for agent ");
        }
		return eAgents;
	}
	

	@Override
	public List<EAgentLdap> createAgentLdaps(List<EAgentLdap> agentLdaps) {
		final String classMethodName="AgentServiceImpl.createAgentLdaps";
		log.info("{}|Creating agentLdaps in edb", classMethodName);
		final String userName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();
		return agentLdaps.stream().map(agentLdap-> agentDao.createOrUpdateAgentLdap(agentLdap, userName)).collect(Collectors.toList());
	}
	
	@Override
	public EAgent findByAgentId(final String countryCode, final String lob, final String agentId) {
		final String classMethodName="AgentServiceImpl.findByAgentId";		
		String id = couchbaseUtils.getId(new EAgent(config.getAgentType(), countryCode, lob, agentId), EAgent.class);
		return agentDao.findById(id,EAgent.class).orElseThrow(()->{
			log.info("{}| EAgent document not found for docId: {}", classMethodName, id);
			return new DataNotFoundException("EAgent document not found for agentId: " + agentId);
		});		
	}	
	
	@Override
	public EAgent findAgentByLdapId(final String countryCode, final String lob, final String ldapId) {
		final String classMethodName="AgentServiceImpl.findAgentByLdapId";		
		String id = couchbaseUtils.getId(new EAgentLdap(config.getAgentLdapType(), countryCode, lob, ldapId), EAgentLdap.class);
		EAgentLdap agentLdap =  agentDao.findById(id,EAgentLdap.class).orElseThrow(()->{
			log.info("{}| EAgentLdap document not found for docId: {}", classMethodName, id);
			return new DataNotFoundException("EAgentLdap document not found for ldapId: " + ldapId);
		});
		log.info("{}| EAgentLdap document found for ldapId: {}.Fetching EAgent document by using agentId: {} ",
				                                   classMethodName, ldapId,agentLdap.getAgentId());
		return findByAgentId(countryCode,lob,agentLdap.getAgentId());
	}

	@Override
	public EAgent findAgentByExtension(final String countryCode, final String lob,final String extension) {
		final String classMethodName="AgentServiceImpl.findAgentByExtension";		
		String id = couchbaseUtils.getId(new EAgentExtension(config.getAgentExtensionType(), countryCode, lob, extension), EAgentExtension.class);
		EAgentExtension agentExtension =  agentDao.findById(id,EAgentExtension.class).orElseThrow(()->{
			log.info("{}| EAgentExtension document not found for docId: {}", classMethodName, id);
			return new DataNotFoundException("EAgentExtension document not found for extension: " + extension);
		});
		log.info("{}| EAgentExtension document found for extension: {}.Fetching EAgent document by using agentId: {} ",
				                                   classMethodName, extension,agentExtension.getAgentId());
		return findByAgentId(countryCode,lob,agentExtension.getAgentId());
	}
		
	@Override
	public EAgent updateAgent(EAgent agent,String ldapId) {
		final String classMethodName="AgentServiceImpl.updateAgent";
		final String userName = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();
		log.info("{}|Updating agent for agentId: {} ", classMethodName,agent.getAgentId());
		return agentDao.updateAgent(agent, userName);
	}
	
	@Override
	public EAgent deleteAgent(EAgent agent) {
		final String classMethodName="AgentServiceImpl.deleteAgent";
		log.info("{}|Deleting agent by using agentId: {} ", classMethodName,agent.getAgentId());
		agent.setType(config.getAgentType());
		agentDao.delete(agent,EAgent.class);
		if(StringUtils.isNotBlank(agent.getExtension())){
			String id = couchbaseUtils.getId(new EAgentExtension(config.getAgentExtensionType(), agent.getOperationalCountryCode(), 
					 agent.getLineOfBusiness(), agent.getExtension()), EAgentExtension.class);
			 agentDao.findById(id,EAgentExtension.class).ifPresent(agentExtension->{
				 log.info("{}|Deleting EAgentExtension by using extension: {} ", classMethodName,agentExtension.getExtension());
				 agentDao.delete(agentExtension,EAgentExtension.class);
			 });
		}else{
			log.warn("{}| Agent {} is not associated with extension ",classMethodName,agent.getAgentId());
		}
		return agent;
	}

	@Override
	public List<EAgentLdap> deleteAgentLdaps(List<EAgentLdap> agentLdaps) {
		final String classMethodName="AgentServiceImpl.deleteAgentLdaps";
		log.info("{}|Deleting agentLdaps in edb", classMethodName);
		return agentLdaps.stream().map(agentLdap-> {
			agentLdap.setType(config.getAgentLdapType());
			log.info("{}|Deleting EAgentLdap using ldapId:{}", classMethodName,agentLdap.getLdapId());
			agentDao.delete(agentLdap,EAgentLdap.class);
			ELdapAgent eLdapAgent = dozerBeanMapper.map(agentLdap,ELdapAgent.class);
			eLdapAgent.setType(config.getLdapAgentType());
			log.info("{}|Deleting ELdapAgent using AgentId:{}", classMethodName, agentLdap.getAgentId());
            agentDao.delete(eLdapAgent,ELdapAgent.class);
			return agentLdap;
		}).collect(Collectors.toList());
	}
	
	  @Override
	  public ELdapAgent findLdapAgentByAgentId(String countryCode, String lob, String agentId) {
	    final String classMethodName="AgentServiceImpl.findLdapAgentByAgentId";      
	    String id = couchbaseUtils.getId(new ELdapAgent(config.getLdapAgentType(), countryCode, lob, agentId), ELdapAgent.class);
	    return agentDao.findById(id,ELdapAgent.class).orElseThrow(()->{
	        log.info("{}| ELdapAgent document not found for docId: {}", classMethodName, id);
	        return new DataNotFoundException("ELdapAgent document not found for agentId: " + agentId);
	    });
	  }
	  
	  @Override
	  public EAgentLdap findAgentLdapByLdapId(String countryCode, String lob, String ldapId) {
	    final String classMethodName="AgentServiceImpl.findAgentLdapByLdapId";      
	    String id = couchbaseUtils.getId(new EAgentLdap(config.getAgentLdapType(), countryCode, lob, ldapId), EAgentLdap.class);
	    return agentDao.findById(id,EAgentLdap.class).orElseThrow(()->{
	        log.info("{}| EAgentLdap document not found for docId: {}", classMethodName, id);
	        return new DataNotFoundException("EAgentLdap document not found for ldapId: " + ldapId);
	    });
	  }
}
