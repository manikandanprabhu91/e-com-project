package com.qvc.cti.data.edb.dao;

import java.util.Optional;
import org.springframework.stereotype.Service;
import com.qvc.cti.data.edb.config.EdbCouchbaseRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class SessionDaoImpl helps to create, update, retrieve and delete the couch Session document.
 *
 * @author c007152
 */
@Slf4j
@Service
@AllArgsConstructor
public class SessionDaoImpl implements SessionDao {

  /** The edb couchbase repository. */
  EdbCouchbaseRepository edbCouchbaseRepository;

  /**
   * Create or update.
   *
   * @param <T> the generic type
   * @param entity the entity
   * @param type the type
   * @return the t
   */
  @Override
  public <T> T createOrUpdate(T entity, Class<T> type) {
    final String classMethodName = "SessionDaoImpl.createOrUpdate";
    log.info("{}|Creating/Updating the document:{}", classMethodName,entity);
    return edbCouchbaseRepository.upsert(entity, type);
  }

  /**
   * Find by id.
   *
   * @param <T> the generic type
   * @param id the id
   * @param type the type
   * @return the optional
   */
  @Override
  public <T> Optional<T> findById(String id, Class<T> type) {
    final String classMethodName = "SessionDaoImpl.findById";
    log.info("{}|finding the document by Id:{}",classMethodName,id);
    return edbCouchbaseRepository.findById(id, type);
  }

  /**
   * Delete.
   *
   * @param <T> the generic type
   * @param entity the entity
   * @param type the type
   * @return the t
   */
  @Override
  public <T> T delete(T entity, Class<T> type) {
    final String classMethodName = "SessionDaoImpl.delete";
    log.info("{}|Deleting the document:{}",classMethodName,entity);
    edbCouchbaseRepository.delete(entity, type);
    return entity;
  }
}
