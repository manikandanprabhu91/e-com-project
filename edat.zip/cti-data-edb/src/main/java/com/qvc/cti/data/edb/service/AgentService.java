package com.qvc.cti.data.edb.service;

import java.util.List;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;

public interface AgentService {
	
	List<EAgent> createAgents(final List<EAgent> agents, String countryCode, String lob);
	EAgent updateAgent(final EAgent agent,final String ldapId);
	EAgent deleteAgent(final EAgent agent);
	
	EAgent findByAgentId(final String countryCode, final String lob, final String agentId);
	EAgent findAgentByLdapId(final String countryCode, final String lob, final String ldapId);
	EAgent findAgentByExtension(final String countryCode, final String lob, final String extension);
	
	List<EAgentLdap> createAgentLdaps(final List<EAgentLdap> agentLdaps);
	List<EAgentLdap> deleteAgentLdaps(final List<EAgentLdap> agentLdaps);
	
    ELdapAgent findLdapAgentByAgentId(final String countryCode, final String lob, final String agentId);
    EAgentLdap findAgentLdapByLdapId(final String countryCode, final String lob, final String ldapId);  
}
