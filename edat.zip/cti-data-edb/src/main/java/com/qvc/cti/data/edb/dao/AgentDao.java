package com.qvc.cti.data.edb.dao;

import java.util.Optional;

import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;


public interface AgentDao {
	
	public <T> Optional<T> findById(String id, Class<T> type) ;
	
	public EAgent createOrUpdateAgent(final EAgent agent,String userName);
	public EAgentLdap createOrUpdateAgentLdap(final EAgentLdap agentLdap ,String userName);
	public EAgent updateAgent(final EAgent agent,String userName);
	public EAgentExtension createAgentExtension(final EAgentExtension agentExtension ,String userName);
	public <T> T  delete(T entity, Class<T> type) ;
}
