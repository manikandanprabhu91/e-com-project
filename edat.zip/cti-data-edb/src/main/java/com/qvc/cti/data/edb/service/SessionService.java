package com.qvc.cti.data.edb.service;

import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;

public interface SessionService {
  public ECTISession createOrUpdateSession(ECTISession ectiSession);
  public ECTISessionLdap createSessionLdap(ECTISessionLdap ectiSessionLdap);
  public ECTISession findSessionBySessionId(final String countryCode, final String lob, final String sessionId);
  public ECTISession findSessionByLdapId(final String countryCode, final String lob, final String ldapId);
  public ECTISession deleteSession(final ECTISession ectiSession);
}
