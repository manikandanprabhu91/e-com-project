package com.qvc.cti.data.edb.config;

import java.util.concurrent.TimeUnit;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.qvc.edb.common.utils.repository.FallbackCouchbaseRepository;


public class EdbCouchbaseRepository extends FallbackCouchbaseRepository {
	
	public EdbCouchbaseRepository(@Autowired Bucket primaryBucket, @Autowired Bucket secondaryBucket, 
			@Autowired Cluster primaryCluster, @Autowired DozerBeanMapper dozerBeanMapper) {
		this(primaryBucket, primaryCluster, secondaryBucket, dozerBeanMapper, TimeUnit.SECONDS.toMillis(800));
	}
	
    public EdbCouchbaseRepository(@Autowired Bucket primaryBucket, @Autowired Cluster primaryCluster, 
    		@Autowired Bucket secondaryBucket, @Autowired DozerBeanMapper dozerBeanMapper, Long timeout) {
		super(primaryBucket, primaryCluster, secondaryBucket, timeout);
    }
}
