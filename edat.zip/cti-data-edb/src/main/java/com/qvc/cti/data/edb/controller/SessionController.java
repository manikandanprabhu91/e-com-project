package com.qvc.cti.data.edb.controller;

import java.security.Principal;
import javax.validation.Valid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;
import com.qvc.coast.web.client.error.ApiException.ErrorCode;
import com.qvc.coast.web.client.error.BadRequestException;
import com.qvc.cti.data.edb.service.SessionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class SessionController helps to create, update, retrieve and delete the couch Session
 * document.
 *
 * @author c007152
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping(value = "/order/management/{version}/{countryCode}/{lob}/cti",
    produces = MediaType.APPLICATION_JSON_VALUE)
public class SessionController {

  SessionService sessionService;

  private static final String NOT_AUTHENTICATED = "User Not Authenticated";

  /**
   * Creates the session.
   *
   * @param headers the headers
   * @param version 
   * @param countryCode the country code
   * @param lob the lob
   * @param ectiSession the ecti session
   * @param principal the principal
   * @return the response entity
   */
  @PostMapping(value = "/session", produces = {"application/json", "application/xml"},
      consumes = {"application/json", "application/xml"})
  public ResponseEntity<ECTISession> createCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode,
      @PathVariable String lob, @RequestBody final @Valid ECTISession ectiSession, Principal principal) {

    final String classMethodName = "SessionController.createSession";
    requestValidation(principal, ectiSession, classMethodName);
    setCommonValues(ectiSession, version, countryCode, lob);
    log.info("{}|Creating ECTISession.Requested user is: {}", classMethodName, principal.getName());
    return new ResponseEntity<>(sessionService.createOrUpdateSession(ectiSession),
        HttpStatus.CREATED);
  }

  /**
   * Creates the session ldap.
   *
   * @param headers the headers
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   * @param ectiSessionLdap the ecti session ldap
   * @param principal the principal
   * @return the response entity
   */
  @PostMapping(value = "/session/login-id", produces = {"application/json", "application/xml"},
      consumes = {"application/json", "application/xml"})
  public ResponseEntity<ECTISessionLdap> createSessionLdap(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode,
      @PathVariable String lob, @RequestBody final @Valid ECTISessionLdap ectiSessionLdap, Principal principal) {

    final String classMethodName = "SessionController.createSessionLdap";
    Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
    Assert.notNull(ectiSessionLdap, "The ECTISessionLdap request payload cannot be null");
    if (!StringUtils.isNotBlank(ectiSessionLdap.getLdapId())) {
      throw new BadRequestException(ErrorCode.PARAMETER_INVALID,
          "Payload missing mandatory LdapId field");
    }
    ectiSessionLdap.setDocumentVersion(version);
    ectiSessionLdap.setOperationalCountryCode(countryCode);
    ectiSessionLdap.setLineOfBusiness(lob);
    log.info("{}|Creating ECTISessionLdap.Requested user is: {}", classMethodName,
        principal.getName());
    return new ResponseEntity<>(sessionService.createSessionLdap(ectiSessionLdap),
        HttpStatus.CREATED);
  }

  /**
   * Find session by session id.
   *
   * @param headers the headers
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @param principal the principal
   * @return the response entity
   */
  @GetMapping(value = "/session/session-id/{sessionId}",
      produces = {"application/json", "application/xml"})
  public ResponseEntity<ECTISession> findCTISessionBySessionId(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode, @PathVariable String lob,
      @PathVariable String sessionId, Principal principal) {
    final String classMethodName = "SessionController.findSessionBySessionId";
    Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
    log.info("{}|Finding ECTISession by sessionId: {}.Requested user is: {}", classMethodName,
        sessionId, principal.getName());
    return new ResponseEntity<>(sessionService.findSessionBySessionId(countryCode, lob, sessionId),
        HttpStatus.OK);
  }

  /**
   * Find session by ldap id.
   *
   * @param headers the headers
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   * @param ldapId the ldap id
   * @param principal the principal
   * @return the response entity
   */
  @GetMapping(value = "/session/login-id/{ldapId}",
      produces = {"application/json", "application/xml"})
  public ResponseEntity<ECTISession> findCTISessionByLdapId(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode, @PathVariable String lob,
      @PathVariable String ldapId, Principal principal) {
    final String classMethodName = "SessionController.findSessionByLdapId";
    Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
    log.info("{}|Finding ECTISession by ldapId: {}.Requested user is: {}", classMethodName,
        ldapId, principal.getName());
    return new ResponseEntity<>(sessionService.findSessionByLdapId(countryCode, lob, ldapId),
        HttpStatus.OK);
  }
  /**
   * Update session.
   *
   * @param headers the headers
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   * @param ectiSession the ecti session
   * @param principal the principal
   * @return the response entity
   */
  @PutMapping(value = "/session", produces = {"application/json", "application/xml"},
      consumes = {"application/json", "application/xml"})
  public ResponseEntity<ECTISession> updateCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode,
      @PathVariable String lob, @RequestBody final ECTISession ectiSession, Principal principal) {

    final String classMethodName = "SessionController.updateSession";
    requestValidation(principal, ectiSession, classMethodName);
    setCommonValues(ectiSession, version, countryCode, lob);
    log.info("{}|Updating ECTISession by using sessionId {} .Requested user is: {}",
        classMethodName, ectiSession.getSessionId(), principal.getName());
    return new ResponseEntity<>(sessionService.createOrUpdateSession(ectiSession), HttpStatus.OK);
  }

  /**
   * Delete session.
   *
   * @param headers the headers
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   * @param ectiSession the ecti session
   * @param principal the principal
   * @return the response entity
   */
  @DeleteMapping(value = "/session", produces = {"application/json", "application/xml"},
      consumes = {"application/json", "application/xml"})
  public ResponseEntity<ECTISession> deleteCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable String version, @PathVariable String countryCode,
      @PathVariable String lob, @RequestBody final ECTISession ectiSession, Principal principal) {
    final String classMethodName = "SessionController.deleteSession";
    requestValidation(principal, ectiSession, classMethodName);
    setCommonValues(ectiSession, version, countryCode, lob);
    log.info("{}|Deleting ECTISession using ectiSession: {}.Requested user is: {}", classMethodName,
        ectiSession.getSessionId(), principal.getName());
    return new ResponseEntity<>(sessionService.deleteSession(ectiSession), HttpStatus.OK);
  }

  /**
   * Request validation.
   *
   * @param principal the principal
   * @param ectiSession the ecti session
   * @param classMethodName the class method name
   */
  private void requestValidation(Principal principal, ECTISession ectiSession,
      String classMethodName) {
    Assert.notNull(principal, classMethodName + NOT_AUTHENTICATED);
    Assert.notNull(ectiSession, "The ECTISession request payload cannot be null");
    if (!StringUtils.isNotBlank(ectiSession.getSessionId())) {
      throw new BadRequestException(ErrorCode.PARAMETER_INVALID,
          "Payload missing mandatory SessionId field");
    }
  }

  /**
   * Sets the common values.
   *
   * @param ectiSession the ecti session
   * @param version
   * @param countryCode the country code
   * @param lob the lob
   */
  private void setCommonValues(ECTISession ectiSession, String version, String countryCode, String lob) {
    ectiSession.setDocumentVersion(version);
    ectiSession.setOperationalCountryCode(countryCode);
    ectiSession.setLineOfBusiness(lob);
  }
}
