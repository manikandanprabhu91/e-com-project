package com.qvc.cti.data.edb.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class CustomerDataEDBAspect {

	@Around("execution(* com.qvc.cti.data.edb.handler.*.*(..)) || execution(* com.qvc.cti.data.edb.controller.*.*(..)) || "
			+ "execution(* com.qvc.cti.data.edb.service.*.*(..))  || execution(* com.qvc.cti.data.edb.dao.*.*(..))")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		long methodMicroStartTime = System.nanoTime();
		String methodName = null;
		String simpleClassName = null;
		try {
			methodName = joinPoint.getSignature().getName();
			simpleClassName = joinPoint.getTarget().getClass().getSimpleName();
			return joinPoint.proceed();
		} catch (Throwable b) {
			log.error(simpleClassName + "." + methodName + "|" + (System.nanoTime() - methodMicroStartTime)
					+ "| Error while executing methood", b.getMessage());
			throw b;
		} finally {
			log.debug("{}.{}|{}|Method completed", simpleClassName, methodName,
					System.nanoTime() - methodMicroStartTime);
		}
	}
}
