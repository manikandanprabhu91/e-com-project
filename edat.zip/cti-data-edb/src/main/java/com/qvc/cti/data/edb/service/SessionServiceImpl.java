package com.qvc.cti.data.edb.service;

import java.util.Date;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.qvc.coast.edb.data.transformer.cti.CTIBase;
import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.coast.web.client.error.DataNotFoundException;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.cti.data.edb.dao.SessionDao;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class SessionServiceImpl helps to create, update, retrieve and delete the couch Session
 * document.
 *
 * @author c007152
 */
@Service
@AllArgsConstructor
@Slf4j
public class SessionServiceImpl implements SessionService {

  private SessionDao sessionDao;
  private CouchbaseUtils couchbaseUtils;
  private PropertiesConfig config;

 
  /**
   * Creates the or update session.
   *
   * @param ectiSession the ecti session
   * @return the ECTI session
   */
  @Override
  public ECTISession createOrUpdateSession(ECTISession ectiSession) {
    final String classMethodName = "SessionServiceImpl.createOrUpdateSession";
    log.info("{}|Creating/Updating ECTISession in edb using sessionId:{}", classMethodName,ectiSession.getSessionId());
    final String userName =
        ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
            .getUsername();
    setCommonCtiBaseAttributes(ectiSession,new Date(),userName);
    ectiSession.setType(config.getSessionType());
    return sessionDao.createOrUpdate(ectiSession, ECTISession.class);
  }

  /**
   * Creates the session ldap.
   *
   * @param ectiSessionLdap the ecti session ldap
   * @return the ECTI session
   */
  @Override
  public ECTISessionLdap createSessionLdap(ECTISessionLdap ectiSessionLdap) {
    final String classMethodName = "SessionServiceImpl.createSessionLdap";
    log.info("{}|Creating ECTISessionLdap in edb using ldapId:{}", classMethodName,ectiSessionLdap.getLdapId());
    final String userName =
        ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
            .getUsername();
    setCommonCtiBaseAttributes(ectiSessionLdap,new Date(),userName);
    ectiSessionLdap.setType(config.getSessionLdapType());
    return sessionDao.createOrUpdate(ectiSessionLdap, ECTISessionLdap.class);
  }

  /**
   * Find session by session id.
   *
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @return the ECTI session
   */
  @Override
  public ECTISession findSessionBySessionId(String countryCode, String lob, String sessionId) {
    final String classMethodName = "SessionServiceImpl.findSessionBySessionId";
    String id = couchbaseUtils.getId(
        new ECTISession(config.getSessionType(), countryCode, lob, sessionId), ECTISession.class);
    log.info("{}|Finding ECTISession using sessionId:{}", classMethodName, sessionId);
    return sessionDao.findById(id, ECTISession.class).orElseThrow(() -> {
      log.info("{}| ECTISession document not found for docId: {}", classMethodName, id);
      return new DataNotFoundException(
          "ECTISession document not found for sessionId : " + sessionId);
    });
  }

  /**
   * Find session by ldap id.
   *
   * @param countryCode the country code
   * @param lob the lob
   * @param ldapId the ldap id
   * @return the ECTI session
   */
  @Override
  public ECTISession findSessionByLdapId(String countryCode, String lob, String ldapId) {
    ECTISessionLdap ectiSessionLdap = findECTISessionLdapByLdapId(countryCode,lob,ldapId);
    return findSessionBySessionId(countryCode, lob, ectiSessionLdap.getSessionId());
  }

  /**
   * Find ECTI session ldap by ldap id.
   *
   * @param countryCode the country code
   * @param lob the lob
   * @param ldapId the ldap id
   * @return the ECTI session ldap
   */
  private ECTISessionLdap findECTISessionLdapByLdapId(String countryCode, String lob,
      String ldapId) {
    final String classMethodName = "SessionServiceImpl.findECTISessionLdapByLdapId";
    log.info("{}|Finding ECTISessionLdap using ldapId:{}", classMethodName, ldapId);
    String id = couchbaseUtils.getId(
        new ECTISessionLdap(config.getSessionLdapType(), countryCode, lob, ldapId),
        ECTISessionLdap.class);
    return sessionDao.findById(id, ECTISessionLdap.class).orElseThrow(() -> {
      log.info("{}| ECTISessionLdap document not found for docId: {}", classMethodName, id);
      return new DataNotFoundException("ECTISessionLdap document not found for ldapId : " + ldapId);
    });
  }

  /**
   * Delete session.
   *
   * @param ectiSession the ecti session
   * @return the ECTI session
   */
  @Override
  public ECTISession deleteSession(ECTISession ectiSession) {
    final String classMethodName = "SessionServiceImpl.deleteSession";
    ectiSession.setType(config.getSessionType());
    if(!StringUtils.isEmpty(ectiSession.getAgentId())) {
      ELdapAgent eLdapAgent = findLdapAgentByAgentId(ectiSession);
      ECTISessionLdap ectiSessionLdap = findECTISessionLdapByLdapId(ectiSession.getOperationalCountryCode(), ectiSession.getLineOfBusiness(),eLdapAgent.getLdapId());
      log.info("{}|Deleting ECTISessionLdap with LdapId:{}", classMethodName, ectiSessionLdap.getLdapId());
      sessionDao.delete(ectiSessionLdap, ECTISessionLdap.class);
    }
    log.info("{}|Deleting ECTISession with sessionId:{}", classMethodName, ectiSession.getSessionId());
    return sessionDao.delete(ectiSession,ECTISession.class);
  }
  
  /**
   * Find ldap agent by agent id.
   *
   * @param ectiSession the ecti session
   * @return the e ldap agent
   */
  private ELdapAgent findLdapAgentByAgentId(ECTISession ectiSession) {
    final String classMethodName = "SessionServiceImpl.findLdapAgentByAgentId";
    String id = couchbaseUtils.getId(new ELdapAgent(config.getLdapAgentType(), ectiSession.getOperationalCountryCode(), ectiSession.getLineOfBusiness(), ectiSession.getAgentId()), ELdapAgent.class);
    log.info("{}|Finding ELdapAgent using agentId:{}", classMethodName, ectiSession.getAgentId());
    return sessionDao.findById(id,ELdapAgent.class).orElseThrow(()->{
      log.info("{}| ELdapAgent document not found for docId: {}", classMethodName, id);
      return new DataNotFoundException("ELdapAgent document not found for AgentId: " + ectiSession.getAgentId());
  });
  }

  /**
   * Sets the common cti base attributes.
   *
   * @param ctiBase the cti base
   * @param date the date
   * @param userName the user name
   */
  private void setCommonCtiBaseAttributes(final CTIBase ctiBase, Date date, String userName) {
    ctiBase.setLastUpdateProgramName(config.getAppName());
    ctiBase.setLastUpdateDBUserId(config.getClusterUsername());
    ctiBase.setLastUpdateApplicationUserId(config.getBucketName());
    ctiBase.setLastUpdatePrincipalName(userName);
    ctiBase.setLastUpdateTimeStamp(date);
  }
}
