package com.qvc.cti.data.edb.config;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import lombok.AllArgsConstructor;

/**
 * Basic authentication using spring security.Simple file based authentication is used
 * ${env.dir} must be passed as parameter to microservice to determine location of
 * spring.security.rest.client.properties file
 * 
 * @author Atul
 * @since 1.0
 */
@Configuration
@EnableGlobalMethodSecurity(securedEnabled = true)
@EnableWebSecurity
@AllArgsConstructor
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	PropertiesConfig propertiesConfig;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/swagger-ui*", "/info", "/health")
		.permitAll().and().authorizeRequests().anyRequest().fullyAuthenticated().and().httpBasic().and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().csrf().disable();
	}

	@Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(inMemoryUserDetailsManager());
    }

    @Bean
    public InMemoryUserDetailsManager inMemoryUserDetailsManager() throws Exception {
        return new InMemoryUserDetailsManager(getSpringUserProperties());
    }
    
    @Bean(name="springUserProperties")
    public Properties getSpringUserProperties()throws IOException {
    	return PropertiesLoaderUtils.loadProperties(
    			new FileSystemResource(propertiesConfig.getSecurityFileLocation()+File.separatorChar+"spring.security.rest.client.properties"));
    }
}
