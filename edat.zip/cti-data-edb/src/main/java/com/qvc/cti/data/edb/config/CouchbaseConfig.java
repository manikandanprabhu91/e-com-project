package com.qvc.cti.data.edb.config;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.naming.NamingException;

import org.dozer.DozerBeanMapper;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
import com.couchbase.client.java.util.Bootstrap;
import com.qvc.edb.common.utils.config.CouchbaseRepositoryConfig;

import lombok.AllArgsConstructor;

@Configuration
@AllArgsConstructor
public class CouchbaseConfig extends CouchbaseRepositoryConfig {

	private PropertiesConfig propertiesConfig;
	private FallbackCouchbaseConfig fallbackCouchbaseConfig;

	@Bean(name="primaryCluster", destroyMethod = "disconnect")
    public Cluster primaryCluster() {
    	Cluster cluster = CouchbaseCluster.create(couchbaseEnvironment(), getBootstrapHosts(true));
        cluster.authenticate(propertiesConfig.getClusterUsername(), propertiesConfig.getClusterPassword());
        return cluster;
    }
	
	@Bean(name="secondaryCluster", destroyMethod = "disconnect")
    public Cluster secondaryCluster() {
    	Cluster cluster = CouchbaseCluster.create(fallbackCouchbaseEnvironment(), getBootstrapHosts(false));
        cluster.authenticate(fallbackCouchbaseConfig.getFallbackClusterUsername(), fallbackCouchbaseConfig.getFallbackClusterPassword());
        return cluster;
    }
	
	protected List<String> getBootstrapHosts(boolean isPrimary) {
		if(isPrimary) {
			return propertiesConfig.getBootstrapHosts().stream().flatMap(CouchbaseConfig::safeFromDnsSrv).collect(Collectors.toList());
		}
		return fallbackCouchbaseConfig.getFallbackBootstrapHosts().stream().flatMap(CouchbaseConfig::safeFromDnsSrv).collect(Collectors.toList());
	}

	private static Stream<String> safeFromDnsSrv(String serviceName) {
		try {
			return Bootstrap.fromDnsSrv(serviceName, false, true).stream();
		} catch (NamingException e) {
			return null;
		}
	}

	/* Prepare Couchbase environment */
	public CouchbaseEnvironment couchbaseEnvironment() {
		CouchbaseProperties.Timeouts timeouts = propertiesConfig.getEnv().getTimeouts();
		DefaultCouchbaseEnvironment.Builder builder = DefaultCouchbaseEnvironment
				.builder().connectTimeout(timeouts.getConnect())
				.dnsSrvEnabled(false)
				.forceSaslPlain(true)
				.kvTimeout(timeouts.getKeyValue())
				.socketConnectTimeout(timeouts.getSocketConnect())
				.viewTimeout(timeouts.getView());
		CouchbaseProperties.Ssl ssl = propertiesConfig.getEnv().getSsl();
		if (ssl.getEnabled()) {
			builder.sslEnabled(true);
			if (ssl.getKeyStore() != null) {
				builder.sslKeystoreFile(ssl.getKeyStore());
			}
			if (ssl.getKeyStorePassword() != null) {
				builder.sslKeystorePassword(ssl.getKeyStorePassword());
			}
		}
		return builder.build();
	}

	/* Prepare Couchbase environment */
	public CouchbaseEnvironment fallbackCouchbaseEnvironment() {
		CouchbaseProperties.Timeouts timeouts = fallbackCouchbaseConfig.getEnv().getTimeouts();
		DefaultCouchbaseEnvironment.Builder builder = DefaultCouchbaseEnvironment
				.builder().connectTimeout(timeouts.getConnect())
				.dnsSrvEnabled(false)
				.forceSaslPlain(true)
				.kvTimeout(timeouts.getKeyValue())
				.socketConnectTimeout(timeouts.getSocketConnect())
				.viewTimeout(timeouts.getView());
		CouchbaseProperties.Ssl ssl = fallbackCouchbaseConfig.getEnv().getSsl();
		if (ssl.getEnabled()) {
			builder.sslEnabled(true);
			if (ssl.getKeyStore() != null) {
				builder.sslKeystoreFile(ssl.getKeyStore());
			}
			if (ssl.getKeyStorePassword() != null) {
				builder.sslKeystorePassword(ssl.getKeyStorePassword());
			}
		}
		return builder.build();
	}

	@Bean(name="primaryBucket", destroyMethod = "close")
    public Bucket primaryBucket() {
        return primaryCluster().openBucket(propertiesConfig.getBucketName(),TimeUnit.SECONDS.toMillis(20), TimeUnit.MILLISECONDS);
    }

	@Bean(name="secondaryBucket", destroyMethod = "close")
    public Bucket secondaryBucket() {
        return secondaryCluster().openBucket(fallbackCouchbaseConfig.getFallbackBucketName(),TimeUnit.SECONDS.toMillis(20), TimeUnit.MILLISECONDS);
    }
	
	@Bean
	public EdbCouchbaseRepository getCouchbaseRepository() {
		Long timeout;
		try {
			timeout = Long.parseLong(propertiesConfig.getTimeoutForReplica());
		} catch(NumberFormatException ex) {
			timeout = 800L;
		}
		return new EdbCouchbaseRepository(primaryBucket(), primaryCluster(), secondaryBucket(), dozerBeanMapper(), timeout);
	}	
	
	@Bean 
	public DozerBeanMapper dozerBeanMapper() {
		return new DozerBeanMapper();
	}
}