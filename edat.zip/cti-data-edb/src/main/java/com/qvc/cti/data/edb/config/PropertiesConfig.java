package com.qvc.cti.data.edb.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "couchbase")
@Getter
@Setter
@PropertySource(value = "file:${security.fileLocation}/spring.datasource.properties", ignoreResourceNotFound = false)
public class PropertiesConfig extends CouchbaseProperties {
	
	@Value("#{'${couchbase.bootstrap-hosts}'.split(',')}")
	private List<String> bootstrapHosts;
	
	@Value("${couchbase.cluster.username}")
	private String clusterUsername;

	@Value("${couchbase.cluster.password}")
	private String clusterPassword;
	
	@Value("${couchbase.bucket.name}")
	private String bucketName;

	@Value("${security.fileLocation}") 
	private String securityFileLocation;
	
	@Value("${spring.application.name}")
	private String appName;
	
	@Value("${cti.data.expiry}")
	private int expiry;	
	
	@Value("${cti.data.document.version}")
	private String documentVersion;
	
	@Value("${cti.data.timeout.replica}")
	private  String timeoutForReplica;

	@Value("${cti.cluster.default}")
	private String defaultCluster;	
	
	@Value("${cti.cluster.current}")
	private String cluster;

	@Value("#{'${cti.cluster.list}'.split(',')}")
	private List<String> clusters;

	@Value("${cti.data.agent.type}")
  	private  String agentType;
	
	@Value("${cti.data.ldapagent.type}")
  	private String ldapAgentType;
	
	@Value("${cti.data.agentldap.type}")
  	private String agentLdapType;
	
	@Value("${cti.data.agentextension.type}")
	private String agentExtensionType;

	@Value("${cti.session.type}")
    private String sessionType;
    
    @Value("${cti.sessionldap.type}")
    private String sessionLdapType;
}
