package com.qvc.cti.data.edb.dao;

import java.util.Optional;

/**
 * The Interface SessionDao.
 *
 * @author c007152
 */
public interface SessionDao {

  /**
   * Creates or update session.
   *
   * @param ectiSession the ecti session
   * @param userName the user name
   * @return the ECTI session
   */
  public <T> T createOrUpdate(T entity, Class<T> type);

  /**
   * Find by id.
   *
   * @param <T> the generic type
   * @param id the id
   * @param type the type
   * @return the optional
   */
  public <T> Optional<T> findById(String id, Class<T> type);

  /**
   * Delete.
   *
   * @param <T> the generic type
   * @param entity the entity
   * @param type the type
   * @return the t
   */
  public <T> T delete(T entity, Class<T> type);
}
