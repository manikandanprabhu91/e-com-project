package com.qvc.cti.data.edb.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;
import com.qvc.cti.data.edb.TestConfig;
import com.qvc.cti.data.edb.service.SessionService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
@ActiveProfiles("test")
public class SessionControllerTest {
  
  private MockMvc mockMvc;
  
  @Autowired
  private WebApplicationContext webApplicationContext;
  
  private TestingAuthenticationToken testingAuthenticationToken;
  
  @MockBean
  SessionService sessionService;
  
  @Mock
  ECTISession ectiSession;

  @Mock
  ECTISessionLdap ectiSessionLdap;
  
  @BeforeClass
  public static void beforeClass() {
      TestConfig.loadConfigSecurityFiles();
  }
  
  @Before
  public void beforeMethod() {
    this.mockMvc = webAppContextSetup(webApplicationContext).build();
    
    final User user = new User("edbJunitRestUser", "eSQIx8T7Ilujtl4@WkC6R",
        AuthorityUtils.createAuthorityList("ROLE_REST_API_CLIENT"));
    this.testingAuthenticationToken = new TestingAuthenticationToken(user, null);
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    ectiSession  = new ECTISession("ctisession","us","q","001");
    ectiSessionLdap = new ECTISessionLdap("ctisessionldap","us","q","win001");
  }
  
  private static String asJsonString(final Object obj) throws JsonProcessingException {
    return new ObjectMapper().writeValueAsString(obj);
  }
  @Test
  public void testCreateSession() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createOrUpdateSession(any())).thenReturn(ectiSession);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(ectiSession))
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isCreated())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    
    verify(sessionService,times(1)).createOrUpdateSession(any());
  }

  @Test
  public void testCreateSession_invalidAuthorisation() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createOrUpdateSession(any())).thenReturn(ectiSession);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(ectiSession))
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    verify(sessionService,times(0)).createOrUpdateSession(any());
  }
  
  @Test
  public void testCreateSession_EmptyPayload() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createOrUpdateSession(any())).thenReturn(ectiSession);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content("")
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    verify(sessionService,times(0)).createOrUpdateSession(any());
  }
  
  @Test
  public void testCreateSession_EmptySessionId() throws JsonProcessingException, Exception {
    ECTISession sessWithEmptyId = new ECTISession("ctisession","us","q","");
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createOrUpdateSession(any())).thenReturn(sessWithEmptyId);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(sessWithEmptyId))
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    verify(sessionService,times(0)).createOrUpdateSession(any());
  }
  
  @Test
  public void testfindSessionBySessionId() throws Exception{
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      when(sessionService.findSessionBySessionId(anyString(), anyString(), anyString())).thenReturn(new ECTISession("ctisession","us","q","002"));
      
      mockMvc.perform(get("/order/management/v1/us/q/cti/session/session-id/002").contentType(MediaType.APPLICATION_JSON)
              .principal(testingAuthenticationToken)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isOk())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andDo(print());
      
      verify(sessionService,times(1)).findSessionBySessionId(anyString(), anyString(), anyString());
  }
  
  @Test
  public void testfindSessionBySessionId_invalidAuthorisation() throws Exception{
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      when(sessionService.findSessionBySessionId(anyString(), anyString(), anyString())).thenReturn(new ECTISession("ctisession","us","q","002"));
      
      mockMvc.perform(get("/order/management/v1/us/q/cti/session/session-id/002").contentType(MediaType.APPLICATION_JSON)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isBadRequest())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andDo(print());
      
      verify(sessionService,times(0)).findSessionBySessionId(anyString(), anyString(), anyString());
  }
  
  @Test
  public void testUpdateSession() throws Exception{
      ECTISession updateSession = new ECTISession("ctisession","us","q","003");
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      
      when(sessionService.createOrUpdateSession(any())).thenReturn(updateSession);
      
      mockMvc.perform(put("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(updateSession))
              .principal(testingAuthenticationToken)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isOk())
      .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
      .andExpect(jsonPath("$.sessionId", is("003")))
      .andDo(print());
  }
  
  @Test
  public void testdeleteSession() throws Exception{
      ECTISession deletSession = new ECTISession("ctisession","us","q","003");
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      
      when(sessionService.deleteSession(any())).thenReturn(deletSession);
      
      mockMvc.perform(delete("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(deletSession))
              .principal(testingAuthenticationToken)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isOk())
      .andDo(print());
      
      verify(sessionService,times(1)).deleteSession(any());
  }
  @Test
  public void testdeleteSession_invalidAuthorisation() throws Exception{
      ECTISession deletSession = new ECTISession("ctisession","us","q","003");
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      
      when(sessionService.deleteSession(any())).thenReturn(deletSession);
      
      mockMvc.perform(delete("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(deletSession))
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isBadRequest())
      .andDo(print());
      
      verify(sessionService,times(0)).deleteSession(any());
  }
  
  @Test
  public void testdeleteSession_EmptyPayload() throws Exception{
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      
      when(sessionService.deleteSession(any())).thenReturn(null);
      
      mockMvc.perform(delete("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content("")
              .principal(testingAuthenticationToken)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isBadRequest())
      .andDo(print());
      
      verify(sessionService,times(0)).deleteSession(any());
  }
  @Test
  public void testdeleteSession_EmptySessionId() throws Exception{
      ECTISession deletSession = new ECTISession("ctisession","us","q","");
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      
      when(sessionService.deleteSession(any())).thenReturn(deletSession);
      
      mockMvc.perform(delete("/order/management/v1/us/q/cti/session").contentType(MediaType.APPLICATION_JSON).content(asJsonString(deletSession))
              .principal(testingAuthenticationToken)
              .header("application-code", "ABC").header("application-version", "XYZ"))
      .andExpect(status().isBadRequest())
      .andDo(print());
      
      verify(sessionService,times(0)).deleteSession(any());
  }
  
  @Test
  public void testfindSessionByLdapId() throws Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionService.findSessionByLdapId(any(), any(), any())).thenReturn(ectiSession);

    mockMvc
        .perform(get("/order/management/v1/us/q/cti/session/login-id/win002")
            .contentType(MediaType.APPLICATION_JSON).principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());
    
    verify(sessionService,times(1)).findSessionByLdapId(any(), any(), any());
  }
  

  @Test
  public void testfindSessionByLdapId_InvalidAuthorization() throws Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionService.findSessionByLdapId(any(), any(), any())).thenReturn(ectiSession);

    mockMvc
        .perform(get("/order/management/v1/us/q/cti/session/login-id/win002")
            .contentType(MediaType.APPLICATION_JSON)
            .header("application-code", "ABC").header("application-version", "XYZ"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());
    
    verify(sessionService,times(0)).findSessionByLdapId(any(), any(), any());
  }
  
  @Test
  public void testCreateSessionLdap() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createSessionLdap(any())).thenReturn(ectiSessionLdap);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(ectiSessionLdap))
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isCreated())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    
    verify(sessionService,times(1)).createSessionLdap(any());
  }
  @Test
  public void testCreateSessionLdap_invalidAuthorisation() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createSessionLdap(any())).thenReturn(ectiSessionLdap);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(ectiSessionLdap))
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    
    verify(sessionService,times(0)).createSessionLdap(any());
  }
  @Test
  public void testCreateSessionLdap_emptyPayload() throws JsonProcessingException, Exception {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createSessionLdap(any())).thenReturn(ectiSessionLdap);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session/login-id").contentType(MediaType.APPLICATION_JSON).content("")
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    
    verify(sessionService,times(0)).createSessionLdap(any());
  }
  @Test
  public void testCreateSessionLdap_EmptyLoginId() throws JsonProcessingException, Exception {
    ECTISessionLdap ectiSessionLdap1 = new ECTISessionLdap("ctisessionldap","us","q","");
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    
    when(sessionService.createSessionLdap(any())).thenReturn(ectiSessionLdap);
    
    mockMvc.perform(post("/order/management/v1/us/q/cti/session/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(ectiSessionLdap1))
            .principal(testingAuthenticationToken)
            .header("application-code", "ABC").header("application-version", "XYZ"))
    .andExpect(status().isBadRequest())
    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
    .andDo(print());
    
    verify(sessionService,times(0)).createSessionLdap(any());
  }
}
