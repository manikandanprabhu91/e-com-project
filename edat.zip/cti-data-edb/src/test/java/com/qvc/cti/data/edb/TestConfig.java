package com.qvc.cti.data.edb;

import java.io.File;

public final class TestConfig {

	private TestConfig() {
	}

	public static void loadConfigSecurityFiles() {
		final ClassLoader classLoader = TestConfig.class.getClassLoader();
		final File configTestDirPath = new File(classLoader.getResource("config").getFile());
		final File securityTestDirPath = new File(classLoader.getResource("security").getFile());
		System.setProperty("env.dir", configTestDirPath.getAbsolutePath());
		System.setProperty("security.fileLocation", securityTestDirPath.getAbsolutePath());
	}

}
