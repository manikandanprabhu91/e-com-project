package com.qvc.cti.data.edb.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import java.util.Optional;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;
import com.qvc.cti.data.edb.config.EdbCouchbaseRepository;
import com.qvc.cti.data.edb.config.PropertiesConfig;

public class SessionDaoImplTest {

  @Mock
  private EdbCouchbaseRepository edbCouchbaseRepository;
  @Mock
  PropertiesConfig config;
  @Mock
  Authentication authentication;
  @Mock
  SecurityContext securityContext;
  
  @Mock
  ECTISession ectiSession;
  
  @Mock
  ECTISessionLdap ectiSessionLdap;
  
  private SessionDao sessionDao;
  
  @Before
  public void init() {
      initMocks(this);
      sessionDao = new SessionDaoImpl(edbCouchbaseRepository);
      
      ectiSession = new ECTISession("ctisession","us","q","0001");
      ectiSessionLdap = new ECTISessionLdap("ctisessionldap","us","q","win001");
  }
  
  @Test
  public void testCreateOrUpdateSession() {
    when(edbCouchbaseRepository.upsert(ectiSession, ECTISession.class)).thenReturn(ectiSession);
    ECTISession response = sessionDao.createOrUpdate(ectiSession, ECTISession.class);
    verify(edbCouchbaseRepository,times(1)).upsert(ectiSession, ECTISession.class);
    Assert.assertNotNull(response);
  }
  
  @Test
  public void testFindECTISessionById() {
    when(edbCouchbaseRepository.findById("ctisession:us:q:0001", ECTISession.class)).thenReturn(Optional.of(ectiSession));
    Optional<ECTISession> response = sessionDao.findById("ctisession:us:q:0001",ECTISession.class);
    verify(edbCouchbaseRepository,times(1)).findById("ctisession:us:q:0001", ECTISession.class);
    assertThat(response).isNotNull();
  }
  
  @Test
  public void testFindECTISessionLdapById() {
    when(edbCouchbaseRepository.findById("ctisessionldap:us:q:win001", ECTISessionLdap.class)).thenReturn(Optional.of(ectiSessionLdap));
    Optional<ECTISessionLdap> response = sessionDao.findById("ctisessionldap:us:q:win001",ECTISessionLdap.class);
    verify(edbCouchbaseRepository,times(1)).findById("ctisessionldap:us:q:win001", ECTISessionLdap.class);
    assertThat(response).isNotNull();
  }
  
  @SuppressWarnings("rawtypes")
  @Test
  public void testDeleteECTISession() {
      doAnswer(new Answer() {
          @Override
          public Object answer(InvocationOnMock invocation) throws Throwable {
              return null;
          }
      }).when(edbCouchbaseRepository).delete(any(),any());
      sessionDao.delete(new ECTISession("ctisession","us","q","0002"),ECTISession.class);
     verify(edbCouchbaseRepository,times(1)).delete(any(),any());
  }
}
