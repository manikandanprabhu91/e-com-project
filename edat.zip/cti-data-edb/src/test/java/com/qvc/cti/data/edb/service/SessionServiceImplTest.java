package com.qvc.cti.data.edb.service;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import com.qvc.coast.edb.data.transformer.cti.ECTISession;
import com.qvc.coast.edb.data.transformer.cti.ECTISessionLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.coast.web.client.error.DataNotFoundException;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.cti.data.edb.dao.SessionDao;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;

public class SessionServiceImplTest {

  private SessionService sessionService;
  
  private TestingAuthenticationToken testingAuthenticationToken;
  
  @Mock
  SessionDao sessionDao;
  
  @Mock
  CouchbaseUtils couchbaseUtils;
  
  @Mock
  PropertiesConfig config;
  
  @Mock
  ECTISession ectiSession;
  
  @Mock
  ECTISessionLdap ectisessionLdap;
  
  @Before
  public void init() {
    initMocks(this);
    
    sessionService = new SessionServiceImpl(sessionDao, couchbaseUtils, config);
    
    ectiSession = new ECTISession("ctisession","us","q","0001");
    ectisessionLdap = new ECTISessionLdap("ctisessionldap","us","q","win001");
    ectisessionLdap.setSessionId("0001");
    
    when(config.getSessionType()).thenReturn("ctisession");
    when(config.getSessionLdapType()).thenReturn("ctisessionldap");
    when(config.getLdapAgentType()).thenReturn("ldapagent");
    
    final User user = new User("edbJunitRestUser", "eSQIx8T7Ilujtl4@WkC6R",
        AuthorityUtils.createAuthorityList("ROLE_REST_API_CLIENT"));
    this.testingAuthenticationToken = new TestingAuthenticationToken(user, null);
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
  }
  
  @Test
  public void testCreateSession() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.createOrUpdate(any(),any())).thenReturn(ectiSession);
    sessionService.createOrUpdateSession(ectiSession);
    verify(sessionDao,times(1)).createOrUpdate(any(),any());
  }
  
  @Test
  public void testUpdateSession() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.createOrUpdate(any(),any())).thenReturn(ectiSession);
    sessionService.createOrUpdateSession(ectiSession);
    verify(sessionDao,times(1)).createOrUpdate(any(),any());
  }
  
  @Test
  public void testFindSessionBySessionId() {
    ECTISession findSession = new ECTISession(config.getSessionType(), "us", "q", "0001");
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.findById(any(),any())).thenReturn(Optional.of(ectiSession));
    
    when(couchbaseUtils.getId(findSession, ECTISession.class)).thenReturn("ctisession:us:q:0001");
    
    sessionService.findSessionBySessionId("us","q","0001");
    verify(sessionDao,times(1)).findById(any(),any());
    verify(couchbaseUtils,times(1)).getId(findSession, ECTISession.class);
  }
  
  @Test(expected=DataNotFoundException.class)
  public void testFindSessionBySessionId_SessionNotFound() {
    ECTISession findSession = new ECTISession(config.getSessionType(), "us", "q", "xxx");
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.findById(any(),any())).thenReturn(Optional.empty());
    
    when(couchbaseUtils.getId(findSession, ECTISession.class)).thenReturn("ctisession:us:q:xxx");
    
    sessionService.findSessionBySessionId("us","q","xxx");
    verify(sessionDao,times(1)).findById(any(),any());
    verify(couchbaseUtils,times(1)).getId(findSession, ECTISession.class);
  }
  
  @Test
  public void testFindSessionByLdapId() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    ECTISessionLdap findSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "win001");
    ECTISession findSession = new ECTISession(config.getSessionType(), "us", "q", "0001");
    
    when(couchbaseUtils.getId(findSessionLdap, ECTISessionLdap.class)).thenReturn("ctisessionldap:us:q:win001");
    when(sessionDao.findById("ctisessionldap:us:q:win001",ECTISessionLdap.class)).thenReturn(Optional.of(ectisessionLdap));
    when(couchbaseUtils.getId(findSession, ECTISession.class)).thenReturn("ctisession:us:q:0001");
    when(sessionDao.findById("ctisession:us:q:0001",ECTISession.class)).thenReturn(Optional.of(ectiSession));    
    
    sessionService.findSessionByLdapId("us","q","win001");
    
    verify(couchbaseUtils,times(1)).getId(findSessionLdap, ECTISessionLdap.class);
    verify(sessionDao,times(1)).findById("ctisessionldap:us:q:win001",ECTISessionLdap.class);
    verify(couchbaseUtils,times(1)).getId(findSession, ECTISession.class);
    verify(sessionDao,times(1)).findById("ctisession:us:q:0001",ECTISession.class);
  }
  
  @Test(expected=DataNotFoundException.class)
  public void testFindSessionByLdapId_SessionLdapNotFound() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    ECTISessionLdap findSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "winxxx");
    ECTISession findSession = new ECTISession(config.getSessionType(), "us", "q", "0001");
    
    when(couchbaseUtils.getId(findSessionLdap, ECTISessionLdap.class)).thenReturn("ctisessionldap:us:q:winxxx");
    when(sessionDao.findById("ctisessionldap:us:q:winxxx",ECTISessionLdap.class)).thenReturn(Optional.empty());
    when(couchbaseUtils.getId(findSession, ECTISession.class)).thenReturn("ctisession:us:q:0001");
    when(sessionDao.findById("ctisession:us:q:0001",ECTISession.class)).thenReturn(Optional.of(ectiSession));    
    
    sessionService.findSessionByLdapId("us","q","winxxx");
    
    verify(couchbaseUtils,times(1)).getId(findSessionLdap, ECTISessionLdap.class);
    verify(sessionDao,times(1)).findById("ctisessionldap:us:q:winxxx",ECTISessionLdap.class);
    verify(couchbaseUtils,times(0)).getId(findSession, ECTISession.class);
    verify(sessionDao,times(0)).findById("ctisession:us:q:0001",ECTISession.class);
  }
  
  @Test(expected=DataNotFoundException.class)
  public void testFindSessionByLdapId_SessionNotFound() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    ECTISessionLdap findSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "win001");
    ECTISession findSession = new ECTISession(config.getSessionType(), "us", "q", "0001");
    
    when(couchbaseUtils.getId(findSessionLdap, ECTISessionLdap.class)).thenReturn("ctisessionldap:us:q:win001");
    when(sessionDao.findById("ctisessionldap:us:q:win001",ECTISessionLdap.class)).thenReturn(Optional.of(ectisessionLdap));
    when(couchbaseUtils.getId(findSession, ECTISession.class)).thenReturn("ctisession:us:q:0001");
    when(sessionDao.findById("ctisession:us:q:0001",ECTISession.class)).thenReturn(Optional.empty());    
    
    sessionService.findSessionByLdapId("us","q","win001");
    
    verify(couchbaseUtils,times(1)).getId(findSessionLdap, ECTISessionLdap.class);
    verify(sessionDao,times(1)).findById("ctisessionldap:us:q:win001",ECTISessionLdap.class);
    verify(couchbaseUtils,times(1)).getId(findSession, ECTISession.class);
    verify(sessionDao,times(0)).findById("ctisession:us:q:0001",ECTISession.class);
  }
  
  @Test
  public void testDeleteSession() {
    ECTISession deleteSession = new ECTISession("ctisession","us","q","0001");
    deleteSession.setAgentId("test11");
    ECTISessionLdap findSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "win001");
    ELdapAgent findLdapAgent = new ELdapAgent(config.getLdapAgentType(),"us","q","test11");
    ELdapAgent responseLdapAgent = new ELdapAgent(config.getLdapAgentType(),"us","q","test11");
    responseLdapAgent.setLdapId("win001");
    ECTISessionLdap responseSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "win001");
    responseSessionLdap.setSessionId("0001");
    
    when(couchbaseUtils.getId(findLdapAgent, ELdapAgent.class)).thenReturn("ldapagent:us:q:test11");
    when(sessionDao.findById("ldapagent:us:q:test11",ELdapAgent.class)).thenReturn(Optional.of(responseLdapAgent));
    when(couchbaseUtils.getId(findSessionLdap, ECTISessionLdap.class)).thenReturn("ctisessionldap:us:q:win001");
    when(sessionDao.findById("ctisessionldap:us:q:win001",ECTISessionLdap.class)).thenReturn(Optional.of(responseSessionLdap));
    
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.delete(any(),any())).thenReturn(responseSessionLdap);
    when(sessionDao.delete(any(),any())).thenReturn(ectiSession);
    sessionService.deleteSession(deleteSession);
    verify(sessionDao,times(1)).findById("ldapagent:us:q:test11",ELdapAgent.class);
    verify(sessionDao,times(1)).findById("ctisessionldap:us:q:win001",ECTISessionLdap.class);
    verify(sessionDao,times(2)).delete(any(),any());
  }
  
  @Test
  public void testDeleteSession_emptyAgentId() {
    ECTISession deleteSession = new ECTISession("ctisession","us","q","0001");
    deleteSession.setAgentId("");
    
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.delete(any(),any())).thenReturn(ectiSession);
    sessionService.deleteSession(deleteSession);
    verify(sessionDao,times(1)).delete(any(),any());
  }
  
  @Test
  public void testDeleteSession_nullAgentId() {
    ECTISession deleteSession = new ECTISession("ctisession","us","q","0001");
    deleteSession.setAgentId(null);
    
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.delete(any(),any())).thenReturn(ectiSession);
    sessionService.deleteSession(deleteSession);
    verify(sessionDao,times(1)).delete(any(),any());
  }
  
  @Test(expected =DataNotFoundException.class)
  public void testDeleteSession_invalidAgentId() {
    ECTISession deleteSession = new ECTISession("ctisession","us","q","0001");
    deleteSession.setAgentId("xxx");
    ELdapAgent findLdapAgent = new ELdapAgent(config.getLdapAgentType(),"us","q","xxx");
    ELdapAgent responseLdapAgent = new ELdapAgent(config.getLdapAgentType(),"us","q","xxx");
    responseLdapAgent.setLdapId("win001");
    ECTISessionLdap responseSessionLdap = new ECTISessionLdap(config.getSessionLdapType(), "us", "q", "win001");
    responseSessionLdap.setSessionId("0001");
    
    when(couchbaseUtils.getId(findLdapAgent, ELdapAgent.class)).thenReturn("ldapagent:us:q:xxx");
    when(sessionDao.findById("ldapagent:us:q:xxx",ELdapAgent.class)).thenReturn(Optional.empty());
    
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    sessionService.deleteSession(deleteSession);
  }
  
  @Test
  public void testCreateSessionLdap() {
    SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    when(sessionDao.createOrUpdate(any(),any())).thenReturn(ectisessionLdap);
    sessionService.createSessionLdap(ectisessionLdap);
    verify(sessionDao,times(1)).createOrUpdate(any(),any());
  }
  
}
