package com.qvc.cti.data.edb.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.cti.data.edb.TestConfig;
import com.qvc.cti.data.edb.service.AgentService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
@ActiveProfiles("test")
public class AgentControllerTest {

	private MockMvc mockMvc;

	@MockBean
	AgentService agentService;
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	private TestingAuthenticationToken testingAuthenticationToken;

	@Mock
	private List<EAgent> agent;
	@Mock
	private EAgent eAgent;
	
	@Mock
	private List<EAgentLdap> agentLdaps;
	
	@Mock
	private EAgentLdap agentLdap;
	
	@Mock
	private EAgentExtension agentExtension;
	
	@Mock
    private List<ELdapAgent> ldapAgents;
	
	@Mock
	private ELdapAgent ldapAgent;
	
	@BeforeClass
	public static void beforeClass() {
		
		TestConfig.loadConfigSecurityFiles();
	}

	@Before
	public void beforeMethod() {
		this.mockMvc = webAppContextSetup(webApplicationContext).build();
		
		final User user = new User("edbJunitRestUser", "eSQIx8T7Ilujtl4@WkC6R",
				AuthorityUtils.createAuthorityList("ROLE_REST_API_CLIENT"));
		this.testingAuthenticationToken = new TestingAuthenticationToken(user, null);
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);

    	eAgent = new EAgent();
    	agent = new ArrayList<EAgent>();
    	eAgent.setType("cti");
    	eAgent.setOperationalCountryCode("us");
    	eAgent.setLineOfBusiness("q");    	
    	eAgent.setExtension("extid1234");
    	eAgent.setAgentId("idagent1234");
    	eAgent.setLdapId("ldapid1234");	
    	agent.add(eAgent);
    	
    	agentLdap= new EAgentLdap("ldapagent","us","q","ldapid1234");
    	agentLdaps= new ArrayList<>();
    	agentLdaps.add(agentLdap);
    	agentExtension= new EAgentExtension("agentextension","us","q","extid1234");
    	ldapAgents = new ArrayList<>();
    	ldapAgent = new ELdapAgent("ldapagent","us","q","ldapagentId");
    	ldapAgents.add(ldapAgent);
	}

	private static String asJsonString(final Object obj) throws JsonProcessingException {
		return new ObjectMapper().writeValueAsString(obj);
	}
	
	@SuppressWarnings("unchecked")
  @Test
	public void testCreateAgents() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.createAgents(anyList(), anyString(), anyString())).thenReturn(agent);
		
		mockMvc.perform(post("/order/management/v1/us/q/cti/agent/cms").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agent))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isCreated())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andDo(print());
	}
	
	@SuppressWarnings("unchecked")
	  @Test
		public void testCreateAgentsException() throws Exception{
			SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
			
			when(agentService.createAgents(anyList(), anyString(), anyString())).thenReturn(agent);
			ArrayList<EAgent> agentList = new ArrayList<>();
			//agentList.add(new EAgent());
			
			mockMvc.perform(post("/order/management/v1/us/q/cti/agent/cms").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agentList))
					.principal(testingAuthenticationToken)
					.header("application-code", "ABC").header("application-version", "XYZ"))
			.andExpect(status().is2xxSuccessful())
			.andDo(print());
		}
	
	@SuppressWarnings("unchecked")
  @Test
	public void testCreateAgentLdaps() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.createAgentLdaps(anyList())).thenReturn(agentLdaps);
		
		mockMvc.perform(post("/order/management/v1/us/q/cti/agent/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agentLdaps))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isCreated())
		.andDo(print());
	}
	@SuppressWarnings("unchecked")
  @Test
	public void testCreateAgents_emptyAgentId() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		agent.get(0).setAgentId(null);
		when(agentService.createAgents(anyList(), anyString(), anyString())).thenReturn(agent);
		
		mockMvc.perform(post("/order/management/v1/us/q/cti/agent/cms").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agent))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().is2xxSuccessful())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andDo(print());
	}
	
	@SuppressWarnings("unchecked")
  @Test
	public void testCreateAgentLdaps_emptyLdapId() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		agentLdaps.get(0).setLdapId(null);
		when(agentService.createAgentLdaps(anyList())).thenReturn(agentLdaps);
		
		mockMvc.perform(post("/order/management/v1/us/q/cti/agent/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agentLdaps))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isBadRequest())
		.andDo(print());
	}
	
	@Test
	public void testGetAgentByAgentId() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		when(agentService.findByAgentId(anyString(), anyString(), anyString())).thenReturn(new EAgent());
		
		mockMvc.perform(get("/order/management/v1/us/q/cti/agent/agent-id/agent1234").contentType(MediaType.APPLICATION_JSON)
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andDo(print());
	}	
	
	@Test
	public void testGetAgentByLdapId() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.findAgentByLdapId(anyString(), anyString(),any())).thenReturn(eAgent);
		
		mockMvc.perform(get("/order/management/v1/us/q/cti/agent/login-id/ldapid1234").contentType(MediaType.APPLICATION_JSON)
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.ldapId", is("ldapid1234")))
		.andDo(print());
	}
	@Test
	public void testGetAgentByExtension() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.findAgentByExtension(anyString(), anyString(),any())).thenReturn(eAgent);
		
		mockMvc.perform(get("/order/management/v1/us/q/cti/agent/extension/extid1234").contentType(MediaType.APPLICATION_JSON)
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.extension", is("extid1234")))
		.andDo(print());
	}
	@Test
	public void testUpdateAgent() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.updateAgent(any(),any())).thenReturn(eAgent);
		
		mockMvc.perform(put("/order/management/v1/us/q/cti/agent/login-id/ldapid1234").contentType(MediaType.APPLICATION_JSON).content(asJsonString(eAgent))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.ldapId", is("ldapid1234")))
		.andDo(print());
	}
	
	@Test
	public void testDeleteAgent() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.deleteAgent(any())).thenReturn(eAgent);
		
		mockMvc.perform(delete("/order/management/v1/us/q/cti/agent/cms").contentType(MediaType.APPLICATION_JSON).content(asJsonString(eAgent))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andDo(print());
	}
	@SuppressWarnings("unchecked")
  @Test
	public void testDeleteAgentLdaps() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		
		when(agentService.deleteAgentLdaps(anyList())).thenReturn(agentLdaps);
		
		mockMvc.perform(delete("/order/management/v1/us/q/cti/agent/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agentLdaps))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isOk())
		.andDo(print());
	}

	@SuppressWarnings("unchecked")
  @Test
	public void testDeleteAgentLdaps_emptyLdapId() throws Exception{
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
		agentLdaps.get(0).setLdapId(null);
		when(agentService.deleteAgentLdaps(anyList())).thenReturn(agentLdaps);
		
		mockMvc.perform(delete("/order/management/v1/us/q/cti/agent/login-id").contentType(MediaType.APPLICATION_JSON).content(asJsonString(agentLdaps))
				.principal(testingAuthenticationToken)
				.header("application-code", "ABC").header("application-version", "XYZ"))
		.andExpect(status().isBadRequest())
		.andDo(print());
	}
	
	   @Test
	    public void testfindLdapAgentByAgentId() throws Exception{
	        SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
	        when(agentService.findLdapAgentByAgentId(anyString(), anyString(), anyString())).thenReturn(new ELdapAgent());
	        
	        mockMvc.perform(get("/order/management/v1/us/q/cti/agent/ldap-agent/test11").contentType(MediaType.APPLICATION_JSON)
	                .principal(testingAuthenticationToken)
	                .header("application-code", "ABC").header("application-version", "XYZ"))
	        .andExpect(status().isOk())
	        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
	        .andDo(print());
	    }
	    @Test
	    public void testfindLdapAgentByAgentId_nullPrincipal() throws Exception{
	        SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
	        when(agentService.findLdapAgentByAgentId(anyString(), anyString(), anyString())).thenReturn(new ELdapAgent());
	        
	        mockMvc.perform(get("/order/management/v1/us/q/cti/agent/ldap-agent/test11").contentType(MediaType.APPLICATION_JSON)
	                .header("application-code", "ABC").header("application-version", "XYZ"))
	        .andExpect(status().isBadRequest())
	        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
	        .andDo(print());
	    }
	    
	    @Test
	    public void testfindAgentLdapByLdapId() throws Exception{
	        SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
	        when(agentService.findAgentLdapByLdapId(anyString(), anyString(), anyString())).thenReturn(new EAgentLdap());
	        
	        mockMvc.perform(get("/order/management/v1/us/q/cti/agent/agent-ldap/test11").contentType(MediaType.APPLICATION_JSON)
	                .principal(testingAuthenticationToken)
	                .header("application-code", "ABC").header("application-version", "XYZ"))
	        .andExpect(status().isOk())
	        .andDo(print());
	    }
	    @Test
	    public void testfindAgentLdapByLdapId_nullPrincipal() throws Exception{
	        SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
	        when(agentService.findAgentLdapByLdapId(anyString(), anyString(), anyString())).thenReturn(new EAgentLdap());
	        
	        mockMvc.perform(get("/order/management/v1/us/q/cti/agent/agent-ldap/t1").contentType(MediaType.APPLICATION_JSON)
	                .header("application-code", "ABC").header("application-version", "XYZ"))
	        .andExpect(status().isBadRequest())
	        .andDo(print());
	    }
	    @Test
	    public void testUpdateAgent_mismatchedLdapIds() throws Exception{
	        SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
	        EAgent eAgent1 = new EAgent();
	        eAgent1.setType("agent");
	        eAgent1.setOperationalCountryCode("us");
	        eAgent1.setLineOfBusiness("q");      
	        eAgent1.setExtension("ext1");
	        eAgent1.setAgentId("agent1");
	        eAgent1.setLdapId("ldapid1"); 
	        agent.add(eAgent);
	        
	        when(agentService.updateAgent(any(),any())).thenReturn(eAgent1);
	        
	        mockMvc.perform(put("/order/management/v1/us/q/cti/agent/login-id/ldapid123").contentType(MediaType.APPLICATION_JSON).content(asJsonString(eAgent1))
	                .principal(testingAuthenticationToken)
	                .header("application-code", "ABC").header("application-version", "XYZ"))
	        .andExpect(status().isBadRequest())
	        .andDo(print());
	    }
}