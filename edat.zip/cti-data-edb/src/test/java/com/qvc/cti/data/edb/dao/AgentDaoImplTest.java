package com.qvc.cti.data.edb.dao;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.dozer.DozerBeanMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.cti.data.edb.config.EdbCouchbaseRepository;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;

public class AgentDaoImplTest {

	@Mock
	private EdbCouchbaseRepository edbCouchbaseRepository;
	@Mock
	PropertiesConfig config;
	@Mock
	Authentication authentication;
	@Mock
	SecurityContext securityContext;	
	@Mock
	User user; 
	@Mock
	List<EAgent> agent;
	EAgent obj, obj2;
	
	@Mock
	EAgentLdap agentLdap;
	
	@Mock
	ELdapAgent ldapAgent;
	
	@Mock
	EAgentExtension agentExtension;
	
	private AgentDao agentDao;	
	
	@Mock
	private DozerBeanMapper dozerBeanMapper;
	
	@Mock
	private CouchbaseUtils couchbaseUtils;
	
    @Before
    public void init() {
    	initMocks(this);
    	agentDao = new AgentDaoImpl(config, edbCouchbaseRepository, dozerBeanMapper, couchbaseUtils);    	
    	
    	agent = new ArrayList<EAgent>();
    	obj = new EAgent();
    	obj.setType("agent");
    	obj.setOperationalCountryCode("us");
    	obj.setLineOfBusiness("q");    	
    	obj.setExtension("1234");
    	obj.setAgentId("idagent1234");
    	obj.setLdapId("ldapid1234");	
    	agent.add(obj);
    	
    	obj2 = new EAgent();
      	obj2.setType("agent");
      	obj2.setOperationalCountryCode("us");
      	obj2.setLineOfBusiness("q");     
      	obj2.setExtension("5678");
      	obj2.setAgentId("idagent1234");
      	obj2.setLdapId("ldapid1234");
    	
    	when(config.getExpiry()).thenReturn(42000);
    	when(config.getAppName()).thenReturn("cti-data-edb");
    	when(securityContext.getAuthentication()).thenReturn(authentication);
    	when(authentication.getPrincipal()).thenReturn(user);
    	when(user.getUsername()).thenReturn("TestUser");
    	SecurityContextHolder.setContext(securityContext);   
    	
    	agentLdap = new EAgentLdap();
    	agentLdap.setType("ldapagent");
    	agentLdap.setOperationalCountryCode("us");
    	agentLdap.setLineOfBusiness("q");    	
    	agentLdap.setAgentId("idagent1234");
    	agentLdap.setLdapId("idldap1234");
    	agentLdap.setId("id1234");	
    	
    	ldapAgent = new ELdapAgent();
    	ldapAgent.setType("agentldap");
    	ldapAgent.setOperationalCountryCode("us");
    	ldapAgent.setLineOfBusiness("q");
    	ldapAgent.setAgentId("idagent1234");
    	ldapAgent.setLdapId("idldap1234");
    	ldapAgent.setId("id1234");
    	
    	agentExtension = new EAgentExtension();
    	agentExtension.setType("agentextension");
    	agentExtension.setOperationalCountryCode("us");
    	agentExtension.setLineOfBusiness("q");    	
    	agentExtension.setAgentId("idagent1234");
    	agentExtension.setExtension("ext1234");	
    	
    }
    
    @Test
    public void testFindById() {
    	when(edbCouchbaseRepository.findById(anyString(), any())).thenReturn(Optional.of(obj));
    	Optional<EAgent> response = agentDao.findById("agent:us:q:agentid",EAgent.class);
    	Assert.assertNotNull(response);     	
    }
    @Test
    public void testFindAgentLdapById() {
    	when(edbCouchbaseRepository.findById(anyString(), any())).thenReturn(Optional.of(obj));
    	Optional<EAgentLdap> response = agentDao.findById("agentldap:us:q:ldapid",EAgentLdap.class);
    	Assert.assertNotNull(response);     	
    }
    
    @Test
    public void testCreateOrUpdateAgent_ExistingAgentDoc() {
      when(couchbaseUtils.getId(any(), any())).thenReturn("agent:us:q:idagent1234"); 
      when(agentDao.findById(anyString(),any())).thenReturn(Optional.of(obj));
      EAgent response = agentDao.createOrUpdateAgent(obj,"comerceRestUser");
      Assert.assertNotNull(response);
    }
    
    @Test
    public void testCreateOrUpdateAgent_NoLDAPId() {
    	obj.setExtension(null);
    	obj.setLdapId(null);
    	when(config.getDocumentVersion()).thenReturn("v1");
    	when(agentDao.findById(anyString(),any())).thenReturn(Optional.empty());
      when(couchbaseUtils.getId(any(), any())).thenReturn("ldapagent:us:q:idagent1234");  
    	when(edbCouchbaseRepository.upsert(obj, EAgent.class,42000)).thenReturn(obj); 
    	when(edbCouchbaseRepository.upsert(agentExtension, EAgentExtension.class,42000)).thenReturn(agentExtension); 
    	EAgent response = agentDao.createOrUpdateAgent(obj,"comerceRestUser");
    	Assert.assertNotNull(response);
    }
    
    @Test
    public void testCreateOrUpdateAgent_LDAPDocPopulated() {
      obj.setExtension(null);
      when(config.getDocumentVersion()).thenReturn("v1");
      when(couchbaseUtils.getId(any(), any())).thenReturn("ldapagent:us:q:idagent1234"); 
      when(agentDao.findById(anyString(),any())).thenReturn(Optional.of(obj2));
      when(edbCouchbaseRepository.upsert(obj, EAgent.class,42000)).thenReturn(obj); 
      when(edbCouchbaseRepository.upsert(agentExtension, EAgentExtension.class,42000)).thenReturn(agentExtension); 
      EAgent response = agentDao.createOrUpdateAgent(obj,"comerceRestUser");
      Assert.assertNotNull(response);
    }
    
    @Test
    public void testCreateOrUpdateAgent_LDAPDocLocatedAndUpdateExtension() {
      //obj.setExtension(null);
      obj.setLdapId(null);
      when(config.getDocumentVersion()).thenReturn("v1");
      when(couchbaseUtils.getId(obj, EAgent.class)).thenReturn("agent:us:q:idagent1234");
      when(agentDao.findById(null, EAgent.class)).thenReturn(Optional.empty());
      when(couchbaseUtils.getId(ldapAgent, ELdapAgent.class)).thenReturn("ldapagent:us:q:idagent1234");
      when(agentDao.findById(null, ELdapAgent.class)).thenReturn(Optional.of(ldapAgent));
      when(edbCouchbaseRepository.upsert(obj, EAgent.class,42000)).thenReturn(obj);
      when(edbCouchbaseRepository.upsert(agentExtension, EAgentExtension.class,42000)).thenReturn(agentExtension);
      when(dozerBeanMapper.map(obj, EAgentExtension.class)).thenReturn(agentExtension);
      EAgent response = agentDao.createOrUpdateAgent(obj,"comerceRestUser");
      Assert.assertNotNull(response);
    }

    @Test
    public void testCreateOrUpdateAgentLdap() {
      when(edbCouchbaseRepository.upsert(agentLdap, EAgentLdap.class)).thenReturn(agentLdap);
      when(edbCouchbaseRepository.upsert(ldapAgent, ELdapAgent.class)).thenReturn(ldapAgent);
      when(dozerBeanMapper.map(agentLdap, ELdapAgent.class)).thenReturn(ldapAgent);      
    	EAgentLdap response = agentDao.createOrUpdateAgentLdap(agentLdap,"comerceRestUser");
    	Assert.assertNotNull(response);     	
    }
    
    @Test
    public void testCreateAgentExtension() {
    	when(edbCouchbaseRepository.create(agentExtension, EAgentExtension.class)).thenReturn(agentExtension); 
    	EAgentExtension response = agentDao.createAgentExtension(agentExtension,"comerceRestUser");
    	Assert.assertNotNull(response);     	
    }
    @Test
    public void testUpdateAgent() {
    	obj.setExtension(null);
    	when(edbCouchbaseRepository.update(obj, EAgent.class)).thenReturn(obj); 
    	EAgent response = agentDao.updateAgent(obj,"comerceRestUser");
    	Assert.assertNotNull(response);     	
    }
    
    @Test
    public void testDeleteAgent() {
    	
    	doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				return null;
			}
		}).when(edbCouchbaseRepository).delete(any(),any());
    	agentDao.delete(obj,EAgent.class);
    } 
    @Test
    public void testDeleteAgentLdap() {
    	doAnswer(new Answer() {
			@Override
			public Object answer(InvocationOnMock invocation) throws Throwable {
				return null;
			}
		}).when(edbCouchbaseRepository).delete(any(),any());
    	agentDao.delete(new EAgentLdap("ldapagent","us","q","ldapid"),EAgentLdap.class);
    }

    @Test
    public void testDeleteLdapAgent() {
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                return null;
            }
        }).when(edbCouchbaseRepository).delete(any(),any());
        agentDao.delete(new ELdapAgent("ldapagent","us","q","ldapagentid"),ELdapAgent.class);
        verify(edbCouchbaseRepository,times(1)).delete(any(),any());
    } 
    
    
}
