package com.qvc.cti.data.edb.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.dozer.DozerBeanMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import com.couchbase.client.java.error.DocumentDoesNotExistException;
import com.qvc.coast.edb.data.transformer.cti.EAgent;
import com.qvc.coast.edb.data.transformer.cti.EAgentExtension;
import com.qvc.coast.edb.data.transformer.cti.EAgentLdap;
import com.qvc.coast.edb.data.transformer.cti.ELdapAgent;
import com.qvc.coast.web.client.error.BadRequestException;
import com.qvc.coast.web.client.error.DataNotFoundException;
import com.qvc.cti.data.edb.config.PropertiesConfig;
import com.qvc.cti.data.edb.dao.AgentDao;
import com.qvc.edb.common.utils.reflection.CouchbaseUtils;

public class AgentServiceImplTest {
	
	private AgentService service;
	
	@Mock
	AgentDao agentDao;

	@Mock
	CouchbaseUtils couchbaseUtils;
	
	@Mock
	PropertiesConfig config;

	@Mock
	List<EAgent> agent;
	@Mock
	EAgentLdap agentLdap;
	
	@Mock
	EAgent eAgent;
	
	@Mock
	EAgentExtension agentExtension;
	private TestingAuthenticationToken testingAuthenticationToken;
	
	@Mock
    DozerBeanMapper dozerBeanMapper;
	
    @Before
    public void init() {
    	initMocks(this);
    	service = new AgentServiceImpl(agentDao, couchbaseUtils, config,dozerBeanMapper);
    	agent = new ArrayList<EAgent>();
    	
    	eAgent = new EAgent();
    	eAgent.setType("agent");
    	eAgent.setOperationalCountryCode("us");
    	eAgent.setLineOfBusiness("q");    	
    	eAgent.setExtension("ext1234");
    	eAgent.setAgentId("idagent1234");
    	eAgent.setId("id1234");	
    	agent.add(eAgent);
    	
    	agentLdap = new EAgentLdap();
    	agentLdap.setType("ldapagent");
    	agentLdap.setOperationalCountryCode("us");
    	agentLdap.setLineOfBusiness("q");    	
    	agentLdap.setAgentId("idagent1234");
    	agentLdap.setLdapId("idldap1234");
    	agentLdap.setId("id1234");	
    	
    	agentExtension = new EAgentExtension();
    	agentExtension.setType("agentextension");
    	agentExtension.setOperationalCountryCode("us");
    	agentExtension.setLineOfBusiness("q");    	
    	agentExtension.setAgentId("idagent1234");
    	agentExtension.setExtension("ext1234");	
    	
    	when(config.getAgentType()).thenReturn("agent");
    	when(config.getAgentExtensionType()).thenReturn("agentextension");
    	when(config.getLdapAgentType()).thenReturn("ldapagent");
    	when(config.getAgentLdapType()).thenReturn("agentldap");
    	
		final User user = new User("edbJunitRestUser", "eSQIx8T7Ilujtl4@WkC6R",
				AuthorityUtils.createAuthorityList("ROLE_REST_API_CLIENT"));
		this.testingAuthenticationToken = new TestingAuthenticationToken(user, null);
		SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    }
     
    @Test
    public void createAgents() {
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(eAgent, EAgent.class)).thenReturn("agent:us:q:idagent1234");
    	when(agentDao.createOrUpdateAgent(any(),any())).thenReturn(eAgent);
    	
    	List<EAgent> response = service.createAgents(agent, "us", "qvc");
    	Assert.assertNotNull(response);
    }
    @Test(expected=BadRequestException.class)
    public void createAgentsException() {
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(eAgent, EAgent.class)).thenReturn("agent:us:q:idagent1234");
    	when(agentDao.createOrUpdateAgent(any(),any())).thenReturn(eAgent);
    	List<EAgent> eagentlist = new ArrayList<>();
    	eagentlist.add(new EAgent());
    	List<EAgent> response = service.createAgents(eagentlist, "us", "qvc");
    	Assert.assertNotNull(response);
    }
    
    @Test(expected=BadRequestException.class)
    public void createAgentsBadRequest() {
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(eAgent, EAgent.class)).thenReturn("agent:us:q:idagent1234");
    	when(agentDao.createOrUpdateAgent(any(),any())).thenReturn(null);
    	
    	List<EAgent> response = service.createAgents(agent, "us", "qvc");
    	Assert.assertNotNull(response);
    }
    
    @Test
    public void createAgentLdaps() {
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.createOrUpdateAgentLdap(any(),any())).thenReturn(agentLdap);
    	
    	List<EAgentLdap> response = service.createAgentLdaps(Arrays.asList(agentLdap));
    	Assert.assertNotNull(response);
    }
    
    @Test
    public void getAgentByAgentId() {
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(any(), any())).thenReturn("agent:us:q:idagent1234");    	
    	assertNotNull(service.findByAgentId("us", "q", "idagent1234"));
    }
    
    @Test(expected=DataNotFoundException.class)
    public void getAgentByAgentId_NotFound() {
    	when(agentDao.findById(anyString(),any())).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(any(), any())).thenReturn("agent:us:q:idagent1234");    	
    	service.findByAgentId("us", "q", "idagent1234");
    } 
    
    @Test
    public void getAgentByLdapId() {
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.of(agentLdap));
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234");    
    	service.findAgentByLdapId("us", "q", "idldap1234");
    }
    
    @Test(expected=DataNotFoundException.class)
    public void getAgentByLdapId_NotFound() {
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234");    
    	service.findAgentByLdapId("us", "q", "idldap1234");
    } 
    
    @Test
    public void getAgentByExtension() {
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.of(agentExtension));
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234");    
    	service.findAgentByExtension("us", "q", "ext1234");
    }
    
    @Test(expected=DataNotFoundException.class)
    public void getAgentByExtension_NotFound() {
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234");    
    	service.findAgentByExtension("us", "q", "ext1234");
    } 
    
    @Test
    public void testUpdateAgent() {
    	eAgent.setLdapId("idldap1234");
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.of(agentLdap));
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234"); 
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.of(agentExtension));
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	EAgent response = service.updateAgent(eAgent,"idldap1234");
    	Assert.assertNull(response);
    }
    @Test()
    public void testUpdateAgent_agentLdapNotFound() {
    	eAgent.setLdapId("idldap1234");
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234"); 
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.of(agentExtension));
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	assertNull(service.updateAgent(eAgent,"idldap1234"));
    }
    @Test
    public void testUpdateAgent_emptyAgentExtension() {
    	eAgent.setLdapId("idldap1234");
    	eAgent.setExtension(null);
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.of(agentLdap));
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234"); 
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.of(agentExtension));
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	EAgent response = service.updateAgent(eAgent,"idldap1234");
    	Assert.assertNull(response);
    }
    @Test
    public void testUpdateAgent_AgentExtensionNotFound() {
    	eAgent.setLdapId("idldap1234");
    	SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
    	when(agentDao.findById("agentldap:us:q:idldap1234",EAgentLdap.class)).thenReturn(Optional.of(agentLdap));
    	when(couchbaseUtils.getId(new EAgentLdap("agentldap","us","q","idldap1234"), EAgentLdap.class)).thenReturn("agentldap:us:q:idldap1234"); 
    	when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.of(eAgent));
    	when(couchbaseUtils.getId(new EAgent("agent","us","q","idagent1234"), EAgent.class)).thenReturn("agent:us:q:idagent1234"); 
    	when(agentDao.findById("agentextension:us:q:ext1234",EAgentExtension.class)).thenReturn(Optional.empty());
    	when(couchbaseUtils.getId(new EAgentExtension("agentextension","us","q","ext1234"), EAgentExtension.class)).thenReturn("agentextension:us:q:ext1234"); 
    	when(agentDao.createAgentExtension(any(), any())).thenReturn(agentExtension);
    	EAgent response = service.updateAgent(eAgent,"idldap1234");
    	Assert.assertNull(response);
    }
    
    @Test
    public void testDeleteAgent() {
    	when(couchbaseUtils.getId(any(), any())).thenReturn("agentExtension:us:q:extid1234");
    	when(agentDao.findById(anyString(),any())).thenReturn(Optional.of(agentExtension));
    	when(agentDao.delete(eAgent, EAgent.class)).thenReturn(eAgent);
    	when(agentDao.delete(agentExtension, EAgentExtension.class)).thenReturn(agentExtension);
    	Assert.assertNotNull(service.deleteAgent(eAgent));
    }
     
    @Test
    public void testDeleteAgent_emptyExtension() {
    	eAgent.setExtension(null);
    	when(agentDao.delete(eAgent, EAgent.class)).thenReturn(eAgent);
    	Assert.assertNotNull(service.deleteAgent(eAgent));
    }
    
    @Test
    public void testDeleteAgentLdaps() {
      ELdapAgent eLdapAgent = new ELdapAgent();
      when(agentDao.delete(agentLdap, EAgentLdap.class)).thenReturn(agentLdap);
      when(agentDao.delete(eLdapAgent, ELdapAgent.class)).thenReturn(eLdapAgent);
      when(dozerBeanMapper.map(agentLdap,ELdapAgent.class)).thenReturn(eLdapAgent);
      Assert.assertNotNull(service.deleteAgentLdaps(Arrays.asList(agentLdap)));
      verify(agentDao,times(1)).delete(agentLdap, EAgentLdap.class);
      verify(agentDao,times(1)).delete(eLdapAgent, ELdapAgent.class);
      verify(dozerBeanMapper,times(1)).map(agentLdap,ELdapAgent.class);
    }
    
    @Test(expected=BadRequestException.class)
    public void testCreateAgents_invalidAgents() {
      SecurityContextHolder.getContext().setAuthentication(this.testingAuthenticationToken);
      when(agentDao.findById("agent:us:q:idagent1234",EAgent.class)).thenReturn(Optional.empty());
      when(couchbaseUtils.getId(eAgent, EAgent.class)).thenReturn("agent:us:q:idagent1234");
      when(agentDao.createOrUpdateAgent(any(),any())).thenReturn(null);
      
      service.createAgents(agent, "us", "qvc");
    }
    
    @SuppressWarnings("unchecked")
    @Test(expected=DocumentDoesNotExistException.class)
    public void testDeleteAgents_invalidAgent() {
      when(couchbaseUtils.getId(any(), any())).thenReturn("agentExtension:us:q:extid1234");
      when(agentDao.findById(anyString(),any())).thenReturn(Optional.of(agentExtension));
      when(agentDao.delete(eAgent, EAgent.class)).thenThrow(DocumentDoesNotExistException.class);
      when(agentDao.delete(agentExtension, EAgentExtension.class)).thenReturn(agentExtension);
      service.deleteAgent(eAgent);
      verify(agentDao,times(1)).delete(eAgent, EAgent.class);
      verify(agentDao,times(0)).delete(agentExtension, EAgentExtension.class);
      verify(couchbaseUtils,times(0)).getId(any(), any());
    }
    
    @SuppressWarnings("unchecked")
    @Test(expected=DocumentDoesNotExistException.class)
    public void testDeleteAgentLdaps_invalidAgentLdap() {
      ELdapAgent eLdapAgent = new ELdapAgent();
      when(agentDao.delete(agentLdap, EAgentLdap.class)).thenThrow(DocumentDoesNotExistException.class);
      when(agentDao.delete(eLdapAgent, ELdapAgent.class)).thenReturn(eLdapAgent);
      service.deleteAgentLdaps(Arrays.asList(agentLdap));
      verify(agentDao,times(1)).delete(eLdapAgent, ELdapAgent.class);
      verify(agentDao,times(0)).delete(eLdapAgent, ELdapAgent.class);
    }
    
    @Test
    public void testfindLdapAgentByAgentId() {
      when(couchbaseUtils.getId(new ELdapAgent("ldapagent", "us", "q", "test11"), ELdapAgent.class)).thenReturn("ldapagent:us:q:test11");
      when(agentDao.findById("ldapagent:us:q:test11",ELdapAgent.class)).thenReturn(Optional.of(new ELdapAgent()));
      service.findLdapAgentByAgentId("us", "q", "test11");
      verify(couchbaseUtils,times(1)).getId(new ELdapAgent("ldapagent", "us", "q", "test11"), ELdapAgent.class);
      verify(agentDao,times(1)).findById("ldapagent:us:q:test11",ELdapAgent.class);
    }
    
    @Test(expected = DataNotFoundException.class)
    public void testfindLdapAgentByAgentId_invalidInput() {
      when(couchbaseUtils.getId(new ELdapAgent("ldapagent", "us", "q", "xx"), ELdapAgent.class)).thenReturn("ldapagent:us:q:xx");
      when(agentDao.findById("ldapagent:us:q:xx",ELdapAgent.class)).thenReturn(Optional.empty());
      service.findLdapAgentByAgentId("us", "q", "xx");
      verify(couchbaseUtils,times(0)).getId(new ELdapAgent("ldapagent", "us", "q", "xx"), ELdapAgent.class);
      verify(agentDao,times(0)).findById("ldapagent:us:q:xx",ELdapAgent.class);
    }
    
    @Test
    public void testfindAgentLdapByLdapId() {
      when(couchbaseUtils.getId(new EAgentLdap("agentldap", "us", "q", "win001"), EAgentLdap.class)).thenReturn("agentldap:us:q:win001");
      when(agentDao.findById("agentldap:us:q:win001",EAgentLdap.class)).thenReturn(Optional.of(new EAgentLdap()));
      service.findAgentLdapByLdapId("us", "q", "win001");
      verify(couchbaseUtils,times(1)).getId(new EAgentLdap("agentldap", "us", "q", "win001"), EAgentLdap.class);
      verify(agentDao,times(1)).findById("agentldap:us:q:win001",EAgentLdap.class);
    }
    
    @Test(expected = DataNotFoundException.class)
    public void testfindAgentLdapByLdapId_invalidInput() {
      when(couchbaseUtils.getId(new EAgentLdap("agentldap", "us", "q", "xyz"), EAgentLdap.class)).thenReturn("agentldap:us:q:xyz");
      when(agentDao.findById("agentldap:us:q:xyz",EAgentLdap.class)).thenReturn(Optional.empty());
      service.findAgentLdapByLdapId("us", "q", "xyz");
      verify(couchbaseUtils,times(0)).getId(new EAgentLdap("agentldap", "us", "q", "xyz"), EAgentLdap.class);
      verify(agentDao,times(0)).findById("agentldap:us:q:xyz",EAgentLdap.class);
    }
}
