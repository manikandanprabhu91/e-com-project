#!/bin/sh

### Enter application name and port within the quotes below ###
APP_NAME="cti-data-edb"
APP_PORT="12206"

echo "Stopping Current Instances"
for i in $(ps -fu $USER | grep $APP_PORT | grep -v grep |  awk '{print $2}')
do
        kill $i
done

echo "Wait here for 5 seconds....."
sleep 5

count=`ps -fu $USER | grep $APP_PORT | grep -v grep |  awk '{print $2}' | wc -l`
endcount=0

while [[ $count -gt 0 && $endcount -lt 2 ]]
do
        sleep 1
        endcount=$(( $endcount + 1 ))
        count=`ps -fu $USER | grep $APP_PORT | grep -v grep | awk '{print $2}' | wc -l`
        echo "$count still running......"
done

if [[ $count -ne 0 ]]
        then
                echo "Killing with extreme predjudice."
                for i in $(ps -fu $USER | grep $APP_PORT | grep -v grep |  awk '{print $2}')
                do
                        kill -9 $i
                done
fi

export TIMESTAMP=`date '+%Y-%m-%d_%H:%M:%S'`
echo "$TIMESTAMP:Script Complete " >> /logs/$APP_NAME/shutdown.out 2>&1 &
