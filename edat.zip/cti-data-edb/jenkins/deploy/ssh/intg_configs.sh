#!/bin/bash

echo "........Unzipping config files........"
unzip /tmp/cti-data-edb/config.zip -d /tmp/cti-data-edb/
echo "........Config file unzip complete........"