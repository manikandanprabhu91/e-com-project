#!/bin/bash

echo "........Transferring config file to FP VM........"
if [ ! -d "/applications/common/config/cti-data-edb" ]; then
   mkdir -vp /applications/common/config/cti-data-edb/
fi
mv /tmp/cti-data-edb/config/Acceptance/US/FP/*.* /applications/common/config/cti-data-edb/
chmod 776 /applications/common/config/cti-data-edb/*.*
echo "........Config file transfer complete........"

echo "Shutting down Service"
sudo -u tomcat /applications/common/scripts/cti-data-edb/shutdown.sh

echo "........Pausing for 5 seconds to allow shutdown to finish........"
sleep 10

echo "........Transferring script files to FP VM........"
if [ ! -d "/applications/common/scripts/cti-data-edb" ]; then
   mkdir -vp /applications/common/scripts/cti-data-edb/
fi
mv -f /tmp/cti-data-edb/scripts/Acceptance/US/FP/*.* /applications/common/scripts/cti-data-edb/
chmod 775 /applications/common/scripts/cti-data-edb/*.*
echo "........Script files transfer complete........"

echo "Moving jar to bin, cleaning up, and changing location"
if [ ! -d "/applications/common/bin/cti-data-edb" ]; then
   mkdir -vp /applications/common/bin/cti-data-edb/
fi
rm -rf /applications/common/bin/cti-data-edb/*.jar
cp /tmp/cti-data-edb/cti-data-edb*.jar /applications/common/bin/cti-data-edb/
rm -rf /tmp/cti-data-edb
cd /applications/common/bin/cti-data-edb
chmod 775 /applications/common/bin/cti-data-edb/*.jar 
echo "...Starting Service..."
sudo -u tomcat /applications/common/scripts/cti-data-edb/startup.sh
sleep 30
echo "...Service instance is up!..."