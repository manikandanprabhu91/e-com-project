package com.qvc.cti.cart.transformer.config;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.client.RestTemplate;
import com.qvc.cti.cart.transformer.util.UtilMethods;

/**
 * @author c004528
 *
 */
@Configuration
@EnableGlobalMethodSecurity(securedEnabled = true)
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  /** Logger */
  private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);

  /**
   * Location of security file dependent on environment in which we are running
   */
  @Value("${security.fileLocation}")
  private String securityFileLocation;

  @Autowired
  private Environment environment;

  private static final String PROFILE_TEST = "test";

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.authorizeRequests().antMatchers("/swagger-ui*", "/info", "/health**","/order-flow/order-capture/**/cti/cart/transformer/tel-ani-dnis").permitAll().antMatchers("/order-flow/**").fullyAuthenticated().and().httpBasic()
        .and().csrf().disable();
  }

  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(inMemoryUserDetailsManager());
  }

  @Bean
  public InMemoryUserDetailsManager inMemoryUserDetailsManager() throws IOException {
    return new InMemoryUserDetailsManager(getSpringUserProperties());
  }

  @Bean(name = "springUserProperties")
  public Properties getSpringUserProperties() throws IOException {
    Properties props = null;
    try {
      if (Arrays.asList(environment.getActiveProfiles()).contains(PROFILE_TEST)) {
        props = PropertiesLoaderUtils.loadProperties(new ClassPathResource("/config/spring.security.rest.client.properties"));
      } else {
        props =
            PropertiesLoaderUtils.loadProperties(new FileSystemResource(securityFileLocation + File.separatorChar + "spring.security.rest.client.properties"));
      }
    } catch (IOException e) {
      logger.error(UtilMethods.generateShortErrorMessage(e) + "|Could not load spring.security.rest.client.properties file", e);
    }
    return props;
  }

  /**
   * Rest template.
   *
   * @return the rest template
   */
  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }
}
