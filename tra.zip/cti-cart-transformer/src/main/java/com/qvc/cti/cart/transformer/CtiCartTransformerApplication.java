package com.qvc.cti.cart.transformer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * Cart Transformer boot application runner
 * 
 * @author   :- c004528
 * @version  :- August 7,2019
 *
 */
@SpringBootApplication
@EnableFeignClients
@ComponentScan("com.qvc.cti.cart.transformer.*")
public class CtiCartTransformerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtiCartTransformerApplication.class, args);
	}

}
