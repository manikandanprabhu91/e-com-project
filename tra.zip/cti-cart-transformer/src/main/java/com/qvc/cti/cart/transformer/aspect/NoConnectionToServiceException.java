package com.qvc.cti.cart.transformer.aspect;

public class NoConnectionToServiceException extends RuntimeException {

  private static final long serialVersionUID = -2143863057743070301L;

  public NoConnectionToServiceException(Throwable t) {
    super(t);
  }
}
