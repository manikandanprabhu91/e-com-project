package com.qvc.cti.cart.transformer.service;

import java.text.MessageFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.stereotype.Service;

import com.qvc.cti.cart.transformer.feign.CtiCartTransformerSessionServiceProxy;
import com.qvc.order.model.cti.CTISession;

import feign.FeignException;

/**
 * Cart Transformer service save cartTransformerSession
 * 
 * @author :- c004528
 * @version :- August 7,2019
 *
 */
@Service
public class CartTransformerServiceImpl implements CartTransformerService {

	private Logger logger = LoggerFactory.getLogger(CartTransformerServiceImpl.class.getName());
	
	@Value("${cti.session.rest.user}")
	private String ctiSessionUser;
	
	@Value("${cti.session.rest.password}")
	private String ctiSessionUserPass;

	@Autowired
	private CtiCartTransformerSessionServiceProxy ctiCartTransformerSessionServiceProxy;
	
	@Autowired
	private FixedLengthConversionService fixedLengthConversionService;
	
	public static final String AUTHORISATION_KEY = "Authorization";

	/**
	 * method creates and save ctiSession along with telAniDnisMsg String
	 * 
	 * @param version
	 * @param countryCode
	 * @param lob
	 * @param telAniDnisMsg
	 * @param headers
	 * @return String
	 */
	@Override
	public String saveCartTransformerSession(String version, String countryCode, String lob, String telAniDnisMsg,
			HttpHeaders headers) {
		String methodName = "saveCartTransformerSession";
		ResponseEntity<CTISession> serviceCallResponse = null;
		try {
			// string telAniDnisMsg
			CTISession ctiSession = new CTISession();
			ctiSession.setDocumentVersion(version);
			ctiSession.setCallInfo(fixedLengthConversionService.extractCallInfo(telAniDnisMsg));//call info
			ctiSession.setSessionId(fixedLengthConversionService.extractCallKey(telAniDnisMsg));//cti key
			ctiSession.setLineOfBusiness(lob);
			ctiSession.setOperationalCountryCode(countryCode);
			ctiSession.setTelAniDnisMsg(telAniDnisMsg);
			serviceCallResponse = ctiCartTransformerSessionServiceProxy.saveCartTransformerSession(version, countryCode,lob, ctiSession, getHttpHeaders());
			logger.info(MessageFormat.format("{0}|cti-cart-transformer service " + "telAniDnisMsg[{1}] ", methodName,telAniDnisMsg));
		} catch (FeignException e) {
			logger.error(MessageFormat.format("{0}|cti-cart-transformer service session not created "
					+ "telAniDnisMsg[{1}] : Error Message: [{2}] ", methodName, telAniDnisMsg, e.getMessage()));
		}
		if (serviceCallResponse != null && serviceCallResponse.getStatusCode().equals(HttpStatus.CREATED)) {
			return "STRATUS00000";
		} else {
			return "STRATUS99999";
		}
	}
	
	 private HttpHeaders getHttpHeaders() {
		    HttpHeaders headers = new HttpHeaders();
		    try {
		      String auth = this.ctiSessionUser + ":" + this.ctiSessionUserPass;
		      byte[] encodedAuth = Base64.encode(auth.getBytes());
		      String authHeader = "Basic " + new String(encodedAuth);
		      headers.set(AUTHORISATION_KEY, authHeader);
		    } catch (Exception e) {
		      // This is intentional. Do nothing here.
		    }
		    return headers;
		  }
}