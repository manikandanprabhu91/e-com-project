package com.qvc.cti.cart.transformer.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.qvc.order.model.cti.CallInfo;
import com.qvc.order.model.cti.LegacyOrder;
import com.qvc.order.model.cti.LegacyOrderLine;

@Service
public class FixedLengthConversionServiceImpl implements FixedLengthConversionService {

  int start;
  int end;
  
  @Override
  public CallInfo extractCallInfo(String stratusFixedLength) {
    
    CallInfo callInfo = new CallInfo();
    
    start = 35; end = start + 10;
    callInfo.setDnis(stratusFixedLength.substring(start,end));
    start = end++; end = start + 10;
    callInfo.setAni(stratusFixedLength.substring(start, end));
    start = end++; end = start + 1;
    callInfo.setSiteId(stratusFixedLength.substring(start, end));
    start = end++; end = start + 4;
    callInfo.setCallId(stratusFixedLength.substring(start, end));
    start = end++; end = start + 2;
    callInfo.setCallDay(stratusFixedLength.substring(start, end));
    start = end++; end = start + 4;
    callInfo.setCallTime(stratusFixedLength.substring(start, end));
    start = end++; end = start + 3;
    callInfo.setReservedATT(stratusFixedLength.substring(start, end));
    start = end++; end = start + 3;
    callInfo.setReservedQVC(stratusFixedLength.substring(start, end));
    start = end++; end = start + 1;
    callInfo.setCallType(stratusFixedLength.substring(start, end));
    start = end+5; end = start + 10;
    callInfo.setExtension(stratusFixedLength.substring(start, end));
    start = end+5; end = start + 10;
    callInfo.setVdnTo(stratusFixedLength.substring(start, end).trim());
    start = end++; end = start + 1;
    callInfo.setQvcCallType(stratusFixedLength.substring(start, end));
    start = end++; end = start + 1;
    callInfo.setDestinationCode(stratusFixedLength.substring(start, end));
    
    return callInfo;
  }
  
  @Override
  public String extractCallKey(String stratusFixedLength) {
       
    start = 30; end = start + 36;
    return(stratusFixedLength.substring(start, end).trim());
  }
  
  @Override
  public LegacyOrder extractLegacyOrder(String stratusFixedLength){
    
    LegacyOrder legacyOrder = new LegacyOrder();
    start = 997; end = start + 1;
    Integer lineCount = Integer.valueOf(stratusFixedLength.substring(start, end));
    
    if (lineCount > 0) {
      List <LegacyOrderLine> legacyOrderLines = new ArrayList<>();
      for(int i = 0; i < lineCount; i++) {
        
        LegacyOrderLine legacyOrderLine = new LegacyOrderLine();
        
        start = end++; end = start + 7;
        legacyOrderLine.setProductId(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setItemId(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setColorSku(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setSizeSku(stratusFixedLength.substring(start, end));
        start = end++; end = start + 4;
        legacyOrderLine.setQuanity(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 4;
        legacyOrderLine.setWeight(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 4;
        legacyOrderLine.setCreditLines(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 7;
        legacyOrderLine.setStartQuantity(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 3;
        legacyOrderLine.setSalesDivison(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setSalesDivisionActual(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setDifferentLineSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setParentProduct(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setParentSkn(stratusFixedLength.substring(start, end));
        start = end++; end = start + 4; 
        legacyOrderLine.setSsCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 4;
        legacyOrderLine.setRecType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 8;
        legacyOrderLine.setSourceCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setShippableSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 5;
        legacyOrderLine.setEmployeeDiscountRate(Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end))));
        start = end++; end = start + 2;
        legacyOrderLine.setTaxType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setCoType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setShipAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 2;
        legacyOrderLine.setShipMethod(stratusFixedLength.substring(start, end));
        start = end++; end = start + 47;
        legacyOrderLine.setSknDescription(stratusFixedLength.substring(start, end));
        start = end++; end = start + 15;
        legacyOrderLine.setSknSubtext(stratusFixedLength.substring(start, end));
        start = end++; end = start + 47;
        legacyOrderLine.setProductDescription(stratusFixedLength.substring(start, end));
        start = end++; end = start + 15;
        legacyOrderLine.setProductSubtext(stratusFixedLength.substring(start, end));
        start = end++; end = start + 31;
        legacyOrderLine.setColorSizeDescription(stratusFixedLength.substring(start, end));
        start = end; end = start + 7;
        legacyOrderLine.setUnitCost(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end; end = start + 7;
        legacyOrderLine.setMsrpPrice(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end; end = start + 7;
        legacyOrderLine.setOnAirPrice(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end; end = start + 7;
        legacyOrderLine.setSpecialPrice(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end; end = start + 4;
        legacyOrderLine.setPriceCode(stratusFixedLength.substring(start, end));
        start = end; end = start + 9;
        legacyOrderLine.setCommRate(Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end))));
        start = end; end = start + 1;
        legacyOrderLine.setUpsellSwitch(stratusFixedLength.substring(start, end));
        start = end; end = start + 7;
        legacyOrderLine.setUpsellId(stratusFixedLength.substring(start, end));
        start = end; end = start + 4;
        legacyOrderLine.setUpsellSSCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 210;
        legacyOrderLine.setUpsellDescription(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setSkuSknId(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setSkuColorCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setSkuSizeCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setMaintenanceInventory(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setCreditTermsSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setCreditTermsType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setCreditTermsNumberofInstallments(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 20;
        legacyOrderLine.setCreditTermsAllowedMethods(stratusFixedLength.substring(start, end));
        start = end++; end = start + 8;
        legacyOrderLine.setCreditTermsDeferToDate(stratusFixedLength.substring(start, end));
        start = end++; end = start + 142;
        legacyOrderLine.setFamTable(stratusFixedLength.substring(start, end));
        start = end++; end = start + 9;
        legacyOrderLine.setFractDeallocationQuantity(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 4;
        legacyOrderLine.setProjCancelRate(Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end))));
        start = end++; end = start + 1;
        legacyOrderLine.setHazardFlag(stratusFixedLength.substring(start, end));
        start = end++; end = start + 6;
        legacyOrderLine.setPresellDate(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 4;
        legacyOrderLine.setVendorCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 20;
        legacyOrderLine.setVendorSkuNumber(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setPayType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setCreditTermsAcceptSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setNewCustomerSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setSalesAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 7;
        legacyOrderLine.setDiscountAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 7;
        legacyOrderLine.setCreditAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 1;
        legacyOrderLine.setEdiStatus(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setPriceUsed(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 1;
        legacyOrderLine.setContinuitySwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 7;
        legacyOrderLine.setContinuityPlanId(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setContinuityOneShotSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setContinuityPlanClass(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setContinuitySeasonalityFlag(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setMerchandiseDivisonCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setMerchandiseDepartmentCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setMerchandiseClassCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setDropShipIndicator(stratusFixedLength.substring(start, end));
        start = end++; end = start + 3;
        legacyOrderLine.setDropShipDays(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 4;
        legacyOrderLine.setPrimaryWarehouse(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setPrimaryWarehouseState(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setCoShipIndicator(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setAlternateShipMethod(stratusFixedLength.substring(start, end));
        start = end++; end = start + 5;
        legacyOrderLine.setAlternateShipAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 2;
        legacyOrderLine.setMultiLineShippingDiscountCode(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setMultiLineShippingEvaluationCode(stratusFixedLength.substring(start, end));
        start = end+4; end = start + 7;
        legacyOrderLine.setShippingDiscountAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 5;
        legacyOrderLine.setPerItemFrt(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 5;
        legacyOrderLine.setPerItemTaxAmount(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 5;
        legacyOrderLine.setShippingAndHandlingIns(addDecimal((Double.valueOf(decodeAmount(stratusFixedLength.substring(start, end)))),2));
        start = end++; end = start + 1;
        legacyOrderLine.setDefaultOK(stratusFixedLength.substring(start, end));
        start = end++; end = start + 10;
        legacyOrderLine.setOrderNumber(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setPersonalSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 248;
        legacyOrderLine.setPersonalLineInfo(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setLineNumber(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 1;
        legacyOrderLine.setWaitlistSwith(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setWaitlistTime(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setWaitlistPhone(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setEzpayCreditSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setDuplicateSkn(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setGiftCertificateSwitch(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setGroupIndicator(stratusFixedLength.substring(start, end));
        start = end++; end = start + 16;
        legacyOrderLine.setItemInfoFlags(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setWaitlistRefundType(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setShhShipWith(stratusFixedLength.substring(start, end));
        start = end++; end = start + 1;
        legacyOrderLine.setLimitChecked(decodeInteger(stratusFixedLength.substring(start, end)));
        start = end++; end = start + 1;
        legacyOrderLine.setGuaranteedFlag(stratusFixedLength.substring(start, end));
        start = end++; end = start + 8;
        legacyOrderLine.setWildCardNumber(stratusFixedLength.substring(start, end));
        start = end++; end = start + 2;
        legacyOrderLine.setWildCardType(stratusFixedLength.substring(start, end));
        start = end++;               
        legacyOrderLines.add(legacyOrderLine);
      }     
      legacyOrder.setLegacyOrderLines(legacyOrderLines);
      return legacyOrder;
    } else {
      return null;
    }
  }
  
  @Override
  public String extractMemberNumber(String str) {
    start = 131; end = start + 10;
    
    return (str.trim().substring(start, end)); 
  }
  
  private String decodeAmount(String str) { 
    if (!StringUtils.isNumeric(str.trim().substring(str.length() - 1, str.trim().length()))) {
      int NumValue = (int) str.charAt(str.length()-1);
      
      switch (NumValue) {
        case  123:
        case  125:
          return (str.substring(0, str.length() - 1) + "0");
        default:
          if (NumValue > 73) {
            return (str.substring(0, str.length() - 1) + String.valueOf(NumValue - 73));
          } else {
            return (str.substring(0, str.length() - 1) + String.valueOf(NumValue - 64));
          }
      }
    } else {
      return str;
    } 
  }
  
  private double addDecimal(double val, int places) {
    long factor = (long)Math.pow(10,places);

    return ((double)val/factor);
  }
  
  private Integer decodeInteger(String str) {
    if (StringUtils.isNumeric(str)) {
      return Integer.valueOf(str);
    } else {
      return Integer.valueOf(0);
    }
  }
}
