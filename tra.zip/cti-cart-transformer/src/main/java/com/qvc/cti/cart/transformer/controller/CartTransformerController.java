package com.qvc.cti.cart.transformer.controller;

import java.text.MessageFormat;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qvc.cti.cart.transformer.service.CartTransformerService;


/**
 * Controller for handling legacy IVR order cart transformation request to
 * new global cart
 * 
 * @author   :- c004528
 * @version  :- August 7,2019
 *
 */
@RestController
@RequestMapping(value = {"/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/cart/transformer"})
public class CartTransformerController {

  private Logger logger = LoggerFactory.getLogger(CartTransformerController.class.getName());

  @Autowired
  private CartTransformerService cartTransformerService;

  @Value("${customer.lineOfBusiness}")
  private String lineOfBusiness;



/**
 * method for handling telAniDnisMsg session save request
 * 
 * @param version
 * @param countryCode
 * @param lob
 * @param telAniDnisMsg
 * @param headers
 * @return String
 */
  @PostMapping(value = "/tel-ani-dnis", produces = {"application/json", "application/xml"})
  public ResponseEntity<String> saveTelAniDnisToSession(@PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
			@PathVariable(name = "lob", required = false) String lob, HttpServletRequest request,
			@RequestHeader HttpHeaders headers) {

		String methodName = "saveTelAniDnisToSession";
		String telAniDnisMsg = request.getParameter("telanidnismsg");
		Assert.hasText(telAniDnisMsg, "The request parameter 'telanidnismsg' cannot be empty");
		logger.info(MessageFormat.format("{0}|Calling cartTransformerService using " + "countryCode[{1}] "+ "version[{2}] " + "telAniDnisMsg[{3}] ", 
				methodName, countryCode, version, telAniDnisMsg));
		return new ResponseEntity<>(cartTransformerService.saveCartTransformerSession(version, countryCode,
				standardizeLob(lob), telAniDnisMsg, headers), HttpStatus.CREATED);
	}


  /**
   * Return first character of the default lob values from the property file.If requested lob is null
   * or empty.
   *
   * @param lob the lob
   * @return the string
   */
  public String standardizeLob(String lob) {
    lob = StringUtils.isBlank(lob) ? lineOfBusiness : lob;
    return Character.toString(lob.charAt(0)).toLowerCase();
  }

}