package com.qvc.cti.cart.transformer.aspect;

import java.text.MessageFormat;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import com.qvc.cti.cart.transformer.util.UtilMethods;

/**
 * @author   :- c004528
 * @version  :- August 7,2019
 *
 */

@Configuration
@Aspect
public class LoggingAspect {

  /** Logger */
  Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

  @SuppressWarnings("unused")
  @Around(" execution(* com.qvc.cti.cart.transformer.controller.CartTransformerController.*(..)) || execution(* com.qvc.cti.cart.transformer.service.CartTransformerServiceImpl.*(..))")
  public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
    long methodStartTime = System.currentTimeMillis();
    String methodName = null;
    String simpleClassName = null;
    Class<?> returnType = null;
    try {
      methodName = joinPoint.getSignature().getName();
      returnType = ((MethodSignature) joinPoint.getSignature()).getReturnType();
      simpleClassName = joinPoint.getTarget().getClass().getSimpleName();
      return joinPoint.proceed();
    } catch (Throwable b) {
      logger
          .error(MessageFormat.format("Error while executing method: {0}, {1}", simpleClassName + "." + methodName, UtilMethods.generateShortErrorMessage(b)));
      throw b;
    } finally {
      logger.info("{}.{} | {} | Method completed ", simpleClassName, methodName, (System.currentTimeMillis() - methodStartTime) + "ms");
    }
  }

}
