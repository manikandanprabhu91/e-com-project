package com.qvc.cti.cart.transformer.config;

import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Configuration;
import ch.qos.logback.access.tomcat.LogbackValve;

@Configuration
public class ServletContainerCustomizer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

	@Override
	public void customize(TomcatServletWebServerFactory webServiceTemplate) {
		LogbackValve logbackValve = new LogbackValve();
		webServiceTemplate.addContextValves(logbackValve);
	}
}
