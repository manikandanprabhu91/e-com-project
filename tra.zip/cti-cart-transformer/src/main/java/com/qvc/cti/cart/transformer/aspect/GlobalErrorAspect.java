package com.qvc.cti.cart.transformer.aspect;

import java.util.List;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import feign.FeignException;

/**
 * Global Error handler for handling the exceptions and then provide user friendly error message
 * with correct HTTP error code to the caller. This helps eliminate the boiler plate code scattered
 * across all over the application and makes exception handling controlled and managed at one place.
 * Spring by default handles all the exception and sets the correct HTTP code in the response body,
 * However it does not set the body of Response message with meaningful error message. This handler
 * will make sure in case of exception it will set correct HTTP error code and will also set most
 * appropriate error message into response body. Spring's default hander is found
 * {@link org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler}
 */
@ControllerAdvice
public class GlobalErrorAspect {

  /** Logger */
  private static final Logger logger = LoggerFactory.getLogger(GlobalErrorAspect.class);

  @ExceptionHandler(HttpClientErrorException.class)
  protected ResponseEntity<Object> handleHttpClientErrorException(HttpClientErrorException ex) {
    logger.error("Exception thrown HttpClientErrorException: {}", ex.getMessage());
    ex.getMostSpecificCause();
    return new ResponseEntity<>(ex.getResponseBodyAsByteArray(), ex.getStatusCode());
  }

  /**
   * When suitable HTTP Method is not supported
   */
  @ExceptionHandler
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex) {
    logger.error("Exception thrown HttpRequestMethodNotSupportedException: {}", ex.getMessage());
    StringBuilder builder = new StringBuilder();
    builder.append(ex.getMethod());
    builder.append(" method is not supported for this request. Supported methods are ");
    ex.getSupportedHttpMethods().forEach(t -> builder.append(t + " "));

    ApiError apiError = new ApiError(HttpStatus.METHOD_NOT_ALLOWED, ex.getLocalizedMessage(), builder.toString());
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getStatus());
  }

  /**
   * When required header is missing from the request
   */
  @ExceptionHandler
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(ServletRequestBindingException ex) {
    logger.error("Exception thrown ServletRequestBindingException: {}", ex.getMessage());
    StringBuilder builder = new StringBuilder();
    builder.append(ex.getMessage());
    ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, ex.getLocalizedMessage(), builder.toString());
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getStatus());
  }


  /**
   * HttpMediaTypeNotAcceptableException is thrown when client can not accept the media type service
   * is returning
   */
  @ExceptionHandler
  protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex) {
    logger.error("Exception thrown HttpMediaTypeNotAcceptableException: {}", ex.getMessage());
    StringBuilder builder = new StringBuilder();
    builder.append(ex.getLocalizedMessage());
    builder.append(" media type is not supported. Supported media types are ");
    ex.getSupportedMediaTypes().forEach(t -> builder.append(t + ", "));

    ApiError apiError = new ApiError(HttpStatus.UNSUPPORTED_MEDIA_TYPE, ex.getLocalizedMessage(), builder.substring(0, builder.length() - 2));
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getStatus());
  }

  /**
   * Exception is thrown when there is an error in a service method
   */
  @ExceptionHandler
  protected ResponseEntity<Object> handleHystrixRuntimeException(HystrixRuntimeException ex) {
    List<Throwable> throwableList = ExceptionUtils.getThrowableList(ex);
    for (Throwable throwable : throwableList) {
      if (throwable.getClass().equals(NoConnectionToServiceException.class)) {
        return handleServiceConnectionErrorInner(ex, "handleHystrixRuntimeException");
      }
    }
    return handleAll(ex);
  }

  /**
   * Exception is thrown when there is a service connection error, mostly used for testing
   */
  @ExceptionHandler
  protected ResponseEntity<Object> handleNoConnectionToServiceException(NoConnectionToServiceException ex) {
    return handleServiceConnectionErrorInner(ex, "handleNoConnectionToServiceException");
  }

  private ResponseEntity<Object> handleServiceConnectionErrorInner(Exception ex, String callingMethod) {
	String logMsgPrefix = "Exception thrown NoConnectionToServiceException :" + callingMethod+": {}";
    logger.error(logMsgPrefix, ex.getMessage());
    StringBuilder builder = new StringBuilder();
    builder.append("Cannot reach GUID Service to retrive GUID information");
    ApiError apiError = new ApiError(HttpStatus.SERVICE_UNAVAILABLE, builder.toString(), ex.getLocalizedMessage());
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getStatus());
  }

  /**
   * This is fall back handler. We will catch the exception when no suitable handler is defined for
   * our request
   */
  @ExceptionHandler({Exception.class})
  public ResponseEntity<Object> handleAll(Exception ex) {
    logger.error("Error occurred: {}", ex.getMessage());
    String errorMessage = ex.getMessage() == null ? ex.getClass().getName() : ex.getMessage();
    ApiError apiError;
    HttpStatus httpStatus = null;
    HttpHeaders responseHeaders = null;
    if (ex instanceof HttpStatusCodeException && ((HttpStatusCodeException) ex).getRawStatusCode() >= 400) {
      try {
        httpStatus = HttpStatus.valueOf(((HttpStatusCodeException) ex).getRawStatusCode());
        responseHeaders = ((HttpStatusCodeException) ex).getResponseHeaders() != null ? ((HttpStatusCodeException) ex).getResponseHeaders() : new HttpHeaders();
      } catch (IllegalArgumentException iae) {
        logger.error("Unknown error code: " + ((HttpStatusCodeException) ex).getRawStatusCode(), iae);
      }
    }
    apiError = new ApiError(httpStatus != null ? httpStatus : HttpStatus.BAD_REQUEST, "Error occurred", errorMessage);
    return new ResponseEntity<>(apiError, responseHeaders, apiError.getStatus());
  }

  /**
   * Handle feign exception.
   *
   * @param ex the ex
   * @return the response entity
   */
  @ExceptionHandler
  public ResponseEntity<ApiError> handleFeignException(FeignException ex) {
    logger.error("Exception thrown FeignException: {}", ex.getMessage());
    return new ResponseEntity<>(new ApiError(HttpStatus.valueOf(ex.status()), "Received no data in response ", ex.getLocalizedMessage()),
        HttpStatus.valueOf(ex.status()));
  }


}
