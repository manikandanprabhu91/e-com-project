package com.qvc.cti.cart.transformer.util;

/**
 * @author c004528
 *
 */
public class UtilMethods {

  private UtilMethods() {

  }

  public static String generateShortErrorMessage(Throwable b) {
    return b.getClass().getName() + (b.getMessage() != null ? ": " + b.getMessage().trim() : "");
  }

}
