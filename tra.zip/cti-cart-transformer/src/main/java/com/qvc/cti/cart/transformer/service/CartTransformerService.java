package com.qvc.cti.cart.transformer.service;

import org.springframework.http.HttpHeaders;

/**
 * 
 * @author   :- c004528
 * @version  :- August 7,2019
 *
 */
public interface CartTransformerService {
  public String saveCartTransformerSession(String version, String countryCode, String lob, String telAniDnisMsg, HttpHeaders headers);
}