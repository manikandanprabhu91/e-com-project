package com.qvc.cti.cart.transformer.service;

import com.qvc.order.model.cti.CallInfo;
import com.qvc.order.model.cti.LegacyOrder;

public interface FixedLengthConversionService {
  public CallInfo extractCallInfo(String stratusFixedLength);
  public String extractCallKey(String stratusFixedLength);
  public LegacyOrder extractLegacyOrder(String stratusFixedLength);
  public String extractMemberNumber(String stratusFixedLength);
}