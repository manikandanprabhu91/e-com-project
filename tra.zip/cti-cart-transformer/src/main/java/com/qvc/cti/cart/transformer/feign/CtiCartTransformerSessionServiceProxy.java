package com.qvc.cti.cart.transformer.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.qvc.order.model.cti.CTISession;

/**
 * Feign client for calling ctiSession Service
 * 
 * @author   :- c004528
 * @version  :- August 7,2019
 *
 */
@FeignClient(name = "${spring.application.name}", url = "${cart.transformer.webservice.ctiSessionService.ctiSessionServiceHost}")
public interface CtiCartTransformerSessionServiceProxy {
	
	@PostMapping(value = "/order-flow/order-capture/{version}/{countryCode}/{lob}/cti/session")
	ResponseEntity<CTISession> saveCartTransformerSession(@PathVariable("version") String version, @PathVariable("countryCode") String countryCode, @PathVariable("lob") String lob,
	@RequestBody CTISession ctiSession, @RequestHeader HttpHeaders headers);
	
}

