package com.qvc.cti.cart.transformer.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * The Class ServletContainerCustomizerTest.
 */
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ServletContainerCustomizer.class})
public class ServletContainerCustomizerTest {

  /** The servlet container customizer. */
  @Autowired
  ServletContainerCustomizer servletContainerCustomizer;

  /**
   * Customize test.
   */
  @Test
  public void customizeTest() {
    servletContainerCustomizer.customize(new TomcatServletWebServerFactory());
  }

}
