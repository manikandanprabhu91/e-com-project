package com.qvc.cti.cart.transformer.service;

import static org.mockito.Mockito.when;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.qvc.cti.cart.transformer.feign.CtiCartTransformerSessionServiceProxy;
import com.qvc.order.model.cti.CTISession;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CartTransformerServiceImpl.class})
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@ActiveProfiles("test")
public class CartTransformerServiceTest {


  @Autowired
  private CartTransformerService cartTransformerService;
  @MockBean
  private CtiCartTransformerSessionServiceProxy ctiCartTransformerSessionServiceProxy;

  private HttpHeaders headers;
  ResponseEntity<CTISession> serviceCallResponse;
  private String serviceTestInput;
  
  public static final String CART_TRANSFORMER_FEIGN_URI = "/order-flow/order-capture/v1/us/q/cti/session";

  @Before
  public void setUp() {
    headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    serviceTestInput="2019090513500610.24.26.136    4292 4292      610701690513554220858X  qvcX5031 61088350314320 1013114320O  000000000000S000008"+
    "G10000010187  RENDELL                  ED                  701 MCCARDLE DR                                                            WEST CHESTER"+
    "		PAUS19380 1956         N 6107016905        6104960011        20001108                336  QV0000000000001253    9912 1809VI0000000000005437    2312A1903QVC"+
    "N  Y N                 NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN        20190821065000COMPlus NNN                      20190821"+
    "1H50041 H50041 0000000001008600000000000QVCQVC                   DISKBA190815Y.000 PD01000072BGRMen of Aran Bronze Sculpture"+
    "Men of Aran Bronze Sculpture                                                                 000280A000000{000495{000495{    0000.000"+
    "H50041 000000Y   00                            10AX10100000BL10100000CB10100000DC10100000HD10100000MC10100000SI10100000VI10100000CK30300000QV00000000"+
    "00000000{.00 N000000Y126XX                     N000000{000000{000000{N000495{          N2067501FN0000540NC2GR00722CL     000000{0000{0000{0000{"+
    "1      N                  0           N                    0000000000000000000                                      .000     000000{";
  }

  @Test
  public void testSaveCartTransformerSessionResponseCreated(){
	serviceCallResponse = new ResponseEntity<>(HttpStatus.CREATED);
    when(ctiCartTransformerSessionServiceProxy.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class), Mockito.any(HttpHeaders.class)))
    .thenReturn(serviceCallResponse);
    Assert.assertEquals("STRATUS00000", cartTransformerService.saveCartTransformerSession("v1", "us", "qvc", serviceTestInput, headers));
  }

  
  @Test
  public void testSaveCartTransformerSessionNotCreated(){
	serviceCallResponse = new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
    when(ctiCartTransformerSessionServiceProxy.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class), Mockito.any(HttpHeaders.class)))
    .thenReturn(serviceCallResponse);
    Assert.assertEquals("STRATUS99999", cartTransformerService.saveCartTransformerSession("v1", "us", "qvc", serviceTestInput, headers));
  }
  
}
