package com.qvc.cti.cart.transformer.aspect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.qvc.cti.cart.transformer.controller.CartTransformerController;
import com.qvc.cti.cart.transformer.feign.CtiCartTransformerSessionServiceProxy;
import com.qvc.cti.cart.transformer.service.CartTransformerService;
import feign.FeignException;


@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
public class GlobalErrorAspectTest {

  private MockMvc mvc;

  @InjectMocks
  private CartTransformerController controller;

  @MockBean
  private CartTransformerService service;

  @MockBean
  private CtiCartTransformerSessionServiceProxy ctiCartTransformerSessionServiceProxy;

  HttpHeaders header;

  public static final String CART_TRANSFORMER_URI = "/order-flow/order-capture/v1/us/q/cti/cart/transformer/tel-ani-dnis";

  public static final String CTI_SESSION_URI = "/order-flow/order-capture/v1/us/q/cti/session";

  public static final String MESSAGE = "$.message";

  public static final String STATUS = "$.status";
  
  public static final String REQUEST_PARAM = "telanidnismsg";

  private NoConnectionToServiceException noConnectionToServiceException;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(new GlobalErrorAspect()).build();
    header = new HttpHeaders();
    header.add("Content-type", "application/json");
    String [] errors = {"404", "500", "410"};
    ApiError apiError = new ApiError();
    apiError.setStatus(HttpStatus.ACCEPTED);
    apiError.setMessage(MESSAGE);
    apiError.setErrors(errors);
    this.noConnectionToServiceException = new NoConnectionToServiceException(new Exception("CTI Cart Transformer Service Not Available Exception"));
  }

  @Test
  public void testHandleHttpRequestMethodNotSupported() throws Exception {
	Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
	.thenThrow(new HttpClientErrorException(HttpStatus.METHOD_NOT_ALLOWED));	  
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;})).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED.value());		
  }
  
  @Test
  public void testRequestHeaderMissing() throws Exception {
	Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
	.thenThrow(new HttpClientErrorException(HttpStatus.EXPECTATION_FAILED));		  
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;})).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.EXPECTATION_FAILED.value());	
  }  

  @Test
  public void testHttpMediaTypeNotAcceptable() throws Exception {
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_OCTET_STREAM).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_ACCEPTABLE.value());
  }

  @Test
  public void testHttpClientErrorException() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;})).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
  }

  @Test
  public void testHystrixRuntimeException() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(HystrixRuntimeException.class);
    mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andExpect(jsonPath(MESSAGE, is("Error occurred"))).andExpect(jsonPath(STATUS, is(HttpStatus.BAD_REQUEST.name())));
  }

  @Test
  public void testNoConnectionToServiceException() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(noConnectionToServiceException);
    mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andExpect(jsonPath(STATUS, is(HttpStatus.SERVICE_UNAVAILABLE.name())));
  }

  @Test
  public void testException() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(NullPointerException.class);
    mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andExpect(jsonPath(MESSAGE, is("Error occurred"))).andExpect(jsonPath(STATUS, is(HttpStatus.BAD_REQUEST.name())));
  }

  @Test
  public void testServiceUnavailable() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class))).thenThrow(noConnectionToServiceException);
    mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andExpect(status().is5xxServerError());
  }
  
  /**
   * Test http status code exception.
   *
   * @throws Exception the exception
   */

  @Test
  public void testHttpStatusCodeException() throws Exception {
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(new HttpStatusCodeException(HttpStatus.CONFLICT) {private static final long serialVersionUID = -7352111074196509737L; });    
    mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;}))
    .andExpect(status().isConflict());
  }  

  /**
   * Test feign exception
   *
   * @throws Exception the exception
   */
  @Test
  public void testFeignExceptionForSaveCartTransformerSession() throws Exception {
    byte[] content = "error".getBytes();
    Mockito.when(service.saveCartTransformerSession(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(HttpHeaders.class)))
    .thenThrow(new FeignException(404, "Received no CTISession in response ", content) {private static final long serialVersionUID = 1L;});
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, "test");return request;})).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());	
  }

}
