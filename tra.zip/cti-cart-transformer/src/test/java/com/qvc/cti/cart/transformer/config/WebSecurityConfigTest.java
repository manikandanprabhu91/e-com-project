
package com.qvc.cti.cart.transformer.config;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * The Class WebConfigTest.
 *
 * @author c004528
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {WebSecurityConfig.class})
@ActiveProfiles("test")
public class WebSecurityConfigTest {

  @Autowired
  WebSecurityConfig webConfig;

  @MockBean
  InMemoryUserDetailsManager InMemoryUserDetailsManager;

  /**
   * Test rest template.
   */
  @Test
  public void testRestTemplate() {
    assertNotNull(webConfig.restTemplate());
  }

  /**
   * Test get spring user properties.
 * @throws IOException 
   */
  @Test
  public void testgetSpringUserProperties() throws IOException {
    assertNotNull(webConfig.getSpringUserProperties());
  }

}
