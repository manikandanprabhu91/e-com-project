package com.qvc.cti.cart.transformer.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.qvc.cti.cart.transformer.aspect.GlobalErrorAspect;
import com.qvc.cti.cart.transformer.service.CartTransformerService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(value = CartTransformerController.class)
@ContextConfiguration(locations = {"classpath:applicationContext-test.xml"})
@ActiveProfiles("test") 
public class CartTransformerControllerTest {

  @Autowired
  private CartTransformerController cartTransformerController;

  @MockBean
  private CartTransformerService cartTransformerService;
  
  private MockMvc mvc;
  private HttpHeaders headers;
  
  public static final String CART_TRANSFORMER_URI = "/order-flow/order-capture/v1/us/q/cti/cart/transformer/tel-ani-dnis";
  public static final String CART_TRANSFORMER_WRONG_URI = "/order-flow/order-capture/v1/us/q/cti/cart/transformer/telanidnis";
  public static final String REQUEST_PARAM = "telanidnismsg";
  private String serviceTestInput;

  @Before
  public void setUp() {
	mvc = MockMvcBuilders.standaloneSetup(cartTransformerController).setControllerAdvice(new GlobalErrorAspect()).build();
    headers = new HttpHeaders();
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    serviceTestInput="2019090513500610.24.26.136    4292 4292      610701690513554220858X  qvcX5031 61088350314320 1013114320O  000000000000S000008"+
    "G10000010187  RENDELL                  ED                  701 MCCARDLE DR                                                            WEST CHESTER"+
    "		PAUS19380 1956         N 6107016905        6104960011        20001108                336  QV0000000000001253    9912 1809VI0000000000005437    2312A1903QVC"+
    "N  Y N                 NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN        20190821065000COMPlus NNN                      20190821"+
    "1H50041 H50041 0000000001008600000000000QVCQVC                   DISKBA190815Y.000 PD01000072BGRMen of Aran Bronze Sculpture"+
    "Men of Aran Bronze Sculpture                                                                 000280A000000{000495{000495{    0000.000"+
    "H50041 000000Y   00                            10AX10100000BL10100000CB10100000DC10100000HD10100000MC10100000SI10100000VI10100000CK30300000QV00000000"+
    "00000000{.00 N000000Y126XX                     N000000{000000{000000{N000495{          N2067501FN0000540NC2GR00722CL     000000{0000{0000{0000{"+
    "1      N                  0           N                    0000000000000000000                                      .000     000000{";    
  }
  
  @Test
  public void testSaveTelAniDnisToSessionHttpStatusResponseCreated() throws Exception {
    when(cartTransformerService.saveCartTransformerSession("v1", "us", "q", serviceTestInput, headers)).thenReturn("STRATUS00000");
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, serviceTestInput);return request;})).andReturn().getResponse();
    assertThat(response.getContentAsString()).isEqualTo("STRATUS00000");	
  }

  @Test
  public void testSaveTelAniDnisToSessionHttpStatusResponseNotCreated() throws Exception{
    when(cartTransformerService.saveCartTransformerSession("v1", "us", "q",serviceTestInput, headers)).thenReturn("STRATUS99999");
    MockHttpServletResponse response = mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, serviceTestInput);return request;})).andReturn().getResponse();
    assertThat(response.getContentAsString()).isEqualTo("STRATUS99999");	   
  }
  
  @Test
  public void testSaveTelAniDnisToSessionHttpStatusResponse404NotFound() throws Exception{
    mvc.perform(post(CART_TRANSFORMER_WRONG_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).with(request -> {
    request.setParameter(REQUEST_PARAM, serviceTestInput);return request;})).andExpect(MockMvcResultMatchers.status().isNotFound());  
  }  
  
  @Test
  public void testSaveTelAniDnisToSessionMethodNotSupportedException() throws Exception {
	mvc.perform(get(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isMethodNotAllowed());  
  }   
  
  @Test
  public void testSaveTelAniDnisToSessionMediaTypeNotSupportedException() throws Exception {
	mvc.perform(post(CART_TRANSFORMER_URI).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_OCTET_STREAM).with(request -> {
    request.setParameter(REQUEST_PARAM, serviceTestInput);return request;})).andExpect(MockMvcResultMatchers.status().isNotAcceptable());
  }   
    
  /**
   * Test standard lob with null lob request.
   */
  @Test
  public void testStandardLobWithNullLobRequest() {
    String a = cartTransformerController.standardizeLob(null);
    Assert.assertEquals("q", a);
  }

  /**
   * Test standard lob with empty lob request.
   */
  @Test
  public void testStandardLobWithEmptyLobRequest() {
    String a = cartTransformerController.standardizeLob("");
    Assert.assertEquals("q", a);
  }

  /**
   * Test standard lob.
   */
  @Test
  public void testStandardLob() {
    String a = cartTransformerController.standardizeLob("hsn");
    Assert.assertEquals("h", a);
  }
}
