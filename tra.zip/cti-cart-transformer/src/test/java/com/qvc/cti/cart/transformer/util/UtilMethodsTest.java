package com.qvc.cti.cart.transformer.util;

import static org.mockito.Mockito.when;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {UtilMethods.class})
@ActiveProfiles("test")
public class UtilMethodsTest {

  @Test
  public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
    Constructor<UtilMethods> constructor = UtilMethods.class.getDeclaredConstructor();
    Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
    constructor.setAccessible(true);
    constructor.newInstance();
  }

  @Test(expected = Throwable.class)
  public void testThrowExceptionGenereateShortMsg() {
    when(UtilMethods.generateShortErrorMessage(new Throwable())).thenReturn("java.lang.Throwable");
    Assert.assertEquals("java.lang.Throwable", UtilMethods.generateShortErrorMessage(new Throwable()));

  }

  @Test
  public void testThrowExceptionGenereateShortEmptyMsg() {
    Assert.assertNull("", null);

  }

  @Test
  public void testUtilMethodGenerateShortErrorMessage() {
    Assert.assertEquals(new Throwable() + "", UtilMethods.generateShortErrorMessage(new Throwable()));
    Assert.assertEquals(new Throwable("message") + "", UtilMethods.generateShortErrorMessage(new Throwable("message")));
  }


}
