package com.qvc.cti.session.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.qvc.cti.session.CtiSessionApplication;
import com.qvc.cti.session.aspect.GlobalErrorAspect;
import com.qvc.cti.session.feign.DataRouterClient;
import com.qvc.cti.session.service.CtiSessionServiceImpl;
import com.qvc.order.model.cti.CTISession;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CtiSessionApplication.class,CtiSessionController.class,CtiSessionServiceImpl.class})
@ActiveProfiles("test")
public class CtiSessionTest {

  @Autowired
  public CtiSessionController ctiSessionController;

  @MockBean
  DataRouterClient idataRouterClient;
  
  private String input;
  
  private MockMvc mvc;
  
  public static final String CREATE_CTI_SESSION = "/order-flow/order-capture/v1/us/q/cti/session";
  
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mvc = MockMvcBuilders.standaloneSetup(ctiSessionController).setControllerAdvice(new GlobalErrorAspect())
        .build();
    input = "{\"sessionId\": \"000\",\"agentId\": \"c00\"}";
  }
  
  @Test
  public void testSession() throws Exception {
    HttpHeaders headers = getHeader();
    CTISession ctiSession = new CTISession();
    when(idataRouterClient.createCTISession(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
    .thenReturn(new ResponseEntity<CTISession>(ctiSession, HttpStatus.CREATED));
    MockHttpServletResponse response =
        mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON).content(input).headers(headers)).andReturn().getResponse();
    assertThat(response.getStatus())
        .isNotNull();
    verify(idataRouterClient, times(1)).createCTISession(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());
  }
  
  /**
   * Gets the header.
   *
   * @return the header
   */
  private HttpHeaders getHeader() {
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      ArrayList<MediaType> list = new ArrayList<>();
      list.add(MediaType.APPLICATION_JSON);
      headers.setAccept(list);
      String auth = "teset" + ":" + "pwd";
      byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
      String authHeader = "Basic " + new String(encodedAuth);
      headers.set("Authorization", authHeader);
      return headers;
  }
}
