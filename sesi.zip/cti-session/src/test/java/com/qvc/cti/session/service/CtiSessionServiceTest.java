package com.qvc.cti.session.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import com.qvc.cti.session.feign.DataRouterClient;
import com.qvc.cti.session.service.CtiSessionServiceImpl;
import com.qvc.order.model.cti.CTISession;

/**
 * The Class CtiCmsServiceTest.
 *
 * @author c007152
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = CtiSessionServiceImpl.class)
@ActiveProfiles("test")
public class CtiSessionServiceTest {

	@Autowired
	CtiSessionServiceImpl service;

	@MockBean
	DataRouterClient idataRouterClient;

	/**
	 * Test update cms.
	 */
	@Test
	public void testcreateCTISession() {
		HttpHeaders headers = getHeader();
		CTISession ctiSession = new CTISession();
		when(idataRouterClient.createCTISession(headers,"v1", "us", "q", ctiSession))
				.thenReturn(new ResponseEntity<CTISession>(ctiSession, HttpStatus.CREATED));
		service.createCTISession(getHeader(), "v1", "us", "q", ctiSession);
		verify(idataRouterClient, times(1)).createCTISession(headers,"v1", "us", "q", ctiSession);
	}

	@Test
	public void testFindSessionBySesionId() {
	  HttpHeaders headers = getHeader();
      CTISession ctiSession = new CTISession();
      ctiSession.setSessionId("0001");
      ctiSession.setAgentId("c007152");
      when(idataRouterClient.findCTISessionBySessionId(headers,"v1", "us", "q", "0001"))
              .thenReturn(new ResponseEntity<CTISession>(ctiSession, HttpStatus.CREATED));
      service.findSessionBySessionId(getHeader(), "v1", "us", "q", "0001");
      verify(idataRouterClient, times(1)).findCTISessionBySessionId(headers,"v1", "us", "q", "0001");
	}
	/**
     * Test find session by sesion id.
     */
    @Test
    public void testupdateCtiSession() {
      HttpHeaders headers = getHeader();
      CTISession ctiSession = new CTISession();
      ctiSession.setSessionId("0001");
      ctiSession.setAgentId("c007152");
      when(idataRouterClient.updateCTISession(headers,"v1", "us", "q",ctiSession))
              .thenReturn(new ResponseEntity<CTISession>(ctiSession, HttpStatus.CREATED));
      service.updateCTISession(getHeader(), "v1", "us", "q",ctiSession);
      verify(idataRouterClient, times(1)).updateCTISession(headers,"v1", "us", "q",ctiSession);
    }
    /**
     * Test find session by sesion id.
     */
    @Test
    public void testDeleteCtiSession() {
      HttpHeaders headers = getHeader();
      CTISession ctiSession = new CTISession();
      ctiSession.setSessionId("0001");
      ctiSession.setAgentId("c007152");
      when(idataRouterClient.deleteCTISession(headers,"v1", "us", "q",ctiSession))
              .thenReturn(new ResponseEntity<CTISession>(ctiSession, HttpStatus.CREATED));
      service.deleteCTISession(getHeader(), "v1", "us", "q",ctiSession);
      verify(idataRouterClient, times(1)).deleteCTISession(headers,"v1", "us", "q",ctiSession);
    }
	/**
	 * Gets the header.
	 *
	 * @return the header
	 */
	private HttpHeaders getHeader() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ArrayList<MediaType> list = new ArrayList<>();
		list.add(MediaType.APPLICATION_JSON);
		headers.setAccept(list);
		String auth = "teset" + ":" + "pwd";
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.set("Authorization", authHeader);
		return headers;
	}

}
