
package com.qvc.cti.session.config;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;


/**
 * The Class WebConfigTest.
 *
 * @author c007152
 */
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { WebSecurityConfig.class })
public class WebSecurityConfigTest {

	@Autowired
	WebSecurityConfig webConfig;

	@MockBean
	InMemoryUserDetailsManager InMemoryUserDetailsManager;
	/**
	 * Testget spring user properties.
	 */
	@Test
	public void testgetSpringUserProperties() {
		assertNotNull(webConfig.getSpringUserProperties());
	}
}
