package com.qvc.cti.session.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.qvc.cti.session.aspect.ApiError;
import com.qvc.cti.session.aspect.GlobalErrorAspect;
import com.qvc.cti.session.aspect.LoggingAspect;
import com.qvc.cti.session.aspect.NoConnectionToServiceException;
import com.qvc.cti.session.service.CtiSessionService;
import com.qvc.order.model.cti.CTISession;
import feign.FeignException;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
public class GlobalErrorAspectTest {

  private MockMvc mvc;

  @InjectMocks
  CtiSessionController ctiSessionController;

  @MockBean
  CtiSessionService ctiSessionService;
  
  private LoggingAspect loggingAspect;

  HttpHeaders header;

  private String input;

  public static final String CREATE_CTI_SESSION = "/order-flow/order-capture/v1/us/q/cti/session";
  
  public static final String INVALID_CREATE_CTI_SESSION = "/order-flow/order-capture/v1/us/q/cti/seion";

  public static final String MESSAGE = "$.message";

  public static final String STATUS = "$.status";

  private NoConnectionToServiceException noConnectionToServiceException;

  private ApiError apiError;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    mvc = MockMvcBuilders.standaloneSetup(ctiSessionController).setControllerAdvice(new GlobalErrorAspect())
        .build();
    String errors[] = {"404", "500", "410"};
    apiError = new ApiError();
    apiError.setStatus(HttpStatus.ACCEPTED);
    apiError.setMessage(MESSAGE);
    apiError.setErrors(errors);
    input = "{ \"sessionId\": \"0003\",\r\n" + 
        "    \"callInfo\": {\r\n" + 
        "        \"dnis\": \"test\",\r\n" + 
        "        \"ani\": \"test\",\r\n" + 
        "        \"siteId\": \"xxx\",\r\n" + 
        "        \"callId\": \"xxx\",\r\n" + 
        "        \"callDay\": \"Friday\",\r\n" + 
        "        \"callTime\": \"1564123521777\",\r\n" + 
        "        \"reservedATT\": \"reservedATT\",\r\n" + 
        "        \"reservedQVC\": \"reservedQVC\",\r\n" + 
        "        \"callType\": \"normal\",\r\n" + 
        "        \"extension\": \"415212\",\r\n" + 
        "        \"vdnTo\": \"415213\",\r\n" + 
        "        \"qvcCallType\": \"normal\",\r\n" + 
        "        \"destinationCode\": \"001\"\r\n" + 
        "    },\r\n" + 
        "    \"agentId\": \"c00\"}";
    this.noConnectionToServiceException =
        new NoConnectionToServiceException(new Exception("No Connection to Cti cms application"));
    loggingAspect = new LoggingAspect();
  }

  /**
   * Test http client error exception.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHttpClientErrorException() throws Exception {
    Mockito
        .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
    MockHttpServletResponse response =
        mvc.perform(post(INVALID_CREATE_CTI_SESSION).accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
  }


  /**
   * Test http media type not supported exception.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHttpMediaTypeNotSupportedException() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_OCTET_STREAM)
            .accept(MediaType.APPLICATION_OCTET_STREAM)).andReturn().getResponse();
    assertThat(response.getStatus())
        .isEqualTo(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value());
  }

  /**
   * Test handle http request method not supported.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHandleHttpRequestMethodNotSupported() throws Exception {
    MockHttpServletResponse response = mvc
        .perform(get(CREATE_CTI_SESSION).accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
    assertThat(response.getStatus())
        .isEqualTo(HttpStatus.METHOD_NOT_ALLOWED.value());
  }

  /**
   * Test no connection to service exception.
   *
   * @throws Exception the exception
   */

  @Test
  public void testNoConnectionToServiceException() throws Exception {
    Mockito
        .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(new HttpClientErrorException(HttpStatus.SERVICE_UNAVAILABLE));
    MockHttpServletResponse response =
        mvc.perform(post(CREATE_CTI_SESSION).accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus())
        .isEqualTo(HttpStatus.SERVICE_UNAVAILABLE.value());
  }

  /**
   * Test cti security service unavailable.
   *
   * @throws Exception the exception
   */
  @Test
  public void testCtiSecurityServiceUnavailable() throws Exception {
    Mockito
        .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(noConnectionToServiceException);
    mvc.perform(post(CREATE_CTI_SESSION).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).content(input))
        .andExpect(status().is5xxServerError());
  }


  /**
   * Test hystrix runtime exception.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHystrixRuntimeException() throws Exception {
    Mockito
        .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(HystrixRuntimeException.class);
    mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(MESSAGE, is("Error occurred")))
        .andExpect(jsonPath(STATUS, is(HttpStatus.BAD_REQUEST.name())));
  }
  /**
   * Test http status code exception.
   *
   * @throws Exception the exception
   */

  @Test
  public void testHttpStatusCodeException() throws Exception {
    Mockito
        .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(new HttpStatusCodeException(HttpStatus.CONFLICT) {
          private static final long serialVersionUID = -7352111074196509737L;
        });
    mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON).content(input))
        .andExpect(jsonPath(STATUS, is(HttpStatus.CONFLICT.name())));
  }


  /**
   * Test http media type not acceptable exception.
   *
   * @throws Exception the exception
   */
  @Test
  public void testHttpMediaTypeNotAcceptableException() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_OCTET_STREAM).content(input)).andReturn().getResponse();
    assertThat(response.getStatus())
        .isEqualTo(HttpStatus.NOT_ACCEPTABLE.value());
  }
  
  @Test
  public void testHttpRequestMethodNotSupported() throws Exception {
    MockHttpServletResponse response =
        mvc.perform(get(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED.value());
  }
  
  @Test
  public void testFeignException() throws Exception {

    byte[] content = "error".getBytes();
    Mockito
    .when(ctiSessionService.createCTISession(Mockito.any(HttpHeaders.class), Mockito.any(String.class),
        Mockito.any(String.class), Mockito.any(String.class), Mockito.any(CTISession.class)))
        .thenThrow(new FeignException(404,
            "Received no response from cti-data-router application", content) {
          private static final long serialVersionUID = 1L;
        });
    MockHttpServletResponse response =
        mvc.perform(post(CREATE_CTI_SESSION).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).content(input)).andReturn().getResponse();
    assertThat(response.getStatus()).isEqualTo(404);
  }
  

  @Test(expected = RuntimeException.class)
  public void testLoggingAspect() throws Throwable {
    loggingAspect.logAround(null);
  }
}
