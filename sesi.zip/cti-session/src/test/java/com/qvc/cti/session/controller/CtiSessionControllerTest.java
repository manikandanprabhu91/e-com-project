package com.qvc.cti.session.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpStatusCodeException;
import com.qvc.cti.session.service.CtiSessionService;
import com.qvc.order.model.cti.CTISession;

/**
 * @author c007152
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = CtiSessionController.class)
@ActiveProfiles("test")
public class CtiSessionControllerTest {

  @Autowired
  public CtiSessionController ctiSessionController;

  @MockBean
  private CtiSessionService ctiSessionService;

  @Test(expected = IllegalArgumentException.class)
  public void testcreateCTISessionWithNullPayLoad() {
    CTISession ctiSession = null;
    HttpHeaders headers = getHeader();
    ctiSessionController.createCTISession(headers, "v1", "us", "q", ctiSession);
  }
  @Test
  public void testcreateCTISession() {
    HttpHeaders headers = getHeader();
    CTISession ctiSession = new CTISession();
    ctiSession.setSessionId("0001");
    ctiSession.setAgentId("c007152");

    when(ctiSessionService.createCTISession(headers, "v1", "us", "q", ctiSession)).thenReturn(ctiSession);
    ctiSessionController.createCTISession(headers, "v1", "us", "q", ctiSession);
    verify(ctiSessionService, times(1)).createCTISession(headers, "v1", "us", "q", ctiSession);
  }

  @Test(expected = HttpStatusCodeException.class)
  public void testUpdateCmsWithException() {
    HttpHeaders headers = getHeader();
    CTISession ctiSession = new CTISession();
    ctiSession.setSessionId("0001");
    ctiSession.setAgentId("c007152");
    
    when(ctiSessionService.createCTISession(headers, "v1", "us", "q", ctiSession))
        .thenThrow(new HttpStatusCodeException(HttpStatus.SERVICE_UNAVAILABLE) {
          private static final long serialVersionUID = -1851923781093949427L;
        });
    ctiSessionController.createCTISession(headers, "v1", "us", "q", ctiSession);
    verify(ctiSessionService, times(1)).createCTISession(headers, "v1", "us", "q", ctiSession);
  }
  
  /**
   * Testcreate CTI session with null session id.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testcreateCTISessionWithNullSessionId() {
    CTISession ctiSession = new CTISession();
    ctiSession.setAgentId("c007152");
    ctiSession.setSessionId(null);
    HttpHeaders headers = getHeader();
    ctiSessionController.createCTISession(headers, "v1", "us", "q", ctiSession);
  }
  
  /**
   * Testcreate CTI session with empty session id.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testcreateCTISessionWithEmptySessionId() {
    CTISession ctiSession = new CTISession();
    ctiSession.setAgentId("c007152");
    ctiSession.setSessionId("");
    HttpHeaders headers = getHeader();
    ctiSessionController.createCTISession(headers, "v1", "us", "q", ctiSession);
  }
  
  @Test
  public void testFindSessionBysessionId() {
    HttpHeaders headers = getHeader();
    CTISession ctiSession = new CTISession();
    ctiSession.setSessionId("0001");
    ctiSession.setAgentId("c007152");

    when(ctiSessionService.findSessionBySessionId(headers, "v1", "us", "q", "0001")).thenReturn(ctiSession);
    ctiSessionController.findCTISessionBySessionId(headers, "v1", "us", "q","0001");
    verify(ctiSessionService, times(1)).findSessionBySessionId(headers, "v1", "us", "q", "0001");
  }
  /**
   * Testcreate CTI session with null session id.
   */
  @Test
  public void testUpdateCTISessionWithNullSessionId() {
    CTISession ctiSession = new CTISession();
    ctiSession.setAgentId("c007152");
    ctiSession.setSessionId("0001");
    HttpHeaders headers = getHeader();
    when(ctiSessionService.updateCTISession(headers, "v1", "us", "q", ctiSession)).thenReturn(ctiSession);
    ctiSessionController.updateCTISession(headers, "v1", "us", "q",ctiSession);
    verify(ctiSessionService, times(1)).updateCTISession(headers, "v1", "us", "q",ctiSession);
  }
  
  /**
   * Testcreate CTI session with empty session id.
   */
  @Test
  public void testDeleteCTISessionWithEmptySessionId() {
    CTISession ctiSession = new CTISession();
    ctiSession.setAgentId("c007152");
    ctiSession.setSessionId("0001");
    HttpHeaders headers = getHeader();
    when(ctiSessionService.deleteCTISession(headers, "v1", "us", "q",ctiSession)).thenReturn(ctiSession);
    ctiSessionController.deleteCTISession(headers, "v1", "us", "q",ctiSession);
    verify(ctiSessionService, times(1)).deleteCTISession(headers, "v1", "us", "q",ctiSession);
  }
  /**
   * Gets the header.
   *
   * @return the header
   */
  private HttpHeaders getHeader() {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    ArrayList<MediaType> list = new ArrayList<>();
    list.add(MediaType.APPLICATION_JSON);
    headers.setAccept(list);
    String auth = "teset" + ":" + "pwd";
    byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
    String authHeader = "Basic " + new String(encodedAuth);
    headers.set("Authorization", authHeader);
    return headers;
  }
}
