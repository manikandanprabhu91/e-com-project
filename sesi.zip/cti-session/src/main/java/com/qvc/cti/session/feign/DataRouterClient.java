package com.qvc.cti.session.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import com.qvc.order.model.cti.CTISession;

/**
 * The Interface IDataRouterClient.
 *
 * @author c007152
 */
@FeignClient(name = "${spring.application.name}", url = "${dataRouter.hostUrl}")
public interface DataRouterClient {

  /**
   * Creates the CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the response entity
   */
  @PostMapping(value = "/order/management/{version}/{countryCode}/{lob}/cti/session")
  public ResponseEntity<CTISession> createCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob, @RequestBody final CTISession ctiSession);
  
  /**
   * Find session by session id.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @return the response entity
   */
  @GetMapping(value = "/order/management/{version}/{countryCode}/{lob}/cti/session/session-id/{sessionId}",
      produces = {"application/json", "application/xml"})
  public ResponseEntity<CTISession> findCTISessionBySessionId(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob, @PathVariable("sessionId") String sessionId);
  
  /**
   * Update CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the response entity
   */
  @PutMapping(value = "/order/management/{version}/{countryCode}/{lob}/cti/session", produces = {"application/json"},
      consumes = {"application/json"})
  public ResponseEntity<CTISession> updateCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob,@RequestBody final CTISession ctiSession);
  
  /**
   * Delete CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the response entity
   */
  @DeleteMapping(value = "/order/management/{version}/{countryCode}/{lob}/cti/session", produces = {"application/json"},
      consumes = {"application/json"})
  public ResponseEntity<CTISession> deleteCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob,@RequestBody final CTISession ctiSession);
}
