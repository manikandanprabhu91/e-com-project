package com.qvc.cti.session.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.qvc.cti.session.feign.DataRouterClient;
import com.qvc.order.model.cti.CTISession;

/**
 * The Class CtiSessionServiceImpl.
 *
 * @author c007152
 */
@Service
public class CtiSessionServiceImpl implements CtiSessionService {

  @Autowired
  private DataRouterClient iDataRouterClient;

  /**
   * Creates the CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the CTI session
   */
  @Override
  public CTISession createCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    ResponseEntity<CTISession> createdSession =
        iDataRouterClient.createCTISession(headers, version, countryCode, lob, ctiSession);
    return createdSession.getBody();
  }

  /**
   * Find session by session id.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @return the CTI session
   */
  @Override
  public CTISession findSessionBySessionId(HttpHeaders headers, String version, String countryCode,
      String lob, String sessionId) {
    ResponseEntity<CTISession> session = iDataRouterClient.findCTISessionBySessionId(headers, version, countryCode, lob, sessionId);
    return session.getBody();
  }

  /**
   * Update CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the CTI session
   */
  @Override
  public CTISession updateCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    ResponseEntity<CTISession> session = iDataRouterClient.updateCTISession(headers, version, countryCode, lob,ctiSession);
    return session.getBody();
  }

  /**
   * Delete CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the CTI session
   */
  @Override
  public CTISession deleteCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession) {
    ResponseEntity<CTISession> session = iDataRouterClient.deleteCTISession(headers, version, countryCode, lob,ctiSession);
    return session.getBody();
  }
}
