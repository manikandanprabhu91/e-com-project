package com.qvc.cti.session.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.qvc.cti.session.service.CtiSessionService;
import com.qvc.order.model.cti.CTISession;

/**
 * The Class CtiSessionController.
 *
 * @author c007152
 */
@RestController
@RequestMapping(value = {"/order-flow/order-capture/{version}/{countryCode}/{lob}/cti"})
public class CtiSessionController {

  /** The cti session service. */
  @Autowired
  private CtiSessionService ctiSessionService;

  /** The Constant logger. */
  private static final Logger logger = LoggerFactory.getLogger(CtiSessionController.class);

  /**
   * Creates the CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the response entity
   */
  @PostMapping(value = "/session", produces = {"application/json"}, consumes = {"application/json"})
  public ResponseEntity<CTISession> createCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable(name = "lob") String lob, @RequestBody CTISession ctiSession) {
    requestValidation(ctiSession);
    logger.info("In create CTI session with Version {} CountryCode {} lob {}", version, countryCode,
        lob);
    return new ResponseEntity<>(ctiSessionService.createCTISession(headers, version, countryCode,
        lob, ctiSession), HttpStatus.CREATED);
  }

  /**
   * Find session by session id.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @return the response entity
   */
  @GetMapping(value = "/session/session-id/{sessionId}", produces = {"application/json"})
  public ResponseEntity<CTISession> findCTISessionBySessionId(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob, @PathVariable("sessionId") String sessionId) {
    return new ResponseEntity<>(
        ctiSessionService.findSessionBySessionId(headers, version, countryCode, lob, sessionId),
        HttpStatus.OK);
  }
  
  /**
   * Update CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the response entity
   */
  @PutMapping(value = "/session", produces = {"application/json"},
      consumes = {"application/json"})
  public ResponseEntity<CTISession> updateCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob, @RequestBody CTISession ctiSession) {
    requestValidation(ctiSession);
    return new ResponseEntity<>(ctiSessionService.updateCTISession(headers, version, countryCode,
        lob, ctiSession), HttpStatus.OK);
  }

  /**
   * Delete CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @return the response entity
   */
  @DeleteMapping(value = "/session", produces = {"application/json"},
      consumes = {"application/json"})
  public ResponseEntity<CTISession> deleteCTISession(@RequestHeader HttpHeaders headers,
      @PathVariable("version") String version, @PathVariable("countryCode") String countryCode,
      @PathVariable("lob") String lob, @RequestBody CTISession ctiSession) {
    requestValidation(ctiSession);
    return new ResponseEntity<>(ctiSessionService.deleteCTISession(headers, version, countryCode,
        lob, ctiSession), HttpStatus.OK);
  }
    
  /**
   * Request validation.
   *
   * @param ctiSession the cti session
   */
  private void requestValidation(CTISession ctiSession) {
    Assert.notNull(ctiSession, "The ctiSession request payload cannot be null or empty");
    Assert.hasText(ctiSession.getSessionId(), "SessionId should not be null or empty");
  }
}
