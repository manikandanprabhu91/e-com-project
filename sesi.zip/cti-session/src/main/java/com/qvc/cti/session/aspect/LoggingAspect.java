package com.qvc.cti.session.aspect;

import java.text.MessageFormat;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

/**
 * The Class LoggingAspect.
 *
 * @author c007152
 */
@Configuration
@Aspect
public class LoggingAspect {
  Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

  @Around(" execution(* com.qvc.cti.session.controller.CtiSessionController.*(..)) || execution(* com.qvc.cti.session.service.CtiSessionServiceImpl.*(..))")
  public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
    long methodStartTime = System.currentTimeMillis();
    String methodName = null;
    String simpleClassName = null;
    Class<?> returnType = null;
    try {
      methodName = joinPoint.getSignature().getName();
      returnType = ((MethodSignature) joinPoint.getSignature()).getReturnType();
      simpleClassName = joinPoint.getTarget().getClass().getSimpleName();
      return joinPoint.proceed();
    } catch (Throwable b) {
      logger.error(MessageFormat.format("Error while executing method: {0}, {1}",
          simpleClassName + "." + methodName, generateShortErrorMessage(b)));
      throw b;
    } finally {
      long m = (System.currentTimeMillis() - methodStartTime);
      logger.info("{}.{} returned {}| in {} ms | Method completed ", simpleClassName, methodName,returnType, m);
    }
  }

  public static String generateShortErrorMessage(Throwable b) {
    return b.getClass().getName() + (b.getMessage() != null ? ": " + b.getMessage().trim() : "");
  }


}
