package com.qvc.cti.session.config;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

/**
 * The Class WebSecurityConfig contains the configuration for the properties and the valid url
 * configuration.
 *
 * @author c007152
 */
@Configuration
@EnableGlobalMethodSecurity(securedEnabled = true)
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  /** The Constant PROFILE_TEST. */
  private static final String PROFILE_TEST = "test";

  /** The Constant logger. */
  private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);


  /** The environment. */
  @Autowired
  Environment environment;

  /** The file location. */
  @Value("${security.fileLocation}")
  private String fileLocation;

  /**
   * Configure the valid uri that can hit this services.
   *
   * @param http the http
   * @throws Exception the exception
   */
  @Override
  public void configure(HttpSecurity http) throws Exception {
    http.authorizeRequests().antMatchers("/swagger-ui*", "/info", "/health**").permitAll()
        .antMatchers("/order-flow/**").fullyAuthenticated().and().httpBasic().and().csrf()
        .disable();
  }

  /**
   * Configure the valid user who can access the application.
   *
   * @param auth the auth
   * @throws Exception the exception
   */
  @Override
  public void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(inMemoryUserDetailsManager());
  }

  /**
   * In memory user details manager.
   *
   * @return the in memory user details manager
   */
  @Bean
  public InMemoryUserDetailsManager inMemoryUserDetailsManager() {
    return new InMemoryUserDetailsManager(getSpringUserProperties());
  }

  /**
   * Gets the spring user properties.
   *
   * @return the spring user properties
   */
  @Bean(name = "springUserProperties")
  public Properties getSpringUserProperties() {
    Properties properties = null;
    try {
      if (Arrays.asList(environment.getActiveProfiles()).contains(PROFILE_TEST)) {
        properties = PropertiesLoaderUtils
            .loadProperties(new ClassPathResource("spring.security.rest.client.properties"));
      } else {
        properties = PropertiesLoaderUtils
            .loadProperties(new FileSystemResource(fileLocation + File.separatorChar + "spring.security.rest.client.properties"));
      }
    } catch (IOException ioException) {
      logger.error(ioException.getMessage());
    }
    return properties;
  }
}
