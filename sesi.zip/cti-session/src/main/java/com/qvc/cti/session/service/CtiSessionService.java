package com.qvc.cti.session.service;

import org.springframework.http.HttpHeaders;
import com.qvc.order.model.cti.CTISession;

/**
 * The Interface CtiSessionService.
 *
 * @author c007152
 */
public interface CtiSessionService {

  /**
   * Creates the CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the CTI session
   */
  public CTISession createCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession);
  
  /**
   * Find session by session id.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param sessionId the session id
   * @return the CTI session
   */
  public CTISession findSessionBySessionId(HttpHeaders headers, String version, String countryCode,
      String lob, String sessionId);
  
  /**
   * Update CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the CTI session
   */
  public CTISession updateCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession);

  /**
   * Delete CTI session.
   *
   * @param headers the headers
   * @param version the version
   * @param countryCode the country code
   * @param lob the lob
   * @param ctiSession the cti session
   * @return the CTI session
   */
  public CTISession deleteCTISession(HttpHeaders headers, String version, String countryCode,
      String lob, CTISession ctiSession);
}
